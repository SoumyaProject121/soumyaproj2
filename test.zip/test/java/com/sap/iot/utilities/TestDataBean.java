package com.sap.iot.utilities;

public class TestDataBean {
	
	private String basicInfoProjectName;
	private String basicInfoNamespace;
	private String basicInfoTitle;
	private String selectPageThingListEnable;
	private String selectPageThingPageEnable;
	private String selectPageAnalysisPageEnable;
	private String landingPageThingListOnMapCheckBox;
	private String landingPageThingListOnMapInfo1;
	private String landingPageThingListOnMapInfo2;
	private String landingPageThingListOnMapSortField;
	private String landingPageThingListOnMapSortDirection;
	private String landingPageSingleCardTitle;
	private String landingPageSingleCardHeaderInfo1;
	private String landingPageSingleCardHeaderInfo2;
	private String landingPageSingleCardHeaderNavigation;
	private String landingPageSingleCardEventEnable;
	private String landingPageSingleCardEventTitle;
	private String landingPageSingleCardContactEnable;
	private String landingPageSingleCardContactTitle;
	private String landingPageSingleCardContactInfo1;
	private String landingPageSingleCardContactInfo2;
	private String landingPageSingleCardContactInfo3;
	private String landingPageSingleCardFooterText;
	private String landingPageSingleCardFooterNavTarget;
	private String landingPageMultiCardTitle;
	private String landingPageMultiCardInfo1;
	private String landingPageMultiCardInfo2;
	private String landingPageMultiCardListNavTarget;
	private String landingPageMultiCardFooterText;
	private String landingPageMultiCardFooterNavTarget;
	private String thingListTitle;
	private String thingListDefaultSortField;
	private String thingListSortDirection;
	private String thingListColumn2;
	private String thingListColumn3;
	private String thingListColumn4;
	private String thingListColumn5;
	private String thingListColumn6;
	private String thingListColumn7;
	private String thingListColumn8;
	private String thingListnavTarget;
	private String thingPageHeaderInfo1;
	private String thingPageHeaderInfo2;
	private String thingPageHeaderInfo3;
	private String thingPageBasicsDataEnable;
	private String thingPageColumn1Info1;
	private String thingPageColumn1Info2;
	private String thingPageColumn1Info3;
	private String thingPageColumn1Info4;
	private String thingPageColumn1Info5;
	private String thingPageColumn1Info6;
	private String thingPageColumn1Info7;
	private String thingPageColumn1Info8;
	private String thingPageColumn1Info9;
	private String thingPageColumn2Info1;
	private String thingPageColumn2Info2;
	private String thingPageColumn2Info3;
	private String thingPageColumn2Info4;
	private String thingPageColumn2Info5;
	private String thingPageColumn2Info6;
	
	public String getBasicInfoProjectName() {
		return basicInfoProjectName;
	}
	public void setBasicInfoProjectName(String basicInfoProjectName) {
		this.basicInfoProjectName = basicInfoProjectName;
	}
	public String getBasicInfoNamespace() {
		return basicInfoNamespace;
	}
	public void setBasicInfoNamespace(String basicInfoNamespace) {
		this.basicInfoNamespace = basicInfoNamespace;
	}
	public String getBasicInfoTitle() {
		return basicInfoTitle;
	}
	public void setBasicInfoTitle(String basicInfoTitle) {
		this.basicInfoTitle = basicInfoTitle;
	}
	public String getSelectPageThingListEnable() {
		return selectPageThingListEnable;
	}
	public void setSelectPageThingListEnable(String selectPageThingListEnable) {
		this.selectPageThingListEnable = selectPageThingListEnable;
	}
	public String getSelectPageThingPageEnable() {
		return selectPageThingPageEnable;
	}
	public void setSelectPageThingPageEnable(String selectPageThingPageEnable) {
		this.selectPageThingPageEnable = selectPageThingPageEnable;
	}
	public String getSelectPageAnalysisPageEnable() {
		return selectPageAnalysisPageEnable;
	}
	public void setSelectPageAnalysisPageEnable(String selectPageAnalysisPageEnable) {
		this.selectPageAnalysisPageEnable = selectPageAnalysisPageEnable;
	}
	public String getLandingPageThingListOnMapCheckBox() {
		return landingPageThingListOnMapCheckBox;
	}
	public void setLandingPageThingListOnMapCheckBox(String landingPageThingListOnMapCheckBox) {
		this.landingPageThingListOnMapCheckBox = landingPageThingListOnMapCheckBox;
	}
	public String getLandingPageThingListOnMapInfo1() {
		return landingPageThingListOnMapInfo1;
	}
	public void setLandingPageThingListOnMapInfo1(String landingPageThingListOnMapInfo1) {
		this.landingPageThingListOnMapInfo1 = landingPageThingListOnMapInfo1;
	}
	public String getLandingPageThingListOnMapInfo2() {
		return landingPageThingListOnMapInfo2;
	}
	public void setLandingPageThingListOnMapInfo2(String landingPageThingListOnMapInfo2) {
		this.landingPageThingListOnMapInfo2 = landingPageThingListOnMapInfo2;
	}
	public String getLandingPageThingListOnMapSortField() {
		return landingPageThingListOnMapSortField;
	}
	public void setLandingPageThingListOnMapSortField(String landingPageThingListOnMapSortField) {
		this.landingPageThingListOnMapSortField = landingPageThingListOnMapSortField;
	}
	public String getLandingPageThingListOnMapSortDirection() {
		return landingPageThingListOnMapSortDirection;
	}
	public void setLandingPageThingListOnMapSortDirection(String landingPageThingListOnMapSortDirection) {
		this.landingPageThingListOnMapSortDirection = landingPageThingListOnMapSortDirection;
	}
	public String getLandingPageSingleCardTitle() {
		return landingPageSingleCardTitle;
	}
	public void setLandingPageSingleCardTitle(String landingPageSingleCardTitle) {
		this.landingPageSingleCardTitle = landingPageSingleCardTitle;
	}
	public String getLandingPageSingleCardHeaderInfo1() {
		return landingPageSingleCardHeaderInfo1;
	}
	public void setLandingPageSingleCardHeaderInfo1(String landingPageSingleCardHeaderInfo1) {
		this.landingPageSingleCardHeaderInfo1 = landingPageSingleCardHeaderInfo1;
	}
	public String getLandingPageSingleCardHeaderInfo2() {
		return landingPageSingleCardHeaderInfo2;
	}
	public void setLandingPageSingleCardHeaderInfo2(String landingPageSingleCardHeaderInfo2) {
		this.landingPageSingleCardHeaderInfo2 = landingPageSingleCardHeaderInfo2;
	}
	public String getLandingPageSingleCardHeaderNavigation() {
		return landingPageSingleCardHeaderNavigation;
	}
	public void setLandingPageSingleCardHeaderNavigation(String landingPageSingleCardHeaderNavigation) {
		this.landingPageSingleCardHeaderNavigation = landingPageSingleCardHeaderNavigation;
	}
	public String getLandingPageSingleCardEventEnable() {
		return landingPageSingleCardEventEnable;
	}
	public void setLandingPageSingleCardEventEnable(String landingPageSingleCardEventEnable) {
		this.landingPageSingleCardEventEnable = landingPageSingleCardEventEnable;
	}
	public String getLandingPageSingleCardEventTitle() {
		return landingPageSingleCardEventTitle;
	}
	public void setLandingPageSingleCardEventTitle(String landingPageSingleCardEventTitle) {
		this.landingPageSingleCardEventTitle = landingPageSingleCardEventTitle;
	}
	public String getLandingPageSingleCardContactEnable() {
		return landingPageSingleCardContactEnable;
	}
	public void setLandingPageSingleCardContactEnable(String landingPageSingleCardContactEnable) {
		this.landingPageSingleCardContactEnable = landingPageSingleCardContactEnable;
	}
	public String getLandingPageSingleCardContactTitle() {
		return landingPageSingleCardContactTitle;
	}
	public void setLandingPageSingleCardContactTitle(String landingPageSingleCardContactTitle) {
		this.landingPageSingleCardContactTitle = landingPageSingleCardContactTitle;
	}
	public String getLandingPageSingleCardContactInfo1() {
		return landingPageSingleCardContactInfo1;
	}
	public void setLandingPageSingleCardContactInfo1(String landingPageSingleCardContactInfo1) {
		this.landingPageSingleCardContactInfo1 = landingPageSingleCardContactInfo1;
	}
	public String getLandingPageSingleCardContactInfo2() {
		return landingPageSingleCardContactInfo2;
	}
	public void setLandingPageSingleCardContactInfo2(String landingPageSingleCardContactInfo2) {
		this.landingPageSingleCardContactInfo2 = landingPageSingleCardContactInfo2;
	}
	public String getLandingPageSingleCardContactInfo3() {
		return landingPageSingleCardContactInfo3;
	}
	public void setLandingPageSingleCardContactInfo3(String landingPageSingleCardContactInfo3) {
		this.landingPageSingleCardContactInfo3 = landingPageSingleCardContactInfo3;
	}
	public String getLandingPageSingleCardFooterText() {
		return landingPageSingleCardFooterText;
	}
	public void setLandingPageSingleCardFooterText(String landingPageSingleCardFooterText) {
		this.landingPageSingleCardFooterText = landingPageSingleCardFooterText;
	}
	public String getLandingPageSingleCardFooterNavTarget() {
		return landingPageSingleCardFooterNavTarget;
	}
	public void setLandingPageSingleCardFooterNavTarget(String landingPageSingleCardFooterNavTarget) {
		this.landingPageSingleCardFooterNavTarget = landingPageSingleCardFooterNavTarget;
	}
	public String getLandingPageMultiCardTitle() {
		return landingPageMultiCardTitle;
	}
	public void setLandingPageMultiCardTitle(String landingPageMultiCardTitle) {
		this.landingPageMultiCardTitle = landingPageMultiCardTitle;
	}
	public String getLandingPageMultiCardInfo1() {
		return landingPageMultiCardInfo1;
	}
	public void setLandingPageMultiCardInfo1(String landingPageMultiCardInfo1) {
		this.landingPageMultiCardInfo1 = landingPageMultiCardInfo1;
	}
	public String getLandingPageMultiCardInfo2() {
		return landingPageMultiCardInfo2;
	}
	public void setLandingPageMultiCardInfo2(String landingPageMultiCardInfo2) {
		this.landingPageMultiCardInfo2 = landingPageMultiCardInfo2;
	}
	public String getLandingPageMultiCardListNavTarget() {
		return landingPageMultiCardListNavTarget;
	}
	public void setLandingPageMultiCardListNavTarget(String landingPageMultiCardListNavTarget) {
		this.landingPageMultiCardListNavTarget = landingPageMultiCardListNavTarget;
	}
	public String getLandingPageMultiCardFooterText() {
		return landingPageMultiCardFooterText;
	}
	public void setLandingPageMultiCardFooterText(String landingPageMultiCardFooterText) {
		this.landingPageMultiCardFooterText = landingPageMultiCardFooterText;
	}
	public String getLandingPageMultiCardFooterNavTarget() {
		return landingPageMultiCardFooterNavTarget;
	}
	public void setLandingPageMultiCardFooterNavTarget(String landingPageMultiCardFooterNavTarget) {
		this.landingPageMultiCardFooterNavTarget = landingPageMultiCardFooterNavTarget;
	}
	public String getThingListTitle() {
		return thingListTitle;
	}
	public void setThingListTitle(String thingListTitle) {
		this.thingListTitle = thingListTitle;
	}
	public String getThingListDefaultSortField() {
		return thingListDefaultSortField;
	}
	public void setThingListDefaultSortField(String thingListDefaultSortField) {
		this.thingListDefaultSortField = thingListDefaultSortField;
	}
	public String getThingListSortDirection() {
		return thingListSortDirection;
	}
	public void setThingListSortDirection(String thingListSortDirection) {
		this.thingListSortDirection = thingListSortDirection;
	}
	public String getThingListColumn2() {
		return thingListColumn2;
	}
	public void setThingListColumn2(String thingListColumn2) {
		this.thingListColumn2 = thingListColumn2;
	}
	public String getThingListColumn3() {
		return thingListColumn3;
	}
	public void setThingListColumn3(String thingListColumn3) {
		this.thingListColumn3 = thingListColumn3;
	}
	public String getThingListColumn4() {
		return thingListColumn4;
	}
	public void setThingListColumn4(String thingListColumn4) {
		this.thingListColumn4 = thingListColumn4;
	}
	public String getThingListColumn5() {
		return thingListColumn5;
	}
	public void setThingListColumn5(String thingListColumn5) {
		this.thingListColumn5 = thingListColumn5;
	}
	public String getThingListColumn6() {
		return thingListColumn6;
	}
	public void setThingListColumn6(String thingListColumn6) {
		this.thingListColumn6 = thingListColumn6;
	}
	public String getThingListColumn7() {
		return thingListColumn7;
	}
	public void setThingListColumn7(String thingListColumn7) {
		this.thingListColumn7 = thingListColumn7;
	}
	public String getThingListColumn8() {
		return thingListColumn8;
	}
	public void setThingListColumn8(String thingListColumn8) {
		this.thingListColumn8 = thingListColumn8;
	}
	public String getThingListnavTarget() {
		return thingListnavTarget;
	}
	public void setThingListnavTarget(String thingListnavTarget) {
		this.thingListnavTarget = thingListnavTarget;
	}
	public String getThingPageHeaderInfo1() {
		return thingPageHeaderInfo1;
	}
	public void setThingPageHeaderInfo1(String thingPageHeaderInfo1) {
		this.thingPageHeaderInfo1 = thingPageHeaderInfo1;
	}
	public String getThingPageHeaderInfo2() {
		return thingPageHeaderInfo2;
	}
	public void setThingPageHeaderInfo2(String thingPageHeaderInfo2) {
		this.thingPageHeaderInfo2 = thingPageHeaderInfo2;
	}
	public String getThingPageHeaderInfo3() {
		return thingPageHeaderInfo3;
	}
	public void setThingPageHeaderInfo3(String thingPageHeaderInfo3) {
		this.thingPageHeaderInfo3 = thingPageHeaderInfo3;
	}
	public String getThingPageBasicsDataEnable() {
		return thingPageBasicsDataEnable;
	}
	public void setThingPageBasicsDataEnable(String thingPageBasicsDataEnable) {
		this.thingPageBasicsDataEnable = thingPageBasicsDataEnable;
	}
	public String getThingPageColumn1Info1() {
		return thingPageColumn1Info1;
	}
	public void setThingPageColumn1Info1(String thingPageColumn1Info1) {
		this.thingPageColumn1Info1 = thingPageColumn1Info1;
	}
	public String getThingPageColumn1Info2() {
		return thingPageColumn1Info2;
	}
	public void setThingPageColumn1Info2(String thingPageColumn1Info2) {
		this.thingPageColumn1Info2 = thingPageColumn1Info2;
	}
	public String getThingPageColumn1Info3() {
		return thingPageColumn1Info3;
	}
	public void setThingPageColumn1Info3(String thingPageColumn1Info3) {
		this.thingPageColumn1Info3 = thingPageColumn1Info3;
	}
	public String getThingPageColumn1Info4() {
		return thingPageColumn1Info4;
	}
	public void setThingPageColumn1Info4(String thingPageColumn1Info4) {
		this.thingPageColumn1Info4 = thingPageColumn1Info4;
	}
	public String getThingPageColumn1Info5() {
		return thingPageColumn1Info5;
	}
	public void setThingPageColumn1Info5(String thingPageColumn1Info5) {
		this.thingPageColumn1Info5 = thingPageColumn1Info5;
	}
	public String getThingPageColumn1Info6() {
		return thingPageColumn1Info6;
	}
	public void setThingPageColumn1Info6(String thingPageColumn1Info6) {
		this.thingPageColumn1Info6 = thingPageColumn1Info6;
	}
	public String getThingPageColumn1Info7() {
		return thingPageColumn1Info7;
	}
	public void setThingPageColumn1Info7(String thingPageColumn1Info7) {
		this.thingPageColumn1Info7 = thingPageColumn1Info7;
	}
	public String getThingPageColumn1Info8() {
		return thingPageColumn1Info8;
	}
	public void setThingPageColumn1Info8(String thingPageColumn1Info8) {
		this.thingPageColumn1Info8 = thingPageColumn1Info8;
	}
	public String getThingPageColumn1Info9() {
		return thingPageColumn1Info9;
	}
	public void setThingPageColumn1Info9(String thingPageColumn1Info9) {
		this.thingPageColumn1Info9 = thingPageColumn1Info9;
	}
	public String getThingPageColumn2Info1() {
		return thingPageColumn2Info1;
	}
	public void setThingPageColumn2Info1(String thingPageColumn2Info1) {
		this.thingPageColumn2Info1 = thingPageColumn2Info1;
	}
	public String getThingPageColumn2Info2() {
		return thingPageColumn2Info2;
	}
	public void setThingPageColumn2Info2(String thingPageColumn2Info2) {
		this.thingPageColumn2Info2 = thingPageColumn2Info2;
	}
	public String getThingPageColumn2Info3() {
		return thingPageColumn2Info3;
	}
	public void setThingPageColumn2Info3(String thingPageColumn2Info3) {
		this.thingPageColumn2Info3 = thingPageColumn2Info3;
	}
	public String getThingPageColumn2Info4() {
		return thingPageColumn2Info4;
	}
	public void setThingPageColumn2Info4(String thingPageColumn2Info4) {
		this.thingPageColumn2Info4 = thingPageColumn2Info4;
	}
	public String getThingPageColumn2Info5() {
		return thingPageColumn2Info5;
	}
	public void setThingPageColumn2Info5(String thingPageColumn2Info5) {
		this.thingPageColumn2Info5 = thingPageColumn2Info5;
	}
	public String getThingPageColumn2Info6() {
		return thingPageColumn2Info6;
	}
	public void setThingPageColumn2Info6(String thingPageColumn2Info6) {
		this.thingPageColumn2Info6 = thingPageColumn2Info6;
	}
	public String getThingPageColumn2Info7() {
		return thingPageColumn2Info7;
	}
	public void setThingPageColumn2Info7(String thingPageColumn2Info7) {
		this.thingPageColumn2Info7 = thingPageColumn2Info7;
	}
	public String getThingPageColumn2Info8() {
		return thingPageColumn2Info8;
	}
	public void setThingPageColumn2Info8(String thingPageColumn2Info8) {
		this.thingPageColumn2Info8 = thingPageColumn2Info8;
	}
	public String getThingPageColumn2Info9() {
		return thingPageColumn2Info9;
	}
	public void setThingPageColumn2Info9(String thingPageColumn2Info9) {
		this.thingPageColumn2Info9 = thingPageColumn2Info9;
	}
	public String getThingPageColumn3Info1() {
		return thingPageColumn3Info1;
	}
	public void setThingPageColumn3Info1(String thingPageColumn3Info1) {
		this.thingPageColumn3Info1 = thingPageColumn3Info1;
	}
	public String getThingPageColumn3Info2() {
		return thingPageColumn3Info2;
	}
	public void setThingPageColumn3Info2(String thingPageColumn3Info2) {
		this.thingPageColumn3Info2 = thingPageColumn3Info2;
	}
	public String getThingPageColumn3Info3() {
		return thingPageColumn3Info3;
	}
	public void setThingPageColumn3Info3(String thingPageColumn3Info3) {
		this.thingPageColumn3Info3 = thingPageColumn3Info3;
	}
	public String getThingPageColumn3Info4() {
		return thingPageColumn3Info4;
	}
	public void setThingPageColumn3Info4(String thingPageColumn3Info4) {
		this.thingPageColumn3Info4 = thingPageColumn3Info4;
	}
	public String getThingPageColumn3Info5() {
		return thingPageColumn3Info5;
	}
	public void setThingPageColumn3Info5(String thingPageColumn3Info5) {
		this.thingPageColumn3Info5 = thingPageColumn3Info5;
	}
	public String getThingPageColumn3Info6() {
		return thingPageColumn3Info6;
	}
	public void setThingPageColumn3Info6(String thingPageColumn3Info6) {
		this.thingPageColumn3Info6 = thingPageColumn3Info6;
	}
	public String getThingPageColumn3Info7() {
		return thingPageColumn3Info7;
	}
	public void setThingPageColumn3Info7(String thingPageColumn3Info7) {
		this.thingPageColumn3Info7 = thingPageColumn3Info7;
	}
	public String getThingPageColumn3Info8() {
		return thingPageColumn3Info8;
	}
	public void setThingPageColumn3Info8(String thingPageColumn3Info8) {
		this.thingPageColumn3Info8 = thingPageColumn3Info8;
	}
	public String getThingPageColumn3Info9() {
		return thingPageColumn3Info9;
	}
	public void setThingPageColumn3Info9(String thingPageColumn3Info9) {
		this.thingPageColumn3Info9 = thingPageColumn3Info9;
	}
	public String getThingPageMeasuredValuesEnable() {
		return thingPageMeasuredValuesEnable;
	}
	public void setThingPageMeasuredValuesEnable(String thingPageMeasuredValuesEnable) {
		this.thingPageMeasuredValuesEnable = thingPageMeasuredValuesEnable;
	}
	public String getThingPageEventsEnable() {
		return thingPageEventsEnable;
	}
	public void setThingPageEventsEnable(String thingPageEventsEnable) {
		this.thingPageEventsEnable = thingPageEventsEnable;
	}
	public String getThingPageTimelineEnable() {
		return thingPageTimelineEnable;
	}
	public void setThingPageTimelineEnable(String thingPageTimelineEnable) {
		this.thingPageTimelineEnable = thingPageTimelineEnable;
	}
	public String getAnalysisPageDefaultTimePeriod() {
		return analysisPageDefaultTimePeriod;
	}
	public void setAnalysisPageDefaultTimePeriod(String analysisPageDefaultTimePeriod) {
		this.analysisPageDefaultTimePeriod = analysisPageDefaultTimePeriod;
	}
	public String getAnalysisPageTimeSliderEnable() {
		return analysisPageTimeSliderEnable;
	}
	public void setAnalysisPageTimeSliderEnable(String analysisPageTimeSliderEnable) {
		this.analysisPageTimeSliderEnable = analysisPageTimeSliderEnable;
	}
	private String thingPageColumn2Info7;
	private String thingPageColumn2Info8;
	private String thingPageColumn2Info9;
	private String thingPageColumn3Info1;
	private String thingPageColumn3Info2;
	private String thingPageColumn3Info3;
	private String thingPageColumn3Info4;
	private String thingPageColumn3Info5;
	private String thingPageColumn3Info6;
	private String thingPageColumn3Info7;
	private String thingPageColumn3Info8;
	private String thingPageColumn3Info9;
	private String thingPageMeasuredValuesEnable;
	private String thingPageEventsEnable;
	private String thingPageTimelineEnable;
	private String analysisPageDefaultTimePeriod;
	private String analysisPageTimeSliderEnable;
	
}
