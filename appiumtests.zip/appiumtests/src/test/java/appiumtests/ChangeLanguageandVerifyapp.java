package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;

public class ChangeLanguageandVerifyapp {
	
	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
	
		Thread.sleep(5000);
		changeLangauge();
		//LaunchAppandVerifyHomepage app2 = new LaunchAppandVerifyHomepage();
		Thread.sleep(5000);
	
		
	}
		
		public static void changeLangauge() throws MalformedURLException, InterruptedException 
		{
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability("deviceName", "Emulator123"); //Emulator123
			cap.setCapability("platformName", "Android");
			cap.setCapability("platformVersion", "9"); //9
			cap.setCapability("appPackage", "com.android.settings");
			cap.setCapability("appActivity", "com.android.settings.Settings");
			
			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			
			driver = new AppiumDriver<MobileElement>(url,cap);
			Thread.sleep(3000);
			System.out.println("Settings opened");	
			Thread.sleep(8000);
			 AndroidElement list = (AndroidElement)driver.findElement(By.id("android:id/title"));
			 
			 driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))"
					 +".scrollIntoView(new UiSelector().textMatches(\""+"System"+"\").instance(0))"));
			 Thread.sleep(3000);
			 
			 driver.findElement(By.xpath("//android.widget.TextView[@text='System']")).click();
			 
			 Thread.sleep(3000);
			 System.out.println("scrolled and clicked on System");
			 
			 
			 
			 
			 
			/*MobileElement listitem = (MobileElement)driver.findElement(MobileBy.AndroidUIAutomator
					 ("new UiScrollable(new UiSelector()).scrollIntoView("
					 		+ "new UiSelector().description(\"System\"));"));
			 Thread.sleep(4000);
			// driver.findElement(By.xpath("//android.widget.TextView[@text='System']")).click();
			 
			// Thread.sleep(3000);
			System.out.println(listitem.getLocation());
			listitem.click();
			 
			 
			
			//driver.findElement(By.xpath("//android.widget.TextView[@text='Display']")).click();
			/*MobileElement element = driver.findElement(By.xpath("//android.widget.TextView[@text='system']"));
			TouchActions action = new TouchActions(driver);
			MobileElement element = driver.findElement(By.xpath("//android.widget.TextView[@text='system']"));
			action.scroll(element, 10, 100);
			action.perform();
			element.click();
			driver.findElementByCssSelector("new UiScrollable(new UiSelector()).scrollIntoView(text(\"myText")));
	*/
			
			


		}}
