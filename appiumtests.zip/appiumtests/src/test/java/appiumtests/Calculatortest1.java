package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
//import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
//import io.appium.java_client.android.AndroidDriver;

public class Calculatortest1 {
	//WebDriver driver;
	//static AndroidDriver<MobileElement> driver;
	static AppiumDriver<MobileElement> driver;
	public static void main(String[] args) {
		try {
			openCalculator();
		} catch (Exception exp) {
			System.out.println(exp.getCause());
			System.out.println(exp.getMessage());
			exp.printStackTrace();
		}
		}
	
	public static void openCalculator() throws MalformedURLException
	{
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("deviceName", "SM-G550FY");
		cap.setCapability("udid", "42005646c6626337");
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "7.1.1");
		
		cap.setCapability("appPackage", "com.sec.android.app.popupcalculator");
		cap.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		
		driver = new AppiumDriver<MobileElement>(url,cap);
		
		System.out.println("application started");	
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		System.out.println("Calculate sum of two numbers");
		
		MobileElement two = driver.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_02"));
		
		MobileElement plus = driver.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_add"));
		
		MobileElement five = driver.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_05"));
		
		MobileElement equals = driver.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_equal"));
		MobileElement result = driver.findElement(By.className("android.widget.EditText"));
		
		two.click();
		plus.click();
		five.click();
		equals.click();
		String res = result.getText();
		System.out.println(res);
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Locate elements using By.name() to enter data and click +/= buttons
		/*driver.findElement(By.name("1")).click();
		driver.findElement(By.name("+")).click();
		driver.findElement(By.name("2")).click();
		driver.findElement(By.name("=")).click();*/
		
		System.out.println("completed.....");
	}
}
