package com.sap.iotwebide.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class ApplicationMainpage extends BasePage {
	
	
	@FindBy(xpath ="//input[@type='search']")
	public WebElement inputSearchbox;
	
	@FindBy(xpath ="//button[@title='sortBy']//span[1]")
	public WebElement buttonSortby;
	
	@FindBy(xpath ="//button[@title='sortBy']")
	public WebElement buttonSortby1;
	
	@FindBy(xpath ="//span[text()='Landing Page']")
	public WebElement landingpageheader;
	
	@FindBy(xpath ="//div[@class='sapMSLITitleOnly']")
	public List<WebElement> listofitems;
	
	@FindBy(xpath ="//*[@id='__item35-selectSingle-Button']")
	public WebElement ascendingRadiobutton;
	
	@FindBy(xpath ="//*[@id='__item36-selectSingle-Button']")
	public WebElement descendingRadiobutton;
	
	@FindBy(xpath ="//span[bdi[text()='OK']]")
	public WebElement okbutton;
	
	@FindBy(xpath ="//span[bdi[text()='Cancel']]")
	public WebElement cancelbutton;
	
	
		
		public ApplicationMainpage(WebDriver driver) {
		super(driver);
		}

		@Override
		public boolean hasPageLoaded() {
			// TODO Auto-generated method stub
			return false;
		}

}
