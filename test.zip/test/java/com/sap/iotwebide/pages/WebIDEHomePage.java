package com.sap.iotwebide.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.sap.iot.utilities.BasePage;

public class WebIDEHomePage extends BasePage{

	public WebIDEHomePage(WebDriver driver) {
		super(driver);
		//Assert.assertEquals(hasPageLoaded(), true);
	}
	
	@FindBy(xpath="//button[@title='Home']//span")
	public WebElement homebutton;
	
	@FindBy(xpath="//span[@title='Error']")
	public WebElement popupError;

	@FindBy(xpath="//a[@title='Close']")
	public WebElement buttonOnPopup;

	@FindBy(xpath="//button[@title='Preferences']")
	public WebElement buttonPreferences;

	@FindBy(id="optionalPlugins")
	public WebElement buttonPlugins;

	@FindBy(xpath="//button[@title='Development']")
	public WebElement buttonWorkspace1;
	
	@FindBy(xpath="//button[@title='Development' and @type='button']")
	public WebElement buttonWorkspace;
	
	@FindBy(xpath="//button[@title='Run (Alt+F5)']//span")
	public WebElement runbutton;

	@FindBy(xpath="//ul[@class='sapUiTreeChildrenNodes']/li")
	public List<WebElement> generatedProjectsList;

	@FindBy(xpath="//div[text()='Deploy']")
	public WebElement contextMenuDeploy;
	
	@FindBy(xpath="(//span[text()='com.sap.iot'])[1]")
	public WebElement Namespacemenu;

	@FindBy(xpath="//div[text()='Deploy to SAP HANA Cloud Platform']")
	public WebElement contextMenuDeployToHCP;

	/*	@FindBy(id="optionalplugin--repositoryDropdownBox-input")
	public WebElement inputRequiredPlugin;*/

	@FindBy(id="optionalplugin--repositoryDropdownBox-icon")
	public WebElement iconDropDownPluginSelect;

	@FindBy(xpath="//span[text()='IoT Repository']")
	public WebElement IoTRepositoryPluginDropDown;

	@FindBy(xpath="//span[text()='SAP Plugins']")
	public WebElement SAPPluginDropDown;

	@FindBy(xpath="//span[text()='IOT']/following-sibling::button")
	public WebElement buttonIOTPluginEnable;

	@FindBy(xpath="//span[text()='IoT UI plugins Repository']/following-sibling::button")
	public WebElement buttonIoTUIPluginsRepositoryEnable;

	@FindBy(id="applyButton")
	public WebElement buttonSavePlugin;

	@FindBy(id="saveOptionalPluginsDialog--refreshButton")
	public WebElement buttonRefreshPlugin;

	/*@FindBy(xpath="//li[@id='menubarapplicationMenu-file']/span[text()='File']")
	public WebElement menuFile;
	 */
	//@FindBy(linkText="File")
	//public WebElement menuFile;
	
	@FindBy(id="menubarapplicationMenu-file")
	public WebElement menuFile; //2/23/2021

	@FindBy(xpath="//li[contains(@id, 'file.new')]")
	public WebElement menuFileNewButton;

	@FindBy(xpath="//li[@title='Project from Template (Ctrl+Alt+Shift+O)']")
	public WebElement menuFileNewProjectFromTemplate;

	@FindBy(xpath="//input[@value='Featured']/preceding-sibling::div")
	public WebElement iconForSelectingInternetOfThingsForNewProject;

	@FindBy(xpath="//span[text()='Internet Of Things']")
	public WebElement dropdownRequiredTemplateSelection;

	@FindBy(xpath="//button[text()='Next']")
	public WebElement buttonNextInTemplateSelection;

	@FindBy(xpath="//input[@title='Log on to SAP HANA Cloud Platform with your SAP ID or SCN credentials']")
	public WebElement inputLogOnToSAP;

	@FindBy(xpath="//input[@title='Enter password']")
	public WebElement inputLogOnPassword;

	@FindBy(xpath="//button[text()='Login']")
	public WebElement buttonLogin;

	@FindBy(xpath="//button[text()='Deploy']")
	public WebElement buttonDeploy;

	@FindBy(linkText="Open the active version of the application")
	public WebElement linkOpenApplication;

	@FindBy(xpath="//span[text()='New Project from Template']")
	public WebElement newProjectfromTemplate ;
	
	public void goToPluginsSection(){
		wait.until(ExpectedConditions.visibilityOf(buttonPreferences));
		buttonPreferences.click();
		//wait.until(ExpectedConditions.visibilityOf(buttonPlugins));
		//buttonPlugins.click();
	}

	public void selectSAPPluginAsRepository(){
		wait.until(ExpectedConditions.visibilityOf(iconDropDownPluginSelect));
		iconDropDownPluginSelect.click();
		wait.until(ExpectedConditions.visibilityOf(SAPPluginDropDown));
		SAPPluginDropDown.click();
	}

	public void selectIoTRepositoryAsRepository(){
		wait.until(ExpectedConditions.visibilityOf(iconDropDownPluginSelect));
		iconDropDownPluginSelect.click();
		wait.until(ExpectedConditions.visibilityOf(IoTRepositoryPluginDropDown));
		IoTRepositoryPluginDropDown.click();
	}

	public void enableLocalTestingPlugin(){
		wait.until(ExpectedConditions.visibilityOf(buttonIOTPluginEnable));
		//if local plugin is not enabled, then click on it
		if(buttonIOTPluginEnable.getAttribute("aria-pressed").equals("false")){
			buttonIOTPluginEnable.click();		
		}
		//if enabled, then disable the plugin and then enable again
		else{
			buttonIOTPluginEnable.click();	
			wait.until(ExpectedConditions.visibilityOf(buttonSavePlugin));
			buttonSavePlugin.click();
			wait.until(ExpectedConditions.visibilityOf(buttonRefreshPlugin));
			buttonRefreshPlugin.click();
			goToPluginsSection();
			selectIoTRepositoryAsRepository();
			wait.until(ExpectedConditions.visibilityOf(buttonIOTPluginEnable));
			buttonIOTPluginEnable.click();
		}		
		wait.until(ExpectedConditions.visibilityOf(buttonSavePlugin));
		buttonSavePlugin.click();
		wait.until(ExpectedConditions.visibilityOf(buttonRefreshPlugin));
		buttonRefreshPlugin.click();
	}

	public void enableSAPIoTPlugin(){
		wait.until(ExpectedConditions.visibilityOf(buttonIoTUIPluginsRepositoryEnable));
		//if  plugin is not enabled, then click on it
		if(buttonIoTUIPluginsRepositoryEnable.getAttribute("aria-pressed").equals("false")){
			buttonIoTUIPluginsRepositoryEnable.click();		
		}
		//if enabled, then disable the plugin and then enable again
		else{
			buttonIoTUIPluginsRepositoryEnable.click();	
			wait.until(ExpectedConditions.visibilityOf(buttonSavePlugin));
			buttonSavePlugin.click();
			wait.until(ExpectedConditions.visibilityOf(buttonRefreshPlugin));
			buttonRefreshPlugin.click();
			goToPluginsSection();
			selectSAPPluginAsRepository();
			wait.until(ExpectedConditions.visibilityOf(buttonIoTUIPluginsRepositoryEnable));
			buttonIoTUIPluginsRepositoryEnable.click();
		}		
		wait.until(ExpectedConditions.visibilityOf(buttonSavePlugin));
		buttonSavePlugin.click();
		wait.until(ExpectedConditions.visibilityOf(buttonRefreshPlugin));
		buttonRefreshPlugin.click();
	}

	public void disableLocalTestingPlugin(){
		wait.until(ExpectedConditions.visibilityOf(buttonIOTPluginEnable));
		//if local plugin is  enabled, then click on it to disable
		if(buttonIOTPluginEnable.getAttribute("aria-pressed").equals("true")){
			buttonIOTPluginEnable.click();		
		}	
		wait.until(ExpectedConditions.visibilityOf(buttonSavePlugin));
		buttonSavePlugin.click();
		wait.until(ExpectedConditions.visibilityOf(buttonRefreshPlugin));
		buttonRefreshPlugin.click();
	}

	public void disableSAPIoTPlugin(){
		wait.until(ExpectedConditions.visibilityOf(buttonIoTUIPluginsRepositoryEnable));
		//if local plugin is  enabled, then click on it to disable
		if(buttonIoTUIPluginsRepositoryEnable.getAttribute("aria-pressed").equals("true")){
			buttonIoTUIPluginsRepositoryEnable.click();		
		}	
		wait.until(ExpectedConditions.visibilityOf(buttonSavePlugin));
		buttonSavePlugin.click();
		wait.until(ExpectedConditions.visibilityOf(buttonRefreshPlugin));
		buttonRefreshPlugin.click();
	}

	public void createNewProjectFromIoTTemplate(){
		
		
		Actions act =  new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath("//span[text()='New Project from Template']"))).click().perform();
		
		/*wait.until(ExpectedConditions.visibilityOf(menuFile));
		wait.until(ExpectedConditions.elementToBeClickable(menuFile));
		//Actions act = new Actions(driver);
		//act.moveToElement(menuFile).click().perform();
		menuFile.click();
		wait.until(ExpectedConditions.visibilityOf(menuFileNewButton));
		menuFileNewButton.click();
		wait(10);
		wait.until(ExpectedConditions.visibilityOf(menuFileNewProjectFromTemplate));
		menuFileNewProjectFromTemplate.click();*/
	}

	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		wait(100);
		wait.until(ExpectedConditions.elementToBeClickable(menuFile));
		if(menuFile.isDisplayed())
			return true;
		else
			return false;
	}
}
