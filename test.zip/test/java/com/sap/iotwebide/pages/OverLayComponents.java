package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class OverLayComponents extends BasePage{

	
	@FindBy(xpath="//button[@title='Thing List ']")
	public WebElement breadCrumbThingList;
	
	@FindBy(xpath="//button[@title='Thing Page']")
	public WebElement breadCrumbThingPage;
	
	@FindBy(xpath="//button[@title='Analysis Page']")
	public WebElement breadCrumbAnalysisPage;


	public OverLayComponents(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}

}
