package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppPermission {
	
	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
	
		
		opensetting();
	}
		
		
		public static void opensetting() throws MalformedURLException, InterruptedException 
		{
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability("deviceName", "Emulator123"); //Emulator123
			cap.setCapability("platformName", "Android");
			cap.setCapability("platformVersion", "9"); //9
			cap.setCapability("appPackage", "com.android.settings");
			cap.setCapability("appActivity", "com.android.settings.Settings");
			
			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			
			driver = new AppiumDriver<MobileElement>(url,cap);
			Thread.sleep(3000);
			System.out.println("Settings opened");	
			Thread.sleep(5000);
			driver.findElement(By.xpath("//android.widget.TextView[@text='Apps & notifications']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//android.widget.TextView[@text='See all 34 apps']")).click();
			Thread.sleep(8000);
			driver.findElement(By.xpath("//android.widget.TextView[@text='Camera']")).click();
			Thread.sleep(6000);
			driver.findElement(By.xpath("//android.widget.TextView[@text='Permissions']")).click();
			Thread.sleep(5000);
			boolean ele = driver.findElementByXPath("//android.widget.TextView[@text='Camera']").isSelected();
			if(ele)
			{
				System.out.println("Camera toggle displayed");
			}
			else
			{
				System.out.println("Camera toggle not displayed");
			}
			boolean ele1 = driver.findElementByXPath("//android.widget.TextView[@text='Location']").isDisplayed();
			if(ele1)
			{
				System.out.println("Location toggle displayed");
			}
			else
			{
				System.out.println("Location toggle not displayed");
			}
			
			boolean ele2 = driver.findElementByXPath("//android.widget.TextView[@text='Microphone']").isDisplayed();
			if(ele2)
			{
				System.out.println("Microphone toggle displayed");
			}
			else
			{
				System.out.println("Microphone toggle not displayed");
			}
			boolean ele3 = driver.findElementByXPath("//android.widget.TextView[@text='Storage']").isDisplayed();
			if(ele3)
			{
				System.out.println("Storage toggle displayed");
			}
			else
			{
				System.out.println("Storage toggle not displayed");
			}
			
	}

}
