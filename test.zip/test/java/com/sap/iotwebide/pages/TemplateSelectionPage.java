package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class TemplateSelectionPage extends BasePage{

	public TemplateSelectionPage(WebDriver driver) {
		super(driver);
		//Assert.assertEquals(hasPageLoaded(), true, this.getClass().getSimpleName()+" has not loaded");
		// TODO Auto-generated constructor stub
	}
	
	
	@FindBy(xpath="//button[text()='Template Selection']")
	public WebElement breadCrumbTemplateSelection;
	
	@FindBy(xpath="//input[@value='Featured']/parent::div")
	public WebElement comboBoxTemplateCategory;
	
	@FindBy(xpath="//li[@title='Internet Of Things']")
	public WebElement listItemInternetOfThings;
	
	@FindBy(xpath="//span[@title='IoT Application']")
	public WebElement templateIoT;
	
	@FindBy(xpath="//button[@title='Next']")
	public WebElement buttonNext;
	
	@FindBy(xpath="//button[@aria-disabled='false' and @title='Next']")
	public WebElement buttonNextEnabled;

	@Override
	public boolean hasPageLoaded() {
		System.out.println(breadCrumbTemplateSelection.getCssValue("background-color"));
		return false;
	}

}
