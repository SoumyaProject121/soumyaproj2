package Practice;


class Sample
{
	void m1()
	{
		System.out.println("m1 method");
	}
}
public class Test2 extends Sample {
	void m1()
	{
		System.out.println("m2 method");
	}

	public static void main(String[] args) {
		
Test2 t = new Test2();
t.m1();
	}

}
