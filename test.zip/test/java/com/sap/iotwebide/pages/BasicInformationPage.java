package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class BasicInformationPage extends BasePage {
	
	@FindBy(xpath ="//span[@title='Basic Information']")
	public WebElement labelBasicInformation;
	
	@FindBy(id = "projectWizard--projectNameStep--nameField")
	public WebElement textBoxProjectName;
	
	@FindBy(xpath = "//span[text()='Namespace*']/parent::div/following-sibling::div/input")
	public WebElement textBoxNamespace;
	
	@FindBy(xpath = "//span[text()='Title*']/parent::div/following-sibling::div/input")
	public WebElement textBoxTitle;
	
	@FindBy(xpath="//button[@title='Next']")
	public WebElement buttonNext;
	
	public void basicinfoDetails(String projectname, String namespace, String title)
	{
		textBoxProjectName.sendKeys(projectname);
		textBoxNamespace.sendKeys(namespace);
		textBoxTitle.sendKeys(title);
	}
	
	public BasicInformationPage(WebDriver driver) {
		super(driver);
		//Assert.assertTrue(hasPageLoaded());
	}
	
	@Override
	public boolean hasPageLoaded(){
		if(labelBasicInformation.getText().equals("Basic Information"))
			return true;
		else
			return false;
	}
}

