package com.sap.iotwebide.pages;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class ThingPage extends BasePage{
	
	public ThingPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath="//label[text()='Information 1']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxInformation1;
	
	@FindBy(xpath="//label[text()='Information 2']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxInformation2;
	
	@FindBy(xpath="//label[text()='Information 3']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxInformation3;
	
	@FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div/div[2]/div/div/div[1]/div/div[2]/div/div[2]/div/div")
	//(xpath="//label[text()='Basic Data']/parent::div//following-sibling::div[1]//span")
	public WebElement checkboxContentBasicData;
	
	@FindBy(xpath="//label[text()='Column 1 Information 1']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info1;
	
	@FindBy(xpath="//label[text()='Column 2 Information 1']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info1;
	
	@FindBy(xpath="//label[text()='Column 3 Information 1']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info1;
	
	@FindBy(xpath="//button[@title='add' and @aria-disabled='false']/span")
	public List<WebElement> buttonAddList;
	
	@FindBy(xpath="//label[contains(text(),'Column 1 Information 1')]/parent::div//following-sibling::div[1]//input")
	public List<WebElement> dropDownColumn1List;
	
	@FindBy(xpath="//label[contains(text(),'Column 2 Information 2')]/parent::div//following-sibling::div[1]//input")
	public List<WebElement> dropDownColumn2List;
	
	@FindBy(xpath="//label[contains(text(),'Column 3 Information 3')]/parent::div//following-sibling::div[1]//input")
	public List<WebElement> dropDownColumn3List;
	
/*	
	
	@FindBy(xpath="//label[text()='Column 1 Information 2']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info2;
	
	@FindBy(xpath="//label[text()='Column 1 Information 3']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info3;
	
	@FindBy(xpath="//label[text()='Column 1 Information 4']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info4;
	
	@FindBy(xpath="//label[text()='Column 1 Information 5']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info5;
	
	@FindBy(xpath="//label[text()='Column 1 Information 6']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info6;
	
	@FindBy(xpath="//label[text()='Column 1 Information 7']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info7;
	
	@FindBy(xpath="//label[text()='Column 1 Information 8']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info8;
	
	@FindBy(xpath="//label[text()='Column 1 Information 9']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn1Info9;
	
	@FindBy(xpath="//label[text()='Column 2 Information 2']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info2;
	
	@FindBy(xpath="//label[text()='Column 2 Information 3']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info3;
	
	@FindBy(xpath="//label[text()='Column 2 Information 4']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info4;
	
	@FindBy(xpath="//label[text()='Column 2 Information 5']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info5;
	
	@FindBy(xpath="//label[text()='Column 2 Information 6']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info6;
	
	@FindBy(xpath="//label[text()='Column 2 Information 7']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info7;
	
	@FindBy(xpath="//label[text()='Column 2 Information 8']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info8;
	
	@FindBy(xpath="//label[text()='Column 2 Information 9']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn2Info9;
	
	@FindBy(xpath="//label[text()='Column 3 Information 2']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info2;
	
	@FindBy(xpath="//label[text()='Column 3 Information 3']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info3;
	
	@FindBy(xpath="//label[text()='Column 3 Information 4']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info4;
	
	@FindBy(xpath="//label[text()='Column 3 Information 5']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info5;
	
	@FindBy(xpath="//label[text()='Column 3 Information 6']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info6;
	
	@FindBy(xpath="//label[text()='Column 3 Information 7']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info7;
	
	@FindBy(xpath="//label[text()='Column 3 Information 8']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info8;
	
	@FindBy(xpath="//label[text()='Column 3 Information 9']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxColumn3Info9;*/
	
	
	@FindBy(xpath="//label[text()='Measured Values']/parent::div//following-sibling::div[1]//span")
	public WebElement checkBoxMeasureValues;
	
	@FindBy(xpath="//label[text()='Events']/parent::div//following-sibling::div[1]//span")
	public WebElement checkBoxEvents;
	
	@FindBy(xpath="//label[text()='Show Events']/parent::div//following-sibling::div[1]//input")
	public WebElement textBoxShowEvents;
	
	@FindBy(xpath="//label[text()='Timeline']/parent::div//following-sibling::div[1]//span")
	public WebElement checkBoxTimeline;
	
	@FindBy(id="__step14--finishButton")
	public WebElement buttonFinish;
	
	@FindBy(xpath="//button[@title='Next']")
			//"//button[@aria-disabled='false' and @title='Next']")
	public WebElement buttonNextEnabled;

	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}
}
