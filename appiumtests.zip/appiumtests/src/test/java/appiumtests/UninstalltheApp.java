package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class UninstalltheApp {

		static AppiumDriver<MobileElement> driver;
		public static void main(String[] args) throws MalformedURLException, InterruptedException {
			
			openSetting();

		}
		
		public static void openSetting() throws MalformedURLException, InterruptedException
		{
			
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability("deviceName", "Emulator123");
			cap.setCapability("platformName", "Android");
			cap.setCapability("platformVersion", "9");
			cap.setCapability("appPackage", "com.android.settings");
			cap.setCapability("appActivity", "com.android.settings.Settings");
			
			
			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			
			driver = new AppiumDriver<MobileElement>(url,cap);
			
			System.out.println("Settings opened");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//android.widget.TextView[@text='Apps & notifications']")).click();
			Thread.sleep(3000);
			


	}
}

