package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AndroidCalcAppExample {
	
	WebDriver driver;

	@BeforeTest
	public void setUp() throws MalformedURLException {
		
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		
		capabilities.setCapability("deviceName", "SM-G550FY");
	
		capabilities.setCapability("platformName", "Android");
		
		
		capabilities.setCapability("appPackage", "com.sec.android.app.popupcalculator");

		
		capabilities.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new RemoteWebDriver(url, capabilities);
		
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	@Test
	public void Sum() {

		System.out.println("Calculate sum of two numbers");
		//Locate elements using By.name() to enter data and click +/= buttons
		driver.findElement(By.name("1")).click();
		driver.findElement(By.name("+")).click();
		driver.findElement(By.name("2")).click();
		driver.findElement(By.name("=")).click();
		
		// Get the result text
		WebElement sumOfNumbersEle = driver.findElement(By.className("android.widget.EditText"));
		String sumOfNumbers = sumOfNumbersEle.getText();
		
		//verify if result is 3
		Assert.assertTrue(sumOfNumbers.endsWith("3"));
	}

	@AfterTest
	public void End() {
		driver.quit();
	}
}




