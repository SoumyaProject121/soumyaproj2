package com.sap.iotwebide.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class DataConnetionPage extends BasePage
{
	public DataConnetionPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath="//span[text()='Service URL']")
	public WebElement liServiceURL;
	
	/*@FindBy(xpath="//div[@ role='presentation'and  @class='sapUiTfComboIcon'][0]")
	public WebElement comboBoxIcon;*/
	
	@FindBy(xpath="//input[@placeholder='Select a system']/parent::div")
	public WebElement comboBoxSelectASystem;
	
	@FindBy(xpath="//li[@ title='IoTAS oDATA Service (sb)']")
	public WebElement liSystemName;
	
	@FindBy(xpath="//input[@ title='Please enter the service URL relative to selected destination']")
	public WebElement textBoxServiceName;
	
	@FindBy(xpath="//button[@ title='Load Service Metadata']")
	public WebElement buttonTest;
	
	@FindBy(xpath="//button[@ title='Next']")
	public WebElement buttonNext;
	
	@FindBy(xpath="//button[@aria-disabled='false' and @title='Next']")
	public WebElement buttonNextEnabled;

	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	

}
