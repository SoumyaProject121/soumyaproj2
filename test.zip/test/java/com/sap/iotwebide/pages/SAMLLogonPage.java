package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.sap.iot.utilities.BasePage;

public class SAMLLogonPage extends BasePage{

	public SAMLLogonPage(WebDriver driver) {
		super(driver);
		//Assert.assertTrue(hasPageLoaded());
	}

	@FindBy(id="j_username")
	private WebElement textBoxEmail;
	
	@FindBy(id="j_password")
	private WebElement textBoxPassword;
	
	@FindBy(id="logOnFormSubmit")
	private WebElement buttonLogOn;
	
	@FindBy(id="sessioniframe")
	private WebElement frameLogon;
	
	@FindBy(id="ids-heading-1")
	private WebElement headerLogon;
	
	public void login(String email, String password){
		
		//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameLogon));
		//Assert.assertEquals(driver.getTitle(), "SAML2-Bearer-2: Log On");
		textBoxEmail.sendKeys(email);
		textBoxPassword.sendKeys(password);
		buttonLogOn.click();
	}
	
	@Override
	public boolean hasPageLoaded(){
		if(headerLogon.getText().equals("Log On"))
			return true;
		else
			return false;
	}

}
