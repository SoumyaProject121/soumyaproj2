package com.sap.iotwebide.testcases;

public class DataIngestion {

}
