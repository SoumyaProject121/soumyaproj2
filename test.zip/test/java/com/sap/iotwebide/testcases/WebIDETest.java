package com.sap.iotwebide.testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.sikuli.script.FindFailed;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.sap.iot.utilities.BaseTest;
import com.sap.iot.utilities.ExcelUtils;
import com.sap.iotreuseui.pages.AnalysisReuseUIPage;
import com.sap.iotreuseui.pages.MapReuseUIPage;
import com.sap.iotreuseui.pages.ThingListReuseUIPage;
import com.sap.iotreuseui.pages.ThingPageReUseUIPage;
import com.sap.iotwebide.pages.AnalysisPageConfigurationPage;
import com.sap.iotwebide.pages.ApplicationMainpage;
import com.sap.iotwebide.pages.BasicInformationPage;
import com.sap.iotwebide.pages.DataConnetionPage;
import com.sap.iotwebide.pages.DataSourcePage;
import com.sap.iotwebide.pages.LandingPage;
import com.sap.iotwebide.pages.OverLayComponents;
import com.sap.iotwebide.pages.SelectPagesPage;
import com.sap.iotwebide.pages.TemplateSelectionPage;
import com.sap.iotwebide.pages.ThingListConfigPage;
import com.sap.iotwebide.pages.ThingPage;
import com.sap.iotwebide.pages.WebIDEHomePage;



/**
 * @author I329033
 *
 */
public class WebIDETest extends BaseTest {
	LinkedHashMap<String, String> testDataMap=new LinkedHashMap<>();
	String projectName;
	String generatedAppURL="";
	/*public WebIDETest() {
		super();
		System.out.println("In WebIDETest()");
	}*/

	public WebIDETest(String baseURL,LinkedHashMap<String, String> dataMap) {
		super(baseURL,dataMap);
		System.out.println("In WebIDETest(URL, map)");
		this.testDataMap=dataMap;
		projectName=testDataMap.get("Project Name");
		//projectName=testDataMap.get("Project Name").concat(getRandomString(3));
		System.out.println("test123");

	}

	@Test(groups={"pluginTest"})
	public void tc001_webide_pluginConnectivityInLocalRepoTest(){
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		System.out.println("starting tc001");
		/*	webIDEHomePage.goToPluginsSection();
		//if live plugin is enabled then disable it
		webIDEHomePage.selectSAPPluginAsRepository();
		webIDEHomePage.disableSAPIoTPlugin();*/

		//webIDEHomePage.goToPluginsSection();
		//webIDEHomePage.selectIoTRepositoryAsRepository();		
		//webIDEHomePage.enableLocalTestingPlugin();
		//webIDEHomePage.homebutton.click();
		wait(20);
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.homebutton));
		webIDEHomePage.homebutton.click();
		wait(5);
		webIDEHomePage.createNewProjectFromIoTTemplate();

		wait(10);
		TemplateSelectionPage templateSelectionPage=new TemplateSelectionPage(driver);
		wait.until(ExpectedConditions.visibilityOf(templateSelectionPage.comboBoxTemplateCategory));
		templateSelectionPage.comboBoxTemplateCategory.click();
		wait(5);
		Assert.assertTrue(templateSelectionPage.listItemInternetOfThings.isDisplayed(), "Internet Of Things template is available");
		templateSelectionPage.listItemInternetOfThings.click();


		templateSelectionPage.templateIoT.click();
		wait(15);
		//wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.buttonNextEnabled));
		//templateSelectionPage.buttonNextEnabled.click();
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.buttonNext)); //added 2/24/2021
		templateSelectionPage.buttonNext.click();


	}
	/*
	@Test(groups={"pluginTest"})
	public void tc001_webide_pluginConnectivityFromSAPPluginTest(){
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		webIDEHomePage.goToPluginsSection();

		//Following 2 lines of code will have to be deleted if there is no test repository available in web ide account
		webIDEHomePage.selectIoTRepositoryAsRepository();
		webIDEHomePage.disableLocalTestingPlugin();

		webIDEHomePage.goToPluginsSection();
		webIDEHomePage.selectSAPPluginAsRepository();
		webIDEHomePage.enableSAPIoTPlugin();

		wait(20);
		//click on File Menu > New >Project from template
		webIDEHomePage.createNewProjectFromIoTTemplate();
		wait(15);

		//Check if Internet of Things is listed as a template
		TemplateSelectionPage templateSelectionPage=new TemplateSelectionPage(driver);
		templateSelectionPage.comboBoxTemplateCategory.click();
		Assert.assertTrue(templateSelectionPage.listItemInternetOfThings.isDisplayed(), "Internet Of Things template is available");
		templateSelectionPage.listItemInternetOfThings.click();
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.templateIoT));
		templateSelectionPage.templateIoT.click();
		wait(5);
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.buttonNextEnabled));
		templateSelectionPage.buttonNextEnabled.click();
	}
	 */
	@Test(dependsOnGroups="pluginTest")
	public void tc002_webide_basicDetailsTest(){
		System.out.println("starting tc002...");
		BasicInformationPage basicInformationPage=new BasicInformationPage(driver);
		wait.until(ExpectedConditions.visibilityOf(basicInformationPage.textBoxProjectName));
		
		basicInformationPage.textBoxProjectName.sendKeys(projectName);
		String projectname = basicInformationPage.textBoxProjectName.getText();
		System.out.println(projectname);
		basicInformationPage.textBoxNamespace.sendKeys(testDataMap.get("Namespace"));
		basicInformationPage.textBoxTitle.sendKeys(testDataMap.get("Title"));
		Assert.assertTrue(basicInformationPage.buttonNext.isEnabled(),"Next button is enabled");
		wait(10);
		basicInformationPage.buttonNext.click();
	
	}
	
	// DataSource page 2/24/2021
	@Test(dependsOnMethods="tc002_webide_basicDetailsTest")
	public void tc003_webide_datasourceTest() throws AWTException{
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
	System.out.println("starting tc003..");
	DataSourcePage datasource = new DataSourcePage(driver);
	datasource.dropDownService.sendKeys(testDataMap.get("Service"));
	//wait(5);
	datasource.selectdropDown.click();
	wait(10);
	datasource.thingPropertySetsIcon.click();
	wait(5);
	datasource.selectThingTypeTxtbox.sendKeys(testDataMap.get("ThingPropertysets_ThingType"));
	wait(5);
	Robot robot=new Robot();
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	//wait(15);
	wait.until(ExpectedConditions.elementToBeClickable(datasource.propertsetofThingtype));
	datasource.propertsetofThingtype.click();
	//wait(10);
	datasource.okbutton.click();
	//wait(20);
	//Alert alert=driver.switchTo().alert();
	//alert.accept();	
	wait.until(ExpectedConditions.elementToBeClickable(datasource.eventPropertySetsIcon));
	datasource.eventPropertySetsIcon.click();
	//wait(10);
	datasource.eventTypeTxtbox.click();// sendKeys(Keys.ENTER);
	wait(10);
	wait.until(ExpectedConditions.elementToBeClickable(datasource.searchEventType));
	datasource.searchEventType.sendKeys(testDataMap.get("EventPropertysets_EventType"));
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	wait(10);
	datasource.elementselectable.click();
	wait.until(ExpectedConditions.elementToBeClickable(datasource.propertsetofEventtype));
	datasource.propertsetofEventtype.click();
	wait(10);
	datasource.okbutton.click();
	Assert.assertTrue(datasource.buttonNext.isEnabled(),"Next button is enabled");
	datasource.buttonNext.click();
	}
	
/* End using data source

	@Test(dependsOnMethods="tc002_webide_basicDetailsTest")
	public void tc003_webide_dataConnectionTest(){
		DataConnetionPage dataConnetionPage=new DataConnetionPage(driver);
		wait.until(ExpectedConditions.elementToBeClickable(dataConnetionPage.liServiceURL));
		dataConnetionPage.liServiceURL.click();
		dataConnetionPage.comboBoxSelectASystem.click();
		dataConnetionPage.liSystemName.click();
		//	Assert.assertFalse(dataConnetionPage.buttonNext.isEnabled(),"Next button is disabled");
		wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.textBoxServiceName));
		dataConnetionPage.textBoxServiceName.sendKeys("CompositeThings/v1");
		dataConnetionPage.buttonTest.click();
		wait(100);
		//wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNextEnabled));
		wait.until(ExpectedConditions.elementToBeClickable(dataConnetionPage.buttonNextEnabled));
		/*try{
		wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNext));*/
		//DataConnetionPage dataConnetionPage2=new DataConnetionPage(driver);
		//wait.until(ExpectedConditions.stalenessOf(dataConnetionPage.buttonNext));
		//	while(!dataConnetionPage.buttonNext.isEnabled()){
		//wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(dataConnetionPage.buttonNext)));
		/*wait.until(ExpectedConditions.attributeToBe(dataConnetionPage.buttonNext, "aria-disabled", "false"));

		//	}
		}catch(StaleElementReferenceException e){
			wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNext));
		}*/

		//dataConnetionPage.buttonNextEnabled.click();		
	//} */

	@Test(dependsOnMethods="tc003_webide_datasourceTest")
	public void tc004_webide_selectPagesTest(){
		System.out.println("starting tc004");
		SelectPagesPage selectPagesPage=new SelectPagesPage(driver);
		/*wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelSelectPages));
		wait(10);
		Assert.assertEquals(selectPagesPage.labelSelectPages.getText(), "Select Pages");
		Assert.assertEquals(selectPagesPage.labelSelectThePagesYouWant.getText(), "Select the pages you want to use in your application");

		Assert.assertEquals(selectPagesPage.labelLandingPage.isDisplayed(), true, "Landing page is displayed");
		Assert.assertEquals(selectPagesPage.imageLandingPage.isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelThingList.isDisplayed(), true, "Thing List is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxThingList.isEnabled(), true);

		Assert.assertEquals(selectPagesPage.imageThingList.isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelThingPage.isDisplayed(), true, "Thing page is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxThingPage.isEnabled(), true);
		Assert.assertEquals(selectPagesPage.imageThingPage .isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelAnalysisPage.isDisplayed(), true, "Analysis page is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxAnalysisPage.isEnabled(), true);
		Assert.assertEquals(selectPagesPage.imageAnalysisPage.isDisplayed(), true);
		*/
		//selectPagesPage.buttonNext.click();
	}


	@Test(dependsOnMethods="tc004_webide_selectPagesTest")
	public void tc005_webide_pageSelectionTest(){
		System.out.println("starting tc005..");
		OverLayComponents overLayComponents=new OverLayComponents(driver);
		SelectPagesPage selectPagesPage=new SelectPagesPage(driver);
		wait(5);
		/*wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelSelectPages));
		wait.until(ExpectedConditions.elementToBeClickable(selectPagesPage.labelThingList));
		selectPagesPage.labelThingList.click();
		wait(5);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbThingList));	
		selectPagesPage.labelThingList.click();
		wait(5);
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbThingList));

		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelThingPage));
		selectPagesPage.labelThingPage.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbThingPage));
		selectPagesPage.labelThingPage.click();
		wait(5);
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbThingPage));

		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelAnalysisPage));
		selectPagesPage.labelAnalysisPage.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbAnalysisPage));
		selectPagesPage.labelAnalysisPage.click();
		wait(5);
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbAnalysisPage));*/

		/*selectPagesPage.dropDownSelectPST.clear();
		selectPagesPage.dropDownSelectPST.sendKeys(testDataMap.get("PST"));
		//wait.until(ExpectedConditions.textToBePresentInElementValue(selectPagesPage.dropDownSelectNamedPST, testDataMap.get("Named PST")));
		wait(5);
		selectPagesPage.dropDownSelectNamedPST.click();
		wait(5);
		selectPagesPage.dropDownSelectNamedPST.clear();
		wait(2);
		selectPagesPage.dropDownSelectNamedPST.sendKeys(testDataMap.get("Named PST"));
*/
		/*if(testDataMap.get("Select Thing List").equalsIgnoreCase("No"))
			selectPagesPage.labelThingList.click();
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("No"))
			selectPagesPage.labelThingPage.click();
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("No"))
			selectPagesPage.labelAnalysisPage.click();
		wait(10);*/
		selectPagesPage.buttonNext.click();
		
		
		/* Below steps to create application with default value selection in pages
		
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		driver.findElement(By.xpath("//bdi[text()='Finish']")).click();*/
	}

	@Test(dependsOnMethods="tc005_webide_pageSelectionTest")
	public void tc006_webide_landingPageConfigurationTest(){
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		LandingPage landingPage=new LandingPage(driver); 
		wait.until(ExpectedConditions.elementToBeClickable(landingPage.checkBoxThingList));
		if(testDataMap.get("Thing List on Map Check box").equals("No"))
			landingPage.checkBoxThingList.click();
		else{
			landingPage.inputThingListInfo1.clear();
			landingPage.inputThingListInfo1.sendKeys(testDataMap.get("ThingList on Map Info 1"));
			wait(2);
			landingPage.inputThingListInfo2.clear();
			landingPage.inputThingListInfo2.sendKeys(testDataMap.get("ThingList on Map Info 2"));
			landingPage.inputThingListSortField.clear();
			landingPage.inputThingListSortField.sendKeys(testDataMap.get("ThingList on Map Sort field"));
			wait(2);
			if(testDataMap.get("ThingList on Map Sort Direction").equalsIgnoreCase("Descending"))
				landingPage.labelDescendingSortOrder.click();
		}
		wait(2);
		landingPage.inputDetailTitle.sendKeys(testDataMap.get("Single Card Title"));
		landingPage.inputDetailViewHeaderInfo1.clear();
		wait(5);
		landingPage.inputDetailViewHeaderInfo1.sendKeys(testDataMap.get("Single Card Header info 1"));
		wait(2);
		landingPage.inputDetailViewHeaderInfo2.clear();
		landingPage.inputDetailViewHeaderInfo2.sendKeys(testDataMap.get("Single Card Header info 2"));
		wait(2);
		landingPage.inputDetailViewHeaderNavigation.clear();
		landingPage.inputDetailViewHeaderNavigation.sendKeys(testDataMap.get("Single Card Header Navigation"));
		wait(2);
		if(testDataMap.get("Single Card Event Enable").equalsIgnoreCase("No"))
			landingPage.checkboxEvent.click();
		else
			landingPage.inputEventAreaTitle.sendKeys(testDataMap.get("Single Card Event Title"));
		wait(2);
		if(testDataMap.get("Single Card Contact Enable").equalsIgnoreCase("No"))
			landingPage.checkboxContactInfo.click();
		else{
			landingPage.inputContactInfoAreaTitle.sendKeys(testDataMap.get("Single Card Contact Title"));
			wait(2);
			landingPage.inputContactInfo1.clear();
			landingPage.inputContactInfo1.sendKeys(testDataMap.get("Single Card Contact Info1"));
			wait(5);
			landingPage.inputContactInfo2.clear();
			landingPage.inputContactInfo2.sendKeys(testDataMap.get("Single Card Contact Info2"));
			wait(2);
			landingPage.inputContactInfo3.clear();
			landingPage.inputContactInfo3.sendKeys(testDataMap.get("Single Card Contact Info3"));
		}

		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
			wait(5);
			landingPage.inputDetailCardFooterText.sendKeys(testDataMap.get("Single Card footer text"));
			wait(2);
			landingPage.inputDetailCardFooterNavigation.clear();
			landingPage.inputDetailCardFooterNavigation.sendKeys(testDataMap.get("Single Card navigation target"));
		}
		wait(2);
		landingPage.inputListCardTitle.sendKeys(testDataMap.get("Multi Card title"));
		wait(2);
		landingPage.inputListCardInfo1.clear();
		landingPage.inputListCardInfo1.sendKeys(testDataMap.get("Multi Card info1"));
		wait(5);
		landingPage.inputListCardInfo2.clear();
		landingPage.inputListCardInfo2.sendKeys(testDataMap.get("Multi Card info2"));
		wait(2);
		landingPage.inputListCardNavigation.clear();
		landingPage.inputListCardNavigation.sendKeys(testDataMap.get("Multi Card List navigation target"));
		wait(2);
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			landingPage.inputListCardFooterText.sendKeys(testDataMap.get("Multi Card footer text"));
			wait(2);
			landingPage.inputListCardFooterNavigation.clear();
			landingPage.inputListCardFooterNavigation.sendKeys(testDataMap.get("Multi Card footer navigation target"));
		}
		else{
			Assert.assertFalse(isElementPresent(landingPage.inputListCardFooterText));
			Assert.assertFalse(isElementPresent(landingPage.inputListCardFooterNavigation));
		}
		wait.until(ExpectedConditions.elementToBeClickable(landingPage.buttonNextEnabled));
		landingPage.buttonNextEnabled.click();
		wait(10);
		//landingPage.buttonNextEnabled.click();
	}

	// Testing one flow with default values 
	
	 @Test(dependsOnMethods="tc006_webide_landingPageConfigurationTest")
	public void tc007_webide_thingListConfigurationTest(){
		 System.out.println("starting tc006..");
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			ThingListConfigPage thingListConfigPage=new ThingListConfigPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListConfigPage.textBoxTitle));
			thingListConfigPage.textBoxTitle.sendKeys(testDataMap.get("ThingListTitle"));
			thingListConfigPage.inputSortingField.clear();
			thingListConfigPage.inputSortingField.sendKeys(testDataMap.get("Default sort field"));
			wait(2);
			if(testDataMap.get("Sort Direction").equalsIgnoreCase("Descending"))
				thingListConfigPage.radioButtonDescending.click();
			thingListConfigPage.inputColumn2.clear();
			thingListConfigPage.inputColumn2.sendKeys(testDataMap.get("Column 2"));
			wait(2);
			thingListConfigPage.inputColumn3.clear();
			wait(2);
			thingListConfigPage.inputColumn3.sendKeys(testDataMap.get("Column 3"));
			thingListConfigPage.inputColumn4.clear();
			thingListConfigPage.inputColumn4.sendKeys(testDataMap.get("Column 4"));
			wait(5);
			thingListConfigPage.inputColumn5.clear();
			thingListConfigPage.inputColumn5.sendKeys(testDataMap.get("Column 5"));
			wait(2);
			thingListConfigPage.inputColumn6.clear();
			thingListConfigPage.inputColumn6.sendKeys(testDataMap.get("Column 6"));
			wait(2);
			thingListConfigPage.inputColumn7.clear();
			thingListConfigPage.inputColumn7.sendKeys(testDataMap.get("Column 7"));
			wait(2);
			thingListConfigPage.inputColumn8.clear();
			thingListConfigPage.inputColumn8.sendKeys(testDataMap.get("Column 8"));
			wait(2);
			thingListConfigPage.comboBoxListItemNavTarget.clear();
			thingListConfigPage.comboBoxListItemNavTarget.sendKeys(testDataMap.get("List navigation target"));
			wait.until(ExpectedConditions.elementToBeClickable(thingListConfigPage.buttonNext));
			thingListConfigPage.buttonNext.click();
			wait(10);
			thingListConfigPage.buttonNext.click();
		}else
			Reporter.log("Test case for thinglist is skipped");
		
	}

	@Test(enabled=false,dependsOnMethods="tc007_webide_thingListConfigurationTest")
	public void tc008_webide_thingPageConfigurationTest() throws AWTException{
		
		
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			ThingPage thingPage=new ThingPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingPage.dropBoxInformation1));
			thingPage.dropBoxInformation1.clear();
			thingPage.dropBoxInformation1.sendKeys(testDataMap.get("Header Info1"));
			//Robot robot=new Robot();
			//robot.keyPress(KeyEvent.VK_ENTER);
			//robot.keyRelease(KeyEvent.VK_ENTER);
			wait(10);
			thingPage.dropBoxInformation2.clear();
			thingPage.dropBoxInformation2.sendKeys(testDataMap.get("Header Info2"));
			wait(10);
			thingPage.dropBoxInformation3.clear();
			thingPage.dropBoxInformation3.sendKeys(testDataMap.get("Header Info3"));
			wait(10);
			wait.until(ExpectedConditions.visibilityOf(thingPage.checkboxContentBasicData));
			if(testDataMap.get("Basic Data Enable").equalsIgnoreCase("Yes")){
				thingPage.dropBoxColumn1Info1.clear();
				wait(2);
				thingPage.dropBoxColumn1Info1.sendKeys(testDataMap.get("Column1 info1"));

				thingPage.dropBoxColumn2Info1.clear();
				thingPage.dropBoxColumn2Info1.sendKeys(testDataMap.get("Column 2 info1"));
				wait(2);
				thingPage.dropBoxColumn3Info1.clear();
				thingPage.dropBoxColumn3Info1.sendKeys(testDataMap.get("Column 3 info1"));
				/* Checks if user wants to add additional data into basic details for column1
				 * if in data sheet, data exists for additional info, then click on add button for column1
				 * and enter the data.
				 */
	
				for(int i=2;i<9;i++){
					if(!testDataMap.get("Column1 info"+i).isEmpty()) {
						thingPage.buttonAddList.get(0).click();
						thingPage.dropDownColumn1List.get(i-1).clear();
						thingPage.dropDownColumn1List.get(i-1).sendKeys(testDataMap.get("Column1 info"+i));
						wait(2);
					}		
				}
				wait(2);
				for(int j=2;j<9;j++){
					if(!testDataMap.get("Column 2 info"+j).isEmpty()) {
						thingPage.buttonAddList.get(1).click();
						thingPage.dropDownColumn2List.get(j-1).clear();
						thingPage.dropDownColumn2List.get(j-1).sendKeys(testDataMap.get("Column 2 info"+j));
						wait(2);
					}		
				}
				wait(2);
				for(int i=2;i<9;i++){
					if(!testDataMap.get("Column 3 info"+i).isEmpty()) {
						thingPage.buttonAddList.get(2).click();
						thingPage.dropDownColumn3List.get(i-1).clear();
						thingPage.dropDownColumn3List.get(i-1).sendKeys(testDataMap.get("Column 3 info"+i));
						wait(2);
					}		
				}

			}else
				thingPage.checkboxContentBasicData.click();
			Actions action = new Actions(driver); 
			action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
			//		scrollToElementUsingJavascriptExecutor(thingPage.checkBoxMeasureValues);
			scrollPageToBottom();
			if(testDataMap.get("Measured Values Enable").equalsIgnoreCase("No"))
				thingPage.checkBoxMeasureValues.click();

			wait(2);
			/**
			 * Events on chart is not released
			 */
			/*if(testDataMap.get("Events Enable").equalsIgnoreCase("No"))
				thingPage.checkBoxEvents.click();
			//Remove this condition since irrespective of analysis page, text box should be available. once change is done, 
			else if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
				thingPage.textBoxShowEvents.sendKeys(testDataMap.get("Show Events"));
			}*/
			if(testDataMap.get("Timeline Enable").equalsIgnoreCase("No"))
				thingPage.checkBoxTimeline.click();

			wait.until(ExpectedConditions.elementToBeClickable(thingPage.buttonNextEnabled));
			thingPage.buttonNextEnabled.click();
		}else
			Reporter.log("Test case for thing page is skipped");
	
	}

	@Test(dependsOnMethods="tc007_webide_thingListConfigurationTest")//tc008_webide_thingPageConfigurationTest")
	public void tc009_webide_analysisPageConfigurationTest(){
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
			AnalysisPageConfigurationPage analysisConfigurationPage= new AnalysisPageConfigurationPage(driver);
			wait.until(ExpectedConditions.visibilityOf(analysisConfigurationPage.dropBoxInformation1));
			analysisConfigurationPage.dropBoxInformation1.clear();
			wait(3);
			analysisConfigurationPage.dropBoxInformation1.sendKeys(testDataMap.get("Header Info1"));
			wait(2);
			analysisConfigurationPage.dropBoxInformation2.clear();

		wait(3);
			analysisConfigurationPage.dropBoxInformation2.sendKeys(testDataMap.get("Header Info2"));
			wait.until(ExpectedConditions.visibilityOf(analysisConfigurationPage.radioButton7Days));
			if(testDataMap.get("Default Time Period").equalsIgnoreCase("28 Days"))
				analysisConfigurationPage.radioButton28Days.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("7 Days"))
				analysisConfigurationPage.radioButton7Days.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("24 Hours"))
				analysisConfigurationPage.radioButton24Hours.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("12 Hours"))
				analysisConfigurationPage.radioButton12Hours.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("1 Hour"))
				analysisConfigurationPage.radioButton1Hour.click();

			//if(testDataMap.get("Time Slider Enable").equalsIgnoreCase("No"))
				//analysisConfigurationPage.checkBoxShowTimeSlider.click();	
			/**
			 * Events on chart is not released
			 */
			/*if(testDataMap.get("Events Enable").equalsIgnoreCase("No"))
				analysisConfigurationPage.checkBoxShowEventsInChart.click();
			else{
				Assert.assertTrue(isElementPresent(analysisConfigurationPage.textBoxEventListTitle));
				analysisConfigurationPage.textBoxEventListTitle.sendKeys(testDataMap.get("Event List Title"));
			}*/

			analysisConfigurationPage.buttonFinish.click();
			wait(10);
		}else
			Reporter.log("Test case for analysis page is skipped");
	}
	
	@Test(dependsOnMethods="tc009_webide_analysisPageConfigurationTest")
	public void tc010_webide_gnerationOfApplication(){
		
		System.out.println("new project created");
		wait(30);
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.buttonWorkspace));
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonWorkspace));
		wait(10);
		String title = driver.getTitle();
		System.out.println(title);
		//String projectName1=testDataMap.get("Project Name").concat(getRandomString(3).toString());
		//System.out.println(projectName1);
		for (WebElement	element : webIDEHomePage.generatedProjectsList) {
			
			if(element.findElement(By.tagName("span")).getText().equals(testDataMap.get("Project Name")))
			{
				//element.click();
				wait(2);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.Namespacemenu));
		
		webIDEHomePage.Namespacemenu.click();
		wait(20);
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.runbutton));
		wait(5);
		/*String oldTab = driver.getWindowHandle();
	    System.out.println(oldTab);
		//String oldTab = driver.getWindowHandle();
		//System.out.println(oldTab);
		webIDEHomePage.runbutton.click();
		wait(10);
		for(String newtab:driver.getWindowHandles())
		{
			driver.switchTo().window(newtab);
		}*/
		/*ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		int count = newTab.size();
		System.out.println(count);
		System.out.println(newTab);
	    newTab.remove(oldTab);
	    driver.switchTo().window(newTab.get(1));*/
		wait(10);
		

		/*for (WebElement	element : webIDEHomePage.generatedProjectsList) {
			if(element.findElement(By.tagName("span")).getText().equals(testDataMap.get("Project Name"))){
				wait(10);
				Actions act = new Actions(driver);
			    //act.moveToElement(element).doubleClick().perform();
			    //wait(5);
			    act.moveToElement(webIDEHomePage.Namespacemenu).perform();
			    wait(10);
			    System.out.println("selected namespace");
			}} */
			}
	}
		}
	
	
	
	@Test(dependsOnMethods="tc010_webide_gnerationOfApplication")
	public void tc011_webide_verifyApplication(){
		
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		String oldTab = driver.getWindowHandle();
	    System.out.println(oldTab);
		//String oldTab = driver.getWindowHandle();
		//System.out.println(oldTab);
		webIDEHomePage.runbutton.click();
		wait(10);
		for(String newtab:driver.getWindowHandles())
		{
			driver.switchTo().window(newtab);
		}
		
		System.out.println("Generated new application");
		wait(5);
		//driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		//Actions action= new Actions(driver);
		//action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).build().perform();
		wait(5);
		String title = driver.getTitle();
		System.out.println(title);
		wait(5);
		ApplicationMainpage generatedapplication = new ApplicationMainpage(driver);
		//WebElement element =
		String res = generatedapplication.landingpageheader.getText();
		System.out.println(res);
	   Assert.assertEquals(res, "Landing Page");
		
		/*List<WebElement> list = generatedapplication.listofitems;
		for(int i=0;i<=list.size();i++)
		{
			
		String values = list.get(i).getText();
	//System.out.println();
		
		System.out.println(values);
		Assert.assertEquals(values.contains(list.get(i).getText()), values);

		}*/
	   wait(5);
		boolean result1 = generatedapplication.inputSearchbox.isDisplayed();
		System.out.println(result1 + "Search field is displayed");
		wait(10);
		Assert.assertEquals(generatedapplication.buttonSortby.isDisplayed(), true);
		wait(5);
		generatedapplication.buttonSortby.click();
		wait(2);
		Assert.assertEquals(generatedapplication.ascendingRadiobutton.isDisplayed(), true);
		wait(3);
		Assert.assertEquals(generatedapplication.descendingRadiobutton.isDisplayed(), true);
		wait(2);
		Assert.assertEquals(generatedapplication.okbutton.isDisplayed(), true);
		Assert.assertEquals(generatedapplication.cancelbutton.isDisplayed(), true);
		generatedapplication.okbutton.click();
		wait(5);
		
		System.out.println("assertion done");
		//driver.quit();
	}
	
	
	
	
	

	
	
	
	
	@Test(enabled=false,dependsOnMethods="tc009_webide_analysisPageConfigurationTest")
	public void tc010_webide_projectDeploymentTest(){
		
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.buttonWorkspace));
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonWorkspace));
		wait(10);
		System.out.println("new project created");
		//webIDEHomePage.buttonWorkspace.click();
		wait(5);
		//System.out.println("workspace");
		//WebElement element = webIDEHomePage.Namespacemenu;
				//element.click();
		//rightClickOnElement(element,driver);
		//wait(5);		
		for (WebElement	element : webIDEHomePage.generatedProjectsList) {
			//String ele = element.getText();
			//System.out.println(ele);
			if(element.findElement(By.tagName("span")).getText().equals(testDataMap.get("Project Name"))){
			wait(10);
			//String projectName1=testDataMap.get("Project Name").concat(getRandomString(3).toString());
			//if(element.findElement(By.tagName("span")).getText().equals(projectName1)){
			String value = element.findElement(By.tagName("span")).getText();
			System.out.println(value);
			//.equals(testDataMap.get("Project Name"));
			Actions act = new Actions(driver);
			    act.moveToElement(element).doubleClick().perform();
			    wait(5);
			    act.moveToElement(webIDEHomePage.Namespacemenu).perform();
			    wait(10);
			    System.out.println("selected namespace");
				rightClickOnElement(element,driver);
				wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.contextMenuDeploy));
				moveToElementAndClickOnSubMenu(webIDEHomePage.contextMenuDeploy, webIDEHomePage.contextMenuDeployToHCP,driver);
				wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.inputLogOnToSAP));
				webIDEHomePage.inputLogOnToSAP.clear();
				webIDEHomePage.inputLogOnToSAP.sendKeys("I329033");
				wait(5);
				webIDEHomePage.inputLogOnPassword.clear();
				webIDEHomePage.inputLogOnPassword.sendKeys("Vs@9496334472");
				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonLogin));
				webIDEHomePage.buttonLogin.click();

				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonDeploy));
				webIDEHomePage.buttonDeploy.click();
				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.linkOpenApplication));
				generatedAppURL=webIDEHomePage.linkOpenApplication.getAttribute("href");
				//super.reuseUIAppURL=generatedAppURL;
				Reporter.log(generatedAppURL+" is the generated application URL");
				
				
			}
		}
		/*String userDir = System.getProperty("user.dir");
		ExcelUtils excelUtil=new ExcelUtils();
		try {
			excelUtil.writeProjectURLToExcel(generatedAppURL, testDataMap.get("Project Name"),userDir+"/src/test/resources/TestDataDemo.xlsx");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reporter.log("Unable to write generated app URL to excel");
			e.printStackTrace();
		}*/
	}
	
	/**
	 * ReUse UI test cases
	 */

	@Test(enabled=false,dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc001_reUseSingleThingCardTest() throws AWTException{
		driver.navigate().to(generatedAppURL);
		MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
		
		// To click on a pin which displays number as 1
		Screen screen=new Screen();
		ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
		try {
			screen.wait("SingleThingPin.PNG");
			//screen.
			screen.click("SingleThingPin.PNG");
		} catch (FindFailed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		wait(5);
		//Verify single thing card  header is as configured
		wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage.singleThingCardTitle));
		String singleThingCardTitle=mapReuseUIPage.singleThingCardTitle.getText();
		Reporter.log(singleThingCardTitle + " is the title for Single Thing Card");
		Assert.assertEquals(singleThingCardTitle,testDataMap.get("Single Card Title"));
		Assert.assertEquals(isElementPresent(mapReuseUIPage.singleThingCardHeaderImage), true);
		Assert.assertTrue(!mapReuseUIPage.singleThingCardHeaderInfo1.getText().isEmpty(), mapReuseUIPage.singleThingCardHeaderInfo1.getText()+" is the header info1");
		Assert.assertTrue(!mapReuseUIPage.singleThingCardHeaderInfo2.getText().isEmpty(), mapReuseUIPage.singleThingCardHeaderInfo2.getText()+" is the header info2");

		//Verify Events and Contact Section
		if(testDataMap.get("Single Card Event Enable").equalsIgnoreCase("Yes")||testDataMap.get("Single Card Contact Enable").equalsIgnoreCase("Yes")){
			for (WebElement element : mapReuseUIPage.singleThingCardBlockHeaders) {
				if(element.findElement(By.tagName("label")).getText().equals(testDataMap.get("Single Card Event Title"))){
					Assert.assertTrue(true, "Events Area Title is as configured");
					Reporter.log("<br></br>Events Area Title is as configured");
				}
				else if(element.findElement(By.tagName("label")).getText().equals(testDataMap.get("Single Card Contact Title"))){
					Assert.assertTrue(true, "Contact Area Title is as configured");
					Reporter.log("<br></br> Contact Area Title is as configured");
				}
			}
		}

		//Verify footer text
		if(!testDataMap.get("Single Card footer text").isEmpty())
			System.out.println(mapReuseUIPage.singleThingCardFooterButton.getText());
			
			Assert.assertEquals(mapReuseUIPage.singleThingCardFooterButton.getText(), testDataMap.get("Single Card footer text"));

		//Verify navigation from header
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
			mapReuseUIPage.singleThingCardHeaderInfo1.click();	
			ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
			wait(8);
			wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
			Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			driver.navigate().back();
			//thingPageReUseUIPage.buttonBack.click();
		}

		/*MapReuseUIPage mapReuseUIPage2=new MapReuseUIPage(driver);
		wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage2.singleThingCardTitle));
		mapReuseUIPage2.buttonCloseCard.click();*/
	}

	@Test(enabled=false,dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc002_reUsemultipleThingCardTest(){
		MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
		// To click on a pin which displays number greater than 1
		Screen screen=new Screen();
		ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
		try {
			screen.wait("OrangeCluster.PNG");
			screen.click("OrangeCluster.PNG");
		} catch (FindFailed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait(5);
		wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage.multipleThingCardTitle));
		Assert.assertEquals(mapReuseUIPage.multipleThingCardTitle.getText(), testDataMap.get("Multi Card title"));
		//Check for semantic bar, info 1 and info2,
		if(!testDataMap.get("Multi Card footer text").isEmpty())
			Assert.assertEquals(mapReuseUIPage.multipleThingCardFooterButton.getText(), testDataMap.get("Multi Card footer text"));
		if(!testDataMap.get("Multi Card footer navigation target").isEmpty()){
			mapReuseUIPage.multipleThingCardFooterButton.click();
			wait(5);
			ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
			Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
			driver.navigate().back();
		}			
	}

	/*@Test(dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc003_reUsethingPageTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				
				Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}
	}

	@Test(dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc004_reUsemeasuredValuesTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}
	}

	@Test(dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc005_reUseEventListTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				//Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				//Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}

	}

	@Test(dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc006_reUseTimelineTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}

	}

	@Test(dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc007_reUseThingListTest(){
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
			// To click on a pin which displays number greater than 1
			Screen screen=new Screen();
			ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
			try {
				screen.wait("OrangeCluster.PNG");
				screen.click("OrangeCluster.PNG");
			} catch (FindFailed e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			wait(5);
			wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage.multipleThingCardFooterButton));
			mapReuseUIPage.multipleThingCardFooterButton.click();
			ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
			Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
			
			thingListReuseUIPage.tableListItems.get(0).click();
			if(testDataMap.get("List navigation target").equalsIgnoreCase("Analysis Page")){
				AnalysisReuseUIPage analysisReuseUIPage=new AnalysisReuseUIPage(driver);
				Assert.assertEquals(analysisReuseUIPage.buttonSelectMPs.isDisplayed(), true);
			}
			else if(testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
			}
		}
	}
*/
	@Test(enabled=false,dependsOnMethods="tc010_webide_projectDeploymentTest")
	public void tc008_reUseSensorChartTest() throws Exception{
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card navigation target").equalsIgnoreCase("Analysis Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait(6);
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardFooterButton));
				mapReuseUIPage.singleThingCardFooterButton.click();
				AnalysisReuseUIPage analysisReuseUIPage=new AnalysisReuseUIPage(driver);
				wait(6);
				wait.until(ExpectedConditions.visibilityOf(analysisReuseUIPage.pageTitle));
				Assert.assertEquals(analysisReuseUIPage.buttonSelectMPs.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonFullScreen.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonDynamicScaling.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button7Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button28Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button24Hours.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button1Hour.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button12Hours.isDisplayed(),true);
				analysisReuseUIPage.button28Days.click();
				wait(4);
				captureScreenshot("28DaysChart");
				analysisReuseUIPage.button7Days.click();
				wait(4);
				captureScreenshot("7DaysChart");
				analysisReuseUIPage.button24Hours.click();
				wait(4);
				captureScreenshot("24HoursChart");
				analysisReuseUIPage.button12Hours.click();
				wait(4);
				captureScreenshot("12HoursChart");
				analysisReuseUIPage.button1Hour.click();
				wait(4);
				captureScreenshot("1HourChart");
				analysisReuseUIPage.button28Days.click();
				wait(4);
				analysisReuseUIPage.buttonDynamicScaling.click();
				wait(2);
				captureScreenshot("dynamicScaling");
				analysisReuseUIPage.buttonFullScreen.click();
				wait(2);
				captureScreenshot("fullscreenChart");
				driver.navigate().back();
				wait(4);
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Analysis Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				AnalysisReuseUIPage analysisReuseUIPage=new AnalysisReuseUIPage(driver);
				wait(5);
				wait.until(ExpectedConditions.visibilityOf(analysisReuseUIPage.pageTitle));
				Assert.assertEquals(analysisReuseUIPage.buttonSelectMPs.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonFullScreen.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonDynamicScaling.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button7Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button28Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button24Hours.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button1Hour.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button12Hours.isDisplayed(),true);
				analysisReuseUIPage.button28Days.click();
				wait(4);
				captureScreenshot("28DaysChart");
				analysisReuseUIPage.button7Days.click();
				wait(4);
				captureScreenshot("7DaysChart");
				analysisReuseUIPage.button24Hours.click();
				wait(4);
				captureScreenshot("24HoursChart");
				analysisReuseUIPage.button12Hours.click();
				wait(4);
				captureScreenshot("12HoursChart");
				analysisReuseUIPage.button1Hour.click();
				wait(4);
				captureScreenshot("1HourChart");
				analysisReuseUIPage.button28Days.click();
				wait(4);
				analysisReuseUIPage.buttonDynamicScaling.click();
				wait(2);
				captureScreenshot("dynamicScaling");
				analysisReuseUIPage.buttonFullScreen.click();
				wait(2);
				captureScreenshot("fullscreenChart");
				driver.navigate().back();
				wait(4);
			}
		}

	}
}

