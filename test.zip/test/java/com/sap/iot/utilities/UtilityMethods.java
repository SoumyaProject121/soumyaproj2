package com.sap.iot.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;
import java.util.TimeZone;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UtilityMethods{

	WebDriver driver;
	public HashMap<String, String> readFromPropertiesFile(){
		HashMap<String, String> propertiesMap=new HashMap<String, String>();
		Properties properties = new Properties();
		InputStream input = null;
		try {

			input = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/TestConfiguration.properties");
			properties.load(input);
			propertiesMap.put("browser", properties.getProperty("browser"));
			propertiesMap.put("webIDE_staging_URL", properties.getProperty("webIDE_staging_URL"));
			propertiesMap.put("webIDE_commit_URL", properties.getProperty("webIDE_commit_URL"));
			propertiesMap.put("reuseUIURL", properties.getProperty("reuse_URL"));
			propertiesMap.put("username", properties.getProperty("user_name"));
			propertiesMap.put("password", properties.getProperty("password"));
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return propertiesMap;
	}
	/**
	 * This method checks if the string contents of an Arraylist is sorted in alphabetical order
	 * @param arrayList of String
	 * @return boolean- true if sorted, false- if not sorted 
	 */	
	public boolean isSortedInAscending(ArrayList<String> list) {
		ArrayList<String> copy = new ArrayList<String>(list);
		Collections.sort(copy);
		return copy.equals(list);
	}

	/**
	 * This method checks if the string contents of an Arraylist is sorted in ascending order
	 * @param arrayList of Integer
	 * @return boolean- true if sorted, false- if not sorted 
	 */	
	public boolean isSortedInAscendingInt(ArrayList<Integer> list) {
		ArrayList<Integer> copy = new ArrayList<Integer>(list);
		Collections.sort(copy);
		return copy.equals(list);
	}

	/**
	 * This method checks if the string contents of an Arraylist is sorted in descending order
	 * @param arrayList of String
	 * @return boolean- true if sorted, false- if not sorted 
	 */	
	public boolean isSortedInDescending(ArrayList<String> list) {
		ArrayList<String> copy = new ArrayList<String>(list);
		Collections.sort(copy, Comparator.reverseOrder());
		return copy.equals(list);
	}

	/**
	 * This method checks if the string contents of an Arraylist is sorted in descending order
	 * @param arrayList of Integer
	 * @return boolean- true if sorted, false- if not sorted 
	 */
	public boolean isSortedInDescendingInt(ArrayList<Integer> list) {
		ArrayList<Integer> copy = new ArrayList<Integer>(list);
		Collections.sort(copy, Comparator.reverseOrder());
		return copy.equals(list);
	}

	/**
	 * This method checks if the date contents of an Arraylist is sorted in descending order
	 * @param arrayList of Strings which are dates
	 * @return boolean- true if sorted, false- if not sorted 
	 * @throws ParseException 
	 */
	public boolean isDateSortedInDescending(ArrayList<String> list) throws ParseException {
		ArrayList<Date> dateFormatList=new ArrayList<>();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM d',' yyyy',' h:mm:ss.SSS aaa");
		TimeZone.setDefault(TimeZone.getTimeZone("en-US"));

		for (String dateString : list) {
			System.out.println(dateString + "-----"+simpleDateFormat.parse(dateString));
			dateFormatList.add(simpleDateFormat.parse(dateString));
		}


		System.out.println(simpleDateFormat.toPattern()+"-pattern");
		System.out.println(simpleDateFormat.toLocalizedPattern()+"-localised");
		ArrayList<Date> copy = new ArrayList<Date>(dateFormatList);
		Collections.sort(copy, Comparator.reverseOrder());
		copy.forEach(item -> System.out.println(item));
		return copy.equals(list);
	}


	/**
	 * This method checks if the first list is a filtered output of second list(filter)
	 * @param actualList filter output
	 * @param userEnteredValues filter input
	 * @return true if the filter has worked correctly yes false
	 */
	public boolean assertFilterColumns(ArrayList<String> actualList,ArrayList<String> userEnteredValues){
		boolean assertionStatus = false;
		if(userEnteredValues.contains("No Customer")||userEnteredValues.contains("No Location")||userEnteredValues.contains("No Country")){
			userEnteredValues.add("");			
		}
		for (String actualValue : actualList) {	
			if(userEnteredValues.contains(actualValue))
				assertionStatus=true;
			else{
				assertionStatus=false;
				return assertionStatus;
			}
		}
		return assertionStatus;
	}

	public boolean isElementPresent(WebElement element){
		boolean elementPresent=true;
		try {

			element.isDisplayed();
		} catch (NoSuchElementException e) {
			elementPresent=false;
		}
		return elementPresent;
	}


	public boolean isCheckBoxSelected(WebElement element){
		if(element.getAttribute("checked").equals("checked"))
			return true;
		else
			return false;
	}

	public void moveToElement(WebElement toElement){
		Actions action = new Actions(driver);
		action.moveToElement(toElement).build().perform();		
	}

	public void moveToElementAndClickOnSubMenu(WebElement toElement,WebElement onElement, WebDriver driver){
		Actions action = new Actions(driver);
		action.moveToElement(toElement).clickAndHold().build().perform();
		new WebDriverWait(driver, 25).until(ExpectedConditions.visibilityOf(onElement));
		action.click(onElement).build().perform();	
	}

	public void rightClickOnElement(WebElement element,WebDriver driver){
		Actions action=new Actions(driver);
		action.contextClick(element).build().perform();
	}

	/**
	 * 
	 * @param length
	 * @return
	 */
	public static String getRandomString(int length) {
		final String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJLMNOPQRSTUVWXYZ1234567890";
		StringBuilder result = new StringBuilder();
		while(length > 0) {
			Random random = new Random();
			result.append(characters.charAt(random.nextInt(characters.length())));
			length--;
		}
		return result.toString();
	}

	/**
	 * This function is to scroll the browser window to a webelement using JavascriptExecutor
	 */
	public void scrollToElementUsingJavascriptExecutor(WebElement webElement)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",webElement);			
	}


}

