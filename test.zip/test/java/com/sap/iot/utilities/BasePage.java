package com.sap.iot.utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;


public abstract class BasePage extends BaseTest {
	
	public BasePage(WebDriver driver) {
		this.driver=super.getDriver();
		//AjaxElementLocatorFactory ajaxElementLocatorFactory=new AjaxElementLocatorFactory(this.driver, 120);
		PageFactory.initElements(driver, this);
	}
	protected WebDriver driver;	

	public abstract boolean hasPageLoaded();
	
	public boolean isPageTitleAsExpected(String title){
		return false;
	}
	public String getPageTitle(){
		return super.getDriver().getTitle();
	}

	public void keyPressENTER(){
		try {
			Robot robot=new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void keyPressESC(){
		try {
			Robot robot=new Robot();
			robot.delay(1000);
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.delay(1000);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void escape(){
		Actions action=new Actions(driver);
		action.sendKeys(Keys.ENTER).build().perform();
		action.sendKeys(Keys.ESCAPE).build().perform();
	}

}
