package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class AnalysisPageConfigurationPage extends BasePage{
	
	@FindBy(xpath="//label[text()='Information 1']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxInformation1;
	
	@FindBy(xpath="//label[text()='Information 2']/parent::div//following-sibling::div[1]//input")
	public WebElement dropBoxInformation2;
	
	@FindBy(xpath="//label[text()='28 Days']")
	public WebElement radioButton28Days;
	
	@FindBy(xpath="//label[text()='7 Days']")
	public WebElement radioButton7Days;
	
	@FindBy(xpath="//label[text()='24 Hours']")
	public WebElement radioButton24Hours;
	
	@FindBy(xpath="//label[text()='12 Hours']")
	public WebElement radioButton12Hours;
	
	@FindBy(xpath="//label[text()='1 Hour']")
	public WebElement radioButton1Hour;
	
	@FindBy(xpath="//label[text()='Show Time Slider']")
	public WebElement checkBoxShowTimeSlider;
	
	@FindBy(xpath="//label[text()='Show Events']")
	public WebElement checkBoxShowEventsInChart;
	
	@FindBy(xpath="//label[text()='Event List Title']/parent::div//following-sibling::div[1]//input")
	public WebElement textBoxEventListTitle;
	
	@FindBy(xpath="//bdi[text()='Finish']")
	public WebElement buttonFinish;
	
	@FindBy(xpath="//button[@aria-disabled='false' and @title='Next']")
	public WebElement buttonNextEnabled;
	
	@FindBy(xpath="//span[bdi[text()='Next']]")
	public WebElement buttonNext;

	public AnalysisPageConfigurationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}

}
