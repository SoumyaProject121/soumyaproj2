package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

// Created new page class 3/15/2021 
public class LandingPageEventList extends BasePage {

	public LandingPageEventList(WebDriver driver) {
		super(driver);
		
	}
	
	
	@FindBy(xpath="//div[label[bdi[text()='Include Thing Masterdata']]]//div[1]")
	public WebElement checkboxIncludeThingMasterdata;
	

	@FindBy(xpath="//div[span[@title='Sorting']]/following-sibling::div[2]//input")
	public WebElement inputSortingfield;
	
	@FindBy(xpath="//label[text()='Ascending']")
	public WebElement labelAscendingSortOrder;
	
	@FindBy(xpath="//label[text()='Descending']")
	public WebElement labelDescendingSortOrder;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[1]")
	public WebElement inputColoumn1;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[2]")
	public WebElement inputColoumn2;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[3]")
	public WebElement inputColoumn3;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[4]")
	public WebElement inputColoumn4;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[5]")
	public WebElement inputColoumn5;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[6]")
	public WebElement inputColoumn6;
	
	@FindBy(xpath="(//div[span[@title='Column Order']]/following-sibling::div[1]//input)[7]")
	public WebElement inputColoumn7;
	
	@FindBy(xpath="(//div[label[text()='Filter Bar']]/following-sibling::div[1]//input)[1]")
	public WebElement inputFilter1;
	
	@FindBy(xpath="(//div[label[text()='Filter Bar']]/following-sibling::div[1]//input)[2]")
	public WebElement inputFilter2;
	
	@FindBy(xpath="(//div[label[text()='Filter Bar']]/following-sibling::div[1]//input)[3]")
	public WebElement inputFilter3;
	
	@FindBy(xpath="(//div[label[text()='Filter Bar']]/following-sibling::div[1]//input)[4]")
	public WebElement inputFilter4;
	
	@FindBy(xpath="//div[span[text()='Navigation Target']]/following-sibling::div[2]//input")
	public WebElement inputNavigationTarget;

	@FindBy(xpath="//button[@title='Next']")
	//(xpath="//button[@aria-disabled='false' and @title='Next']")
	public WebElement buttonNextEnabled;
	
	
	@Override
	public boolean hasPageLoaded() {
		return false;
	}

}
