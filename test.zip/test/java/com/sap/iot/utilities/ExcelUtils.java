package com.sap.iot.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils
{

	public Object[][] loadDataFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(workbook.getActiveSheetIndex());
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet)-1;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		int numberOfSheets=workbook.getNumberOfSheets();
		System.out.println("No of sheets="+numberOfSheets+" column="+numberOfProjectsToBeCreated);
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			for(int sheetNo=0;sheetNo<numberOfSheets;sheetNo++){
				XSSFSheet sheetInLoop=workbook.getSheetAt(sheetNo);

				for (Row row : sheetInLoop) { 
					Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
					if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
						System.out.println(row.getCell(0).getStringCellValue()+" is empty in blank check");
						dataMap.put(row.getCell(0).getStringCellValue(), "");
					} 
					else{
						String columnContent=(String)objectFrom(workbook, cell);
						if(columnContent.equals(null)){
							System.out.println(row.getCell(0).getStringCellValue()+" is empty in else block");
							dataMap.put(row.getCell(0).getStringCellValue(), "");
						}
						else
							dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
					}
				}				
			}
			data[index] = new Object[] {dataMap};
			index++;
		}
		fis.close();
		return data;
	}

	public void writeProjectURLToExcel(String urlValue, String projectName,String FilePath){
		FileInputStream fis;
		try {
			fis = new FileInputStream(FilePath);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet2 = workbook.getSheet("Basic info");
			int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
			for(int col=1;col<=numberOfProjectsToBeCreated;col++){

				Cell cell=sheet2.getRow(0).getCell(col);
				if(cell==null||cell.getCellType()==Cell.CELL_TYPE_BLANK){
				}
				else{
					String projectNameInExcel=(String)objectFrom(workbook, cell);
					if(projectNameInExcel.equals(projectName)){
						System.out.println("Project name is found at "+sheet2.getRow(3).getCell(0).getStringCellValue());
						Cell cellToWrite=sheet2.getRow(3).getCell(col);
						if (cellToWrite==null||cellToWrite.getCellType()==Cell.CELL_TYPE_BLANK){
							cellToWrite = sheet2.getRow(3).createCell(col);			
						}  

						cellToWrite.setCellValue(urlValue);
						fis.close(); //Close the InputStream
						FileOutputStream outputFile =new FileOutputStream(new File(FilePath));  //Open FileOutputStream to write updates
						workbook.write(outputFile); //write changes
						outputFile.close();  //close the stream  
						break;
					}
				}	
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	//For reading basic details section
	public Object[][] getBasicDetailsFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet2 = workbook.getSheet("Basic info");
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
		int numberOfRows = 3;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			/*	getBasicDetailsData();
			getPageSelectionData();
			getLandingPageData();
			getThingListData();
			getThingPageData();
			getanalysisPageData();*/


			for (Row row : sheet2) { 
				Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				} 
				else{
					String columnContent=(String)objectFrom(workbook, cell);
					dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
				}
			}
			data[index] = new Object[] {dataMap};
			index++;
		}	
		fis.close();
		return data;
	}
	
	//For reading Data Source details section 2/24/2021
	
		public Object[][] getDataSourceDetailsFromSpreadsheet(String FilePath) throws IOException 
		{
			FileInputStream fis = new FileInputStream(FilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet2 = workbook.getSheet("Datasource Page");
			int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
			int numberOfRows = 3;
			int index = 0;
			Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
			for(int col=1;col<=numberOfProjectsToBeCreated;col++){
				LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			

				for (Row row : sheet2) { 
					Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
					if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
					} 
					else{
						String columnContent=(String)objectFrom(workbook, cell);
						dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
					}
				}
				data[index] = new Object[] {dataMap};
				index++;
			}	
			fis.close();
			return data;
		}
	
	
	//End 2/23/2021
	

	public Object[][] getPageSelectionDetailsFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet2 = workbook.getSheet("Page selection");
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
		int numberOfRows = 3;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			/*	getBasicDetailsData();
			getPageSelectionData();
			getLandingPageData();
			getThingListData();
			getThingPageData();
			getanalysisPageData();*/


			for (Row row : sheet2) { 
				Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				} 
				else{
					String columnContent=(String)objectFrom(workbook, cell);
					dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
				}
			}
			data[index] = new Object[] {dataMap};
			index++;
		}	
		fis.close();
		return data;
	}

	public Object[][] getLandingPageDetailsFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet2 = workbook.getSheet("Landing Page");
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
		int numberOfRows = 24;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			/*	getBasicDetailsData();
			getPageSelectionData();
			getLandingPageData();
			getThingListData();
			getThingPageData();
			getanalysisPageData();*/


			for (Row row : sheet2) { 
				Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				} 
				else{
					String columnContent=(String)objectFrom(workbook, cell);
					dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
				}
			}
			data[index] = new Object[] {dataMap};
			index++;
		}	
		fis.close();
		return data;
	}

	public Object[][] getThingListDetailsFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet2 = workbook.getSheet("Thing List");
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
		int numberOfRows = 11;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			/*	getBasicDetailsData();
			getPageSelectionData();
			getLandingPageData();
			getThingListData();
			getThingPageData();
			getanalysisPageData();*/


			for (Row row : sheet2) { 
				Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				} 
				else{
					String columnContent=(String)objectFrom(workbook, cell);
					dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
				}
			}
			data[index] = new Object[] {dataMap};
			index++;
		}	
		fis.close();
		return data;
	}

	public Object[][] getThingPageDetailsFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet2 = workbook.getSheet("Thing Page");
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
		int numberOfRows = 34;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			/*	getBasicDetailsData();
			getPageSelectionData();
			getLandingPageData();
			getThingListData();
			getThingPageData();
			getanalysisPageData();*/


			for (Row row : sheet2) { 
				Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				} 
				else{
					String columnContent=(String)objectFrom(workbook, cell);
					dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
				}
			}
			data[index] = new Object[] {dataMap};
			index++;
		}	
		fis.close();
		return data;
	}

	public Object[][] getAnalysisPageDetailsFromSpreadsheet(String FilePath) throws IOException 
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet2 = workbook.getSheet("Analysis Page");
		int numberOfProjectsToBeCreated = countNonEmptyColumns(sheet2)-1;
		int numberOfRows = 2;
		int index = 0;
		Object[][] data = new Object[numberOfProjectsToBeCreated][numberOfProjectsToBeCreated];
		for(int col=1;col<=numberOfProjectsToBeCreated;col++){
			LinkedHashMap<String, String> dataMap=new LinkedHashMap<>();
			/*	getBasicDetailsData();
			getPageSelectionData();
			getLandingPageData();
			getThingListData();
			getThingPageData();
			getanalysisPageData();*/


			for (Row row : sheet2) { 
				Cell cell = row.getCell(col); // Get the Cell at the Index / Column you want.
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				} 
				else{
					String columnContent=(String)objectFrom(workbook, cell);
					dataMap.put(row.getCell(0).getStringCellValue(), columnContent);
				}
			}
			data[index] = new Object[] {dataMap};
			index++;
		}	
		fis.close();
		return data;
	}

	public LinkedHashMap<String,String> getBasicDetailsData(LinkedHashMap<String,String> testDataMap){
		LinkedHashMap<String, String> testDataHashMap=new LinkedHashMap<>();

		return testDataHashMap;

	}

	public boolean isEmpty(Row row) 
	{
		Cell firstCell = row.getCell(0);
		boolean rowIsEmpty = (firstCell == null) || (firstCell.getCellType() == Cell.CELL_TYPE_BLANK);
		return rowIsEmpty;
	}


	/**
	 * Count the number of columns, using the number of non-empty cells in the
	 * first row.
	 */
	public int countNonEmptyColumns(Sheet sheet) 
	{
		Row firstRow = sheet.getRow(0);
		return firstEmptyCellPosition(firstRow);
	}


	public int firstEmptyCellPosition(Row cells) 
	{
		int columnCount = 0;
		for (Cell cell : cells) 
		{
			if (cell.getCellType() == Cell.CELL_TYPE_BLANK) 
			{
				break;
			}
			columnCount++;
		}
		return columnCount;
	}

	public Object objectFrom(XSSFWorkbook workbook, Cell cell) 
	{
		Object cellValue = null;
		int cellType=cell.getCellType();
		switch (cellType) {
		case 0:
			cellValue = cell.getNumericCellValue();
			break;
		case 1:
			cellValue = cell.getStringCellValue();
			break;
		case 2:
			cellValue = cell.getCellFormula();
			break;
		case 3:
			cellValue = cell.getRichStringCellValue().getString();
			break;
		case 4:
			cellValue = cell.getBooleanCellValue();
			break;
		case 5:
			cellValue = cell.getErrorCellValue();
			break;
		default:
			System.out.println("Unable to read data from execl for row "+cell.getRowIndex()+" and column "+cell.getColumnIndex());
		}
		return cellValue;
	}
}