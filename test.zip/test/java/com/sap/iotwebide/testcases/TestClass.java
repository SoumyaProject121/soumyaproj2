package com.sap.iotwebide.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.sap.iot.utilities.ExcelUtils;
import com.sap.iot.utilities.UtilityMethods;
import com.sap.iotwebide.pages.SAMLLogonPage;
import com.sap.iotwebide.pages.WebIDEHomePage;

public class TestClass extends UtilityMethods{
	WebDriver driver;
	WebDriverWait wait;

	//@org.junit.Test
	@Test
	public void projectDeploymentTest() throws IOException{

		//driver.get("https://webide-acb903337.dispatcher.hana.ondemand.com/");
		driver.get("https://webidecp-aqjuqi30uc.dispatcher.int.sap.eu2.hana.ondemand.com/");
		wait(15);
		SAMLLogonPage samlLogonPage=new SAMLLogonPage(driver);
		//samlLogonPage.login("sreya.kunjukrishnan@sap.com", "IoTtest1234");
		samlLogonPage.login("soumya.golla@sap.com", "Welcome@321");
		wait(15);
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.buttonWorkspace));
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonWorkspace));
		wait(20);
		webIDEHomePage.buttonWorkspace.click();
		wait(5);
		for (WebElement	element : webIDEHomePage.generatedProjectsList) {
			if(element.findElement(By.tagName("span")).getText().equals("VWCars")){
				rightClickOnElement(element,driver);
				wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.contextMenuDeploy));
				moveToElementAndClickOnSubMenu(webIDEHomePage.contextMenuDeploy, webIDEHomePage.contextMenuDeployToHCP,driver);
				wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.inputLogOnToSAP));
				webIDEHomePage.inputLogOnToSAP.sendKeys("I329033");
				webIDEHomePage.inputLogOnPassword.sendKeys("Vs@9496334472");
				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonLogin));
				webIDEHomePage.buttonLogin.click();

				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonDeploy));
				webIDEHomePage.buttonDeploy.click();
				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.linkOpenApplication));
				String generatedAppURL=webIDEHomePage.linkOpenApplication.getAttribute("href");
				Reporter.log(generatedAppURL+" is the generated application URL");
			}
		}
		String userDir = System.getProperty("user.dir");
		ExcelUtils excelUtil=new ExcelUtils();
		excelUtil.writeProjectURLToExcel("https://vwc-acb903337.dispatcher.hana.ondemand.com/?hc_reset", "DataSetupTest3",userDir+"/src/test/resources/TestData.xlsx");
	}

	@DataProvider(name="testData")
	public Object[][] getTestData(){
		System.out.println("In factory getTestData dataprovider");
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.loadDataFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

	@BeforeTest
	public void beforeClass(){

		System.out.println("In basetest before suite");
		//System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/test/resources/chromedriver/chromedriver_windows.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\C5318528\\git\\iot.ui.webideautomation\\src\\test\\resources\\chromedriver\\chromedriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		//options.addArguments("--disable-extensions");
		options.addArguments("start-maximized");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		driver=new ChromeDriver(capabilities);
		driver.manage().deleteAllCookies();

		wait=new WebDriverWait(driver, 120);
		//driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(120,TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);

	}

	public void wait(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
