/*package com.sap.iotwebide.testcases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.sikuli.script.FindFailed;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import com.sap.iot.utilities.BaseTest;
import com.sap.iot.utilities.ExcelUtils;
import com.sap.iotreuseui.pages.AnalysisReuseUIPage;
import com.sap.iotreuseui.pages.MapReuseUIPage;
import com.sap.iotreuseui.pages.ThingListReuseUIPage;
import com.sap.iotreuseui.pages.ThingPageReUseUIPage;


public class ReUseUITest extends BaseTest{
	LinkedHashMap<String, String> testDataMap=new LinkedHashMap<>();

	public ReUseUITest() {
		super();
	}

	public ReUseUITest(String baseURL,LinkedHashMap<String, String> dataMap) {
		super(baseURL,dataMap);
		this.testDataMap=dataMap;
	}

	@Test
	public void tc001_reUseSingleThingCardTest() throws AWTException{
		MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
		
		// To click on a pin which displays number as 1
		Screen screen=new Screen();
		ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
		try {
			screen.wait("SingleThingPin.PNG");
			//screen.
			screen.click("SingleThingPin.PNG");
		} catch (FindFailed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		wait(5);
		//Verify single thing card  header is as configured
		wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage.singleThingCardTitle));
		String singleThingCardTitle=mapReuseUIPage.singleThingCardTitle.getText();
		Reporter.log(singleThingCardTitle + " is the title for Single Thing Card");
		Assert.assertEquals(singleThingCardTitle,testDataMap.get("Single Card Title"));
		Assert.assertEquals(isElementPresent(mapReuseUIPage.singleThingCardHeaderImage), true);
		Assert.assertTrue(!mapReuseUIPage.singleThingCardHeaderInfo1.getText().isEmpty(), mapReuseUIPage.singleThingCardHeaderInfo1.getText()+" is the header info1");
		Assert.assertTrue(!mapReuseUIPage.singleThingCardHeaderInfo2.getText().isEmpty(), mapReuseUIPage.singleThingCardHeaderInfo2.getText()+" is the header info2");

		//Verify Events and Contact Section
		if(testDataMap.get("Single Card Event Enable").equalsIgnoreCase("Yes")||testDataMap.get("Single Card Contact Enable").equalsIgnoreCase("Yes")){
			for (WebElement element : mapReuseUIPage.singleThingCardBlockHeaders) {
				if(element.findElement(By.tagName("label")).getText().equals(testDataMap.get("Single Card Event Title"))){
					Assert.assertTrue(true, "Events Area Title is as configured");
					Reporter.log("<br></br>Events Area Title is as configured");
				}
				else if(element.findElement(By.tagName("label")).getText().equals(testDataMap.get("Single Card Contact Title"))){
					Assert.assertTrue(true, "Contact Area Title is as configured");
					Reporter.log("<br></br> Contact Area Title is as configured");
				}
			}
		}

		//Verify footer text
		if(!testDataMap.get("Single Card footer text").isEmpty())
			System.out.println(mapReuseUIPage.singleThingCardFooterButton.getText());
			
			Assert.assertEquals(mapReuseUIPage.singleThingCardFooterButton.getText(), testDataMap.get("Single Card footer text"));

		//Verify navigation from header
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
			mapReuseUIPage.singleThingCardHeaderInfo1.click();	
			ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
			wait(8);
			wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
			Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			driver.navigate().back();
			//thingPageReUseUIPage.buttonBack.click();
		}

		MapReuseUIPage mapReuseUIPage2=new MapReuseUIPage(driver);
		wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage2.singleThingCardTitle));
		mapReuseUIPage2.buttonCloseCard.click();
	}

	@Test
	public void tc002_reUsemultipleThingCardTest(){
		MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
		// To click on a pin which displays number greater than 1
		Screen screen=new Screen();
		ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
		try {
			screen.wait("OrangeCluster.PNG");
			screen.click("OrangeCluster.PNG");
		} catch (FindFailed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait(5);
		wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage.multipleThingCardTitle));
		Assert.assertEquals(mapReuseUIPage.multipleThingCardTitle.getText(), testDataMap.get("Multi Card title"));
		//Check for semantic bar, info 1 and info2,
		if(!testDataMap.get("Multi Card footer text").isEmpty())
			Assert.assertEquals(mapReuseUIPage.multipleThingCardFooterButton.getText(), testDataMap.get("Multi Card footer text"));
		if(!testDataMap.get("Multi Card footer navigation target").isEmpty()){
			mapReuseUIPage.multipleThingCardFooterButton.click();
			wait(5);
			ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
			Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
			driver.navigate().back();
		}			
	}

	@Test
	public void tc003_reUsethingPageTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}
	}

	@Test
	public void tc004_reUsemeasuredValuesTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}
	}

	@Test
	public void tc005_reUseEventListTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				//Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				//Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}

	}

	@Test
	public void tc006_reUseTimelineTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card Header Navigation").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardHeaderInfo1));
				mapReuseUIPage.singleThingCardHeaderInfo1.click();	
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
				Assert.assertEquals(thingPageReUseUIPage.headerThingPage.getText(), "");
				Assert.assertEquals(thingPageReUseUIPage.headerSubTitleThingPage.getText(), testDataMap.get(""));
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
				Assert.assertEquals(thingPageReUseUIPage.pageTitle.getText(), "Thing Page");
			}
		}

	}

	@Test
	public void tc007_reUseThingListTest(){
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
			// To click on a pin which displays number greater than 1
			Screen screen=new Screen();
			ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
			try {
				screen.wait("OrangeCluster.PNG");
				screen.click("OrangeCluster.PNG");
			} catch (FindFailed e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			wait(5);
			wait.until(ExpectedConditions.visibilityOf(mapReuseUIPage.multipleThingCardFooterButton));
			mapReuseUIPage.multipleThingCardFooterButton.click();
			ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
			Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
			
			thingListReuseUIPage.tableListItems.get(0).click();
			if(testDataMap.get("List navigation target").equalsIgnoreCase("Analysis Page")){
				AnalysisReuseUIPage analysisReuseUIPage=new AnalysisReuseUIPage(driver);
				Assert.assertEquals(analysisReuseUIPage.buttonSelectMPs.isDisplayed(), true);
			}
			else if(testDataMap.get("List navigation target").equalsIgnoreCase("Thing Page")){
				ThingPageReUseUIPage thingPageReUseUIPage=new ThingPageReUseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingPageReUseUIPage.pageTitle));
			}
		}
	}

	@Test
	public void tc008_reUseSensorChartTest() throws Exception{
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
			if(testDataMap.get("Single Card navigation target").equalsIgnoreCase("Analysis Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number as 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("SingleThingPin.PNG");
					screen.click("SingleThingPin.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				wait(6);
				wait.until(ExpectedConditions.elementToBeClickable(mapReuseUIPage.singleThingCardFooterButton));
				mapReuseUIPage.singleThingCardFooterButton.click();
				AnalysisReuseUIPage analysisReuseUIPage=new AnalysisReuseUIPage(driver);
				wait(6);
				wait.until(ExpectedConditions.visibilityOf(analysisReuseUIPage.pageTitle));
				Assert.assertEquals(analysisReuseUIPage.buttonSelectMPs.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonFullScreen.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonDynamicScaling.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button7Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button28Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button24Hours.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button1Hour.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button12Hours.isDisplayed(),true);
				analysisReuseUIPage.button28Days.click();
				wait(4);
				captureScreenshot("28DaysChart");
				analysisReuseUIPage.button7Days.click();
				wait(4);
				captureScreenshot("7DaysChart");
				analysisReuseUIPage.button24Hours.click();
				wait(4);
				captureScreenshot("24HoursChart");
				analysisReuseUIPage.button12Hours.click();
				wait(4);
				captureScreenshot("12HoursChart");
				analysisReuseUIPage.button1Hour.click();
				wait(4);
				captureScreenshot("1HourChart");
				analysisReuseUIPage.button28Days.click();
				wait(4);
				analysisReuseUIPage.buttonDynamicScaling.click();
				wait(2);
				captureScreenshot("dynamicScaling");
				analysisReuseUIPage.buttonFullScreen.click();
				wait(2);
				captureScreenshot("fullscreenChart");
				driver.navigate().back();
				wait(4);
			}
			else if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes") && testDataMap.get("List navigation target").equalsIgnoreCase("Analysis Page")){
				MapReuseUIPage mapReuseUIPage=new MapReuseUIPage(driver);
				// To click on a pin which displays number greater than 1
				Screen screen=new Screen();
				ImagePath.add(System.getProperty("user.dir")+"/src/test/resources/images");
				try {
					screen.wait("OrangeCluster.PNG");
					screen.click("OrangeCluster.PNG");
				} catch (FindFailed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapReuseUIPage.multipleThingCardFooterButton.click();
				ThingListReuseUIPage thingListReuseUIPage=new ThingListReuseUIPage(driver);
				wait.until(ExpectedConditions.visibilityOf(thingListReuseUIPage.pageTitle));
				Assert.assertEquals(thingListReuseUIPage.pageTitle.getText(), "Thing List");
				thingListReuseUIPage.tableListItems.get(0).click();
				AnalysisReuseUIPage analysisReuseUIPage=new AnalysisReuseUIPage(driver);
				wait(5);
				wait.until(ExpectedConditions.visibilityOf(analysisReuseUIPage.pageTitle));
				Assert.assertEquals(analysisReuseUIPage.buttonSelectMPs.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonFullScreen.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.buttonDynamicScaling.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button7Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button28Days.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button24Hours.isDisplayed(),true);
				Assert.assertEquals(analysisReuseUIPage.button1Hour.isDisplayed(), true);
				Assert.assertEquals(analysisReuseUIPage.button12Hours.isDisplayed(),true);
				analysisReuseUIPage.button28Days.click();
				wait(4);
				captureScreenshot("28DaysChart");
				analysisReuseUIPage.button7Days.click();
				wait(4);
				captureScreenshot("7DaysChart");
				analysisReuseUIPage.button24Hours.click();
				wait(4);
				captureScreenshot("24HoursChart");
				analysisReuseUIPage.button12Hours.click();
				wait(4);
				captureScreenshot("12HoursChart");
				analysisReuseUIPage.button1Hour.click();
				wait(4);
				captureScreenshot("1HourChart");
				analysisReuseUIPage.button28Days.click();
				wait(4);
				analysisReuseUIPage.buttonDynamicScaling.click();
				wait(2);
				captureScreenshot("dynamicScaling");
				analysisReuseUIPage.buttonFullScreen.click();
				wait(2);
				captureScreenshot("fullscreenChart");
				driver.navigate().back();
				wait(4);
			}
		}

	}

	@DataProvider(name="testData")
	public Object[][] getTestData(){
		System.out.println("In ReUseUITest getTestData dataprovider");
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.loadDataFromSpreadsheet(userDir+"/src/test/resources/TestDataDemo.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

}
*/