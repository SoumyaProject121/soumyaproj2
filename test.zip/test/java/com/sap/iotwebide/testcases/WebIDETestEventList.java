package com.sap.iotwebide.testcases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.sikuli.script.FindFailed;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.sap.iot.utilities.BaseTest;
import com.sap.iot.utilities.ExcelUtils;
import com.sap.iotreuseui.pages.AnalysisReuseUIPage;
import com.sap.iotreuseui.pages.MapReuseUIPage;
import com.sap.iotreuseui.pages.ThingListReuseUIPage;
import com.sap.iotreuseui.pages.ThingPageReUseUIPage;
import com.sap.iotwebide.pages.AnalysisPageConfigurationPage;
import com.sap.iotwebide.pages.ApplicationMainpage;
import com.sap.iotwebide.pages.BasicInformationPage;
import com.sap.iotwebide.pages.DataConnetionPage;
import com.sap.iotwebide.pages.DataSourcePage;
import com.sap.iotwebide.pages.LandingPage;
import com.sap.iotwebide.pages.LandingPageEventList;
import com.sap.iotwebide.pages.LandingpageMapwithFilter;
import com.sap.iotwebide.pages.OverLayComponents;
import com.sap.iotwebide.pages.SelectPagesPage;
import com.sap.iotwebide.pages.TemplateSelectionPage;
import com.sap.iotwebide.pages.ThingListConfigPage;
import com.sap.iotwebide.pages.ThingPage;
import com.sap.iotwebide.pages.WebIDEHomePage;

public class WebIDETestEventList extends BaseTest {
	LinkedHashMap<String, String> testDataMap=new LinkedHashMap<>();
	String projectName;
	String generatedAppURL="";
	/*public WebIDETest() {
		super();
		System.out.println("In WebIDETest()");
	}*/

	public WebIDETestEventList(String baseURL,LinkedHashMap<String, String> dataMap) {
		super(baseURL,dataMap);
		System.out.println("In WebIDETest(URL, map)");
		this.testDataMap=dataMap;
		projectName=testDataMap.get("Project Name").concat(getRandomString(3));
		System.out.println("test123");

	}

	@Test(groups={"pluginTest"})
	public void tc001_webide_pluginConnectivityInLocalRepoTest(){
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		System.out.println("starting tc001");
		wait(20);
		webIDEHomePage.homebutton.click();
		wait(5);
		webIDEHomePage.createNewProjectFromIoTTemplate();
		wait(10);
		TemplateSelectionPage templateSelectionPage=new TemplateSelectionPage(driver);
		wait.until(ExpectedConditions.visibilityOf(templateSelectionPage.comboBoxTemplateCategory));
		templateSelectionPage.comboBoxTemplateCategory.click();
		wait(5);
		Assert.assertTrue(templateSelectionPage.listItemInternetOfThings.isDisplayed(), "Internet Of Things template is available");
		templateSelectionPage.listItemInternetOfThings.click();
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.templateIoT));
		templateSelectionPage.templateIoT.click();
		wait(15);
		//wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.buttonNextEnabled));
		//templateSelectionPage.buttonNextEnabled.click();
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.buttonNext)); //added 2/24/2021
		templateSelectionPage.buttonNext.click();


	}
	
	@Test(dependsOnGroups="pluginTest")
	public void tc002_webide_basicDetailsTest(){
		System.out.println("starting tc002...");
		BasicInformationPage basicInformationPage=new BasicInformationPage(driver);
		wait.until(ExpectedConditions.visibilityOf(basicInformationPage.textBoxProjectName));
		
		basicInformationPage.textBoxProjectName.sendKeys(projectName);
		basicInformationPage.textBoxNamespace.sendKeys(testDataMap.get("Namespace"));
		basicInformationPage.textBoxTitle.sendKeys(testDataMap.get("Title"));
		Assert.assertTrue(basicInformationPage.buttonNext.isEnabled(),"Next button is enabled");
		basicInformationPage.buttonNext.click();
	}
	
	// DataSource page 2/24/2021
	@Test(dependsOnMethods="tc002_webide_basicDetailsTest")
	public void tc003_webide_datasourceTest() throws AWTException{
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
	System.out.println("starting tc003..");
	DataSourcePage datasource = new DataSourcePage(driver);
	datasource.dropDownService.sendKeys(testDataMap.get("Service"));
	datasource.selectdropDown.click();
	//wait(20);
	datasource.thingPropertySetsIcon.click();
	wait(5);
	datasource.selectThingTypeTxtbox.sendKeys(testDataMap.get("ThingPropertysets_ThingType"));
	wait(10);
	Robot robot=new Robot();
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	//wait(15);
	wait.until(ExpectedConditions.elementToBeClickable(datasource.propertsetofThingtype));
	datasource.propertsetofThingtype.click();
	wait(10);
	datasource.okbutton.click();
	//wait(20);
	//Alert alert=driver.switchTo().alert();
	//alert.accept();	
	wait.until(ExpectedConditions.elementToBeClickable(datasource.eventPropertySetsIcon));
	datasource.eventPropertySetsIcon.click();
	//wait(10);
	datasource.eventTypeTxtbox.click();// sendKeys(Keys.ENTER);
	wait(5);
	wait.until(ExpectedConditions.elementToBeClickable(datasource.searchEventType));
	datasource.searchEventType.sendKeys(testDataMap.get("EventPropertysets_EventType"));
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	wait(5);
	datasource.elementselectable.click();
	wait.until(ExpectedConditions.elementToBeClickable(datasource.propertsetofEventtype));
	datasource.propertsetofEventtype.click();
	wait(5);
	datasource.okbutton.click();
	Assert.assertTrue(datasource.buttonNext.isEnabled(),"Next button is enabled");
	datasource.buttonNext.click();
	wait(10);
	}
	
/* End using data source

	@Test(dependsOnMethods="tc002_webide_basicDetailsTest")
	public void tc003_webide_dataConnectionTest(){
		DataConnetionPage dataConnetionPage=new DataConnetionPage(driver);
		wait.until(ExpectedConditions.elementToBeClickable(dataConnetionPage.liServiceURL));
		dataConnetionPage.liServiceURL.click();
		dataConnetionPage.comboBoxSelectASystem.click();
		dataConnetionPage.liSystemName.click();
		//	Assert.assertFalse(dataConnetionPage.buttonNext.isEnabled(),"Next button is disabled");
		wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.textBoxServiceName));
		dataConnetionPage.textBoxServiceName.sendKeys("CompositeThings/v1");
		dataConnetionPage.buttonTest.click();
		wait(100);
		//wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNextEnabled));
		wait.until(ExpectedConditions.elementToBeClickable(dataConnetionPage.buttonNextEnabled));
		/*try{
		wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNext));*/
		//DataConnetionPage dataConnetionPage2=new DataConnetionPage(driver);
		//wait.until(ExpectedConditions.stalenessOf(dataConnetionPage.buttonNext));
		//	while(!dataConnetionPage.buttonNext.isEnabled()){
		//wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(dataConnetionPage.buttonNext)));
		/*wait.until(ExpectedConditions.attributeToBe(dataConnetionPage.buttonNext, "aria-disabled", "false"));

		//	}
		}catch(StaleElementReferenceException e){
			wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNext));
		}*/

		//dataConnetionPage.buttonNextEnabled.click();		
	//} */

	@Test(dependsOnMethods="tc003_webide_datasourceTest")
	public void tc004_webide_selectPagesTest(){
		System.out.println("starting tc004");
		SelectPagesPage selectPagesPage=new SelectPagesPage(driver);
		selectPagesPage.inputpageselection.clear();
		wait(3);
		selectPagesPage.inputpageselection.sendKeys(testDataMap.get("SelectpageEvent"));
		wait(8);
		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelSelectPages));
		wait(10);
		Assert.assertEquals(selectPagesPage.labelSelectPages.getText(), "Select Pages");
		Assert.assertEquals(selectPagesPage.labelSelectThePagesYouWant.getText(), "Select the pages you want to use in your application");

		//Assert.assertEquals(selectPagesPage.labelLandingPageEventlist.isDisplayed(), true, "Landing Page - Event List");
		//Assert.assertEquals(selectPagesPage.labelLandingPageEventlist.isDisplayed(), true);


		Assert.assertEquals(selectPagesPage.labelThingPage.isDisplayed(), true, "Thing page is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxThingPage.isEnabled(), true);
		Assert.assertEquals(selectPagesPage.imageThingPage .isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelAnalysisPage.isDisplayed(), true, "Analysis page is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxAnalysisPage.isEnabled(), true);
		Assert.assertEquals(selectPagesPage.imageAnalysisPage.isDisplayed(), true);
		
		//selectPagesPage.buttonNext.click();
	}


	@Test(dependsOnMethods="tc004_webide_selectPagesTest")
	public void tc005_webide_pageSelectionTest(){
		System.out.println("starting tc005..");
		OverLayComponents overLayComponents=new OverLayComponents(driver);
		SelectPagesPage selectPagesPage=new SelectPagesPage(driver);
		wait(5);
		
		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelThingPage));
		selectPagesPage.labelThingPage.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbThingPage));
		selectPagesPage.labelThingPage.click();
		wait(5);
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbThingPage));

		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelAnalysisPage));
		selectPagesPage.labelAnalysisPage.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbAnalysisPage));
		selectPagesPage.labelAnalysisPage.click();
		wait(5);
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbAnalysisPage));
		selectPagesPage.buttonNext.click();
		/* Below steps to create application with default value selection in pages	
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		selectPagesPage.buttonNext.click();
		wait(10);
		driver.findElement(By.xpath("//bdi[text()='Finish']")).click();*/
	}

	@Test(dependsOnMethods="tc005_webide_pageSelectionTest")
	public void tc006_webide_landingPageEventlistConfigurationTest() throws AWTException{
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		LandingPageEventList landingPageEvent =new LandingPageEventList(driver);
		wait(10);
		landingPageEvent.inputSortingfield.clear();
		wait(5);
		landingPageEvent.inputSortingfield.sendKeys(testDataMap.get("EventList Sorting Field"));
		wait(5);
		landingPageEvent.inputColoumn1.clear();
		wait(5);
		landingPageEvent.inputColoumn1.sendKeys(testDataMap.get("EventList Column1"));
		wait(5);
		landingPageEvent.inputColoumn2.clear();
		landingPageEvent.inputColoumn2.sendKeys(testDataMap.get("EventList Column2"));
		wait(2);
		landingPageEvent.inputColoumn3.clear();
		landingPageEvent.inputColoumn3.sendKeys(testDataMap.get("EventList Column3"));
		wait(5);
		Robot robot=new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		//landingPageEvent.inputColoumn3.clear();
		//landingPageEvent.inputColoumn3.sendKeys(testDataMap.get("EventList Column3"));
		wait.until(ExpectedConditions.elementToBeClickable(landingPageEvent.buttonNextEnabled));
		landingPageEvent.buttonNextEnabled.click();
		wait(2);
		//landingPage.buttonNextEnabled.click();
	}

	 
	
	 @Test(enabled=false,dependsOnMethods="tc006_webide_landingPageConfigurationTest")
	public void tc007_webide_thingListConfigurationTest(){
		 System.out.println("starting tc006..");
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			ThingListConfigPage thingListConfigPage=new ThingListConfigPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListConfigPage.textBoxTitle));
			thingListConfigPage.textBoxTitle.sendKeys(testDataMap.get("ThingListTitle"));
			thingListConfigPage.inputSortingField.clear();
			thingListConfigPage.inputSortingField.sendKeys(testDataMap.get("Default sort field"));
			wait(2);
			if(testDataMap.get("Sort Direction").equalsIgnoreCase("Descending"))
				thingListConfigPage.radioButtonDescending.click();
			thingListConfigPage.inputColumn2.clear();
			thingListConfigPage.inputColumn2.sendKeys(testDataMap.get("Column 2"));
			wait(2);
			thingListConfigPage.inputColumn3.clear();
			wait(2);
			thingListConfigPage.inputColumn3.sendKeys(testDataMap.get("Column 3"));
			thingListConfigPage.inputColumn4.clear();
			thingListConfigPage.inputColumn4.sendKeys(testDataMap.get("Column 4"));
			wait(5);
			thingListConfigPage.inputColumn5.clear();
			thingListConfigPage.inputColumn5.sendKeys(testDataMap.get("Column 5"));
			wait(2);
			thingListConfigPage.inputColumn6.clear();
			thingListConfigPage.inputColumn6.sendKeys(testDataMap.get("Column 6"));
			wait(2);
			thingListConfigPage.inputColumn7.clear();
			thingListConfigPage.inputColumn7.sendKeys(testDataMap.get("Column 7"));
			wait(2);
			thingListConfigPage.inputColumn8.clear();
			thingListConfigPage.inputColumn8.sendKeys(testDataMap.get("Column 8"));
			wait(2);
			thingListConfigPage.comboBoxListItemNavTarget.clear();
			thingListConfigPage.comboBoxListItemNavTarget.sendKeys(testDataMap.get("List navigation target"));
			wait.until(ExpectedConditions.elementToBeClickable(thingListConfigPage.buttonNext));
			thingListConfigPage.buttonNext.click();
			wait(10);
			thingListConfigPage.buttonNext.click();
		}else
			Reporter.log("Test case for thinglist is skipped");
		
	}

	@Test(dependsOnMethods="tc006_webide_landingPageEventlistConfigurationTest")
	public void tc008_webide_thingPageConfigurationTest() throws AWTException{
		
		
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			ThingPage thingPage=new ThingPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingPage.dropBoxInformation1));
			thingPage.dropBoxInformation1.clear();
			thingPage.dropBoxInformation1.sendKeys(testDataMap.get("Header Info1"));
			//Robot robot=new Robot();
			//robot.keyPress(KeyEvent.VK_ENTER);
			//robot.keyRelease(KeyEvent.VK_ENTER);
			wait(5);
			thingPage.dropBoxInformation2.clear();
			thingPage.dropBoxInformation2.sendKeys(testDataMap.get("Header Info2"));
			wait(5);
			thingPage.dropBoxInformation3.clear();
			thingPage.dropBoxInformation3.sendKeys(testDataMap.get("Header Info3"));
			wait(5);
			Robot robot=new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			wait(5);
			scrollPageToBottom();
			//wait.until(ExpectedConditions.visibilityOf(thingPage.checkboxContentBasicData));
			if(testDataMap.get("Basic Data Enable").equalsIgnoreCase("Yes")){
				thingPage.dropBoxColumn1Info1.clear();
				wait(2);
				thingPage.dropBoxColumn1Info1.sendKeys(testDataMap.get("Column1 info1"));

				thingPage.dropBoxColumn2Info1.clear();
				thingPage.dropBoxColumn2Info1.sendKeys(testDataMap.get("Column 2 info1"));
				wait(2);
				thingPage.dropBoxColumn3Info1.clear();
				thingPage.dropBoxColumn3Info1.sendKeys(testDataMap.get("Column 3 info1"));
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				/* Checks if user wants to add additional data into basic details for column1
				 * if in data sheet, data exists for additional info, then click on add button for column1
				 * and enter the data.
				 */
	
			/*	for(int i=3;i<6;i++){
					if(!testDataMap.get("Column1 info"+i).isEmpty()) {
						thingPage.buttonAddList.get(0).click();
						thingPage.dropDownColumn1List.get(i-1).clear();
						thingPage.dropDownColumn1List.get(i-1).sendKeys(testDataMap.get("Column1 info"+i));
						wait(2);
					}		
				}
				wait(2);
				for(int j=3;j<6;j++){
					if(!testDataMap.get("Column 2 info"+j).isEmpty()) {
						thingPage.buttonAddList.get(1).click();
						thingPage.dropDownColumn2List.get(j-1).clear();
						thingPage.dropDownColumn2List.get(j-1).sendKeys(testDataMap.get("Column 2 info"+j));
						wait(2);
					}		
				}
				wait(2);
				for(int i=3;i<6;i++){
					if(!testDataMap.get("Column 3 info"+i).isEmpty()) {
						thingPage.buttonAddList.get(2).click();
						thingPage.dropDownColumn3List.get(i-1).clear();
						thingPage.dropDownColumn3List.get(i-1).sendKeys(testDataMap.get("Column 3 info"+i));
						wait(2);
					}		
				} */

			}

			wait(5);

			wait.until(ExpectedConditions.elementToBeClickable(thingPage.buttonNextEnabled));
			thingPage.buttonNextEnabled.click();
		}else
			Reporter.log("Test case for thing page is skipped");
	
	}

	@Test(dependsOnMethods="tc008_webide_thingPageConfigurationTest")//tc008_webide_thingPageConfigurationTest")
	public void tc009_webide_analysisPageConfigurationTest(){
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
			AnalysisPageConfigurationPage analysisConfigurationPage= new AnalysisPageConfigurationPage(driver);
			wait.until(ExpectedConditions.visibilityOf(analysisConfigurationPage.dropBoxInformation1));
			analysisConfigurationPage.dropBoxInformation1.clear();
			wait(3);
			analysisConfigurationPage.dropBoxInformation1.sendKeys(testDataMap.get("Header Info1"));
			wait(2);
			analysisConfigurationPage.dropBoxInformation2.clear();
			wait(3);
			analysisConfigurationPage.dropBoxInformation2.sendKeys(testDataMap.get("Header Info2"));
			wait.until(ExpectedConditions.visibilityOf(analysisConfigurationPage.radioButton7Days));
			if(testDataMap.get("Default Time Period").equalsIgnoreCase("28 Days"))
				analysisConfigurationPage.radioButton28Days.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("7 Days"))
				analysisConfigurationPage.radioButton7Days.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("24 Hours"))
				analysisConfigurationPage.radioButton24Hours.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("12 Hours"))
				analysisConfigurationPage.radioButton12Hours.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("1 Hour"))
				analysisConfigurationPage.radioButton1Hour.click();

			//if(testDataMap.get("Time Slider Enable").equalsIgnoreCase("No"))
				//analysisConfigurationPage.checkBoxShowTimeSlider.click();	
			/**
			 * Events on chart is not released
			 */
			/*if(testDataMap.get("Events Enable").equalsIgnoreCase("No"))
				analysisConfigurationPage.checkBoxShowEventsInChart.click();
			else{
				Assert.assertTrue(isElementPresent(analysisConfigurationPage.textBoxEventListTitle));
				analysisConfigurationPage.textBoxEventListTitle.sendKeys(testDataMap.get("Event List Title"));
			}*/

			analysisConfigurationPage.buttonFinish.click();
		}else
			Reporter.log("Test case for analysis page is skipped");
	}
	
	
	
	@Test(dependsOnMethods="tc009_webide_analysisPageConfigurationTest")
	public void tc010_webide_gnerationOfApplication(){
		
		System.out.println("new project created");
		wait(30);
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.buttonWorkspace));
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonWorkspace));
		wait(10);
		String title = driver.getTitle();
		System.out.println(title);
		//String projectName1=testDataMap.get("Project Name").concat(getRandomString(3).toString());
		//System.out.println(projectName1);
		for (WebElement	element : webIDEHomePage.generatedProjectsList) {
			
			if(element.findElement(By.tagName("span")).getText().equals(testDataMap.get("Project Name")))
			{
				//element.click();
				wait(2);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.Namespacemenu));
		webIDEHomePage.Namespacemenu.click();
		wait(20);
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.runbutton));
		//To switch control to new tab
		/*String oldTab = driver.getWindowHandle();
	    System.out.println(oldTab);
		webIDEHomePage.runbutton.click();
		wait(10);
		for(String newtab:driver.getWindowHandles())
		{
			driver.switchTo().window(newtab);
		}*/

		wait(10);
		
	}
		}
	}
	
	
	@Test(enabled=false,dependsOnMethods="tc010_webide_gnerationOfApplication")
	public void tc011_webide_verifyApplication(){
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		String oldTab = driver.getWindowHandle();
	    System.out.println(oldTab);
		webIDEHomePage.runbutton.click();
		wait(10);
		for(String newtab:driver.getWindowHandles())
		{
			driver.switchTo().window(newtab);
		}
		System.out.println("Generated new application");
		String title = driver.getTitle();
		System.out.println(title);
		wait(5);
		
		
	}

	
	}
	
	
		

	


