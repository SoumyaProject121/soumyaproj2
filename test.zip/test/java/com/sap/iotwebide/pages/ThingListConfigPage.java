package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class ThingListConfigPage extends BasePage{

	public ThingListConfigPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath="//div[label[text()='Title']]/following-sibling::div/input")
	public WebElement textBoxTitle;

	@FindBy(xpath="//div[span[text()='Sorting']]/following-sibling::div[2]//input")
	public WebElement inputSortingField;

	@FindBy(xpath="//label[text()='Ascending']")
	public WebElement radioButtonAscending;

	@FindBy(xpath="//label[text()='Descending']")
	public WebElement radioButtonDescending;

	@FindBy(xpath="//div[label[text()='Column 2']]/following-sibling::div[1]//input")
	public WebElement inputColumn2;

	@FindBy(xpath="//div[label[text()='Column 3']]/following-sibling::div[1]//input")
	public WebElement inputColumn3;

	@FindBy(xpath="//div[label[text()='Column 4']]/following-sibling::div[1]//input")
	public WebElement inputColumn4;

	@FindBy(xpath="//div[label[text()='Column 5']]/following-sibling::div[1]//input")
	public WebElement inputColumn5;

	@FindBy(xpath="//div[label[text()='Column 6']]/following-sibling::div[1]//input")
	public WebElement inputColumn6;

	@FindBy(xpath="//div[label[text()='Column 7']]/following-sibling::div[1]//input")
	public WebElement inputColumn7;

	@FindBy(xpath="//div[label[text()='Column 8']]/following-sibling::div[1]//input")
	public WebElement inputColumn8;

	@FindBy(xpath="//div[label[text()='List Item Navigation Target']]/following-sibling::div//input")
	public WebElement comboBoxListItemNavTarget;

	@FindBy(xpath="//label[text()='Column 1']/parent::div/following-sibling::div[1]//input[@value='Thing Image']")
	public WebElement inputColumn1;

	@FindBy(xpath="//button[@title='Next']")
	public WebElement buttonNext;

	@FindBy(xpath="//button[@title='Previous']")
	public WebElement buttonPrevious;


	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}

}
