package com.sap.iotwebide.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\C5318528\\git\\iot.ui.webideautomation\\src\\test\\resources\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://webidecp-aqjuqi30uc.dispatcher.int.sap.eu2.hana.ondemand.com/");

	}

}
