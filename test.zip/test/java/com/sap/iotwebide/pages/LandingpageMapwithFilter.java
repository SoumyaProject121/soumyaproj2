package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class LandingpageMapwithFilter extends BasePage{

	public LandingpageMapwithFilter(WebDriver driver) {
		super(driver);
		
	}
	
	@FindBy(xpath="//div[label[@title='Settings for Geo Clustering']]//following-sibling::div[3]//input")
	public WebElement inputThingtype;
	
	@FindBy(xpath="//div[label[@title='Settings for Geo Clustering']]//following-sibling::div[5]//input")
	public WebElement inputThingPropertSet;
	
	@FindBy(xpath="//div[label[@title='Settings for Geo Clustering']]//following-sibling::div[7]//input")
	public WebElement inputPropertForLatitude;
	
	@FindBy(xpath="//div[label[@title='Settings for Geo Clustering']]//following-sibling::div[9]//input")
	public WebElement inputPropertyForLongitude;
	
	@FindBy(xpath="//div[label[text()='List Header ']]//following-sibling::div[2]//input")
	public WebElement inputTitle;
	
	@FindBy(xpath="//div[label[text()='List Header ']]//following-sibling::div[2]//input")
	public WebElement inputInformation1;
	
	@FindBy(xpath="//div[label[text()='List Header ']]//following-sibling::div[2]//input")
	public WebElement inputInformation2;
	
	@FindBy(xpath="//div[label[text()='List Header ']]//following-sibling::div[2]//input")
	public WebElement inputInformation3;
	
	@FindBy(xpath="//label[text()='Ascending']")
	public WebElement labelAscendingSortOrder;
	
	@FindBy(xpath="//label[text()='Descending']")
	public WebElement labelDescendingSortOrder;
	
	@FindBy(xpath="//div[span[text()='Thing Card - Single Object']]/parent::div//input")
	public WebElement inputDetailTitle;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[2]//input")
	public WebElement inputDetailViewHeaderInfo1;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[4]//input")
	public WebElement inputDetailViewHeaderInfo2;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[6]//input") 
	public WebElement inputDetailViewHeaderInfo3;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[8]//input")
	public WebElement inputDetailViewHeaderNavigation;
	
	@FindBy(xpath="//div[label[bdi[text()='Event']]]//div[1]")
	public WebElement checkboxEvent;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[1]//input")
	public WebElement inputEventAreaTitle;
	
	@FindBy(xpath="//div[label[bdi[text()='Contact Information']]]//div[1]")
	public WebElement checkboxContactInfo;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[1]//input")
	public WebElement inputContactInfoAreaTitle;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[3]//input")
	public WebElement inputContactInfo1;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[5]//input")
	public WebElement inputContactInfo2;
	
	@FindBy(xpath="//div[label[text()='Footer']]//following-sibling::div[2]//input")
	public WebElement inputListCardFooterText;
	
	@FindBy(xpath="(//div[label[text()='Footer']])[2]//following-sibling::div[4]/input")
	public WebElement inputListCardFooterNavigation;
	
	@FindBy(xpath="(//span[@class='sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer sapMInputBaseIcon'])[1]")
	public WebElement thingtypedropdownicon;
	
	@FindBy(xpath="//div[text()='iotae.sandboxdevx03.test.automobiles:CarsThingType']")
	public WebElement thingtypeselectvalue;
	
	@FindBy(xpath="(//span[@class='sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer sapMInputBaseIcon'])[1]")
	public WebElement longitutedropdownicon;
	
	@FindBy(xpath="(//div[text()='LicenseNumber'])[1]")
	public WebElement longitutepeselectvalue;
	
	@FindBy(xpath="//button[@title='Next']")
	public WebElement buttonNextEnabled;
	

@Override
public boolean hasPageLoaded() {
	// TODO Auto-generated method stub
	return false;
}
}