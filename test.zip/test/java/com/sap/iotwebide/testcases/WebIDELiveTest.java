package com.sap.iotwebide.testcases;

import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.sap.iot.utilities.BaseTest;
import com.sap.iot.utilities.ExcelUtils;
import com.sap.iotwebide.pages.AnalysisPageConfigurationPage;
import com.sap.iotwebide.pages.BasicInformationPage;
import com.sap.iotwebide.pages.DataConnetionPage;
import com.sap.iotwebide.pages.LandingPage;
import com.sap.iotwebide.pages.OverLayComponents;
import com.sap.iotwebide.pages.SelectPagesPage;
import com.sap.iotwebide.pages.TemplateSelectionPage;
import com.sap.iotwebide.pages.ThingListConfigPage;
import com.sap.iotwebide.pages.ThingPage;
import com.sap.iotwebide.pages.WebIDEHomePage;



/**
 * @author I329033
 *
 */
public class WebIDELiveTest extends BaseTest {
	LinkedHashMap<String, String> testDataMap=new LinkedHashMap<>();

/*	public WebIDELiveTest() {
		super();
		System.out.println("In WebIDETest()");
	}*/

	public WebIDELiveTest(String baseURL,LinkedHashMap<String, String> dataMap) {
		super(baseURL,dataMap);
		System.out.println("In WebIDETest(URL, map)");
		testDataMap=dataMap;
	}

	
	@Test(groups={"pluginTest"})
	public void pluginConnectivityFromSAPPluginTest(){
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		webIDEHomePage.goToPluginsSection();
		
		//Following 2 lines of code will have to be deleted if there is no test repository available in web ide account
		webIDEHomePage.selectIoTRepositoryAsRepository();
		webIDEHomePage.disableLocalTestingPlugin();
		
		webIDEHomePage.goToPluginsSection();
		webIDEHomePage.selectSAPPluginAsRepository();
		webIDEHomePage.enableSAPIoTPlugin();
		
		wait(20);
		//click on File Menu > New >Project from template
		webIDEHomePage.createNewProjectFromIoTTemplate();
		wait(15);

		//Check if Internet of Things is listed as a template
		TemplateSelectionPage templateSelectionPage=new TemplateSelectionPage(driver);
		templateSelectionPage.comboBoxTemplateCategory.click();
		Assert.assertTrue(templateSelectionPage.listItemInternetOfThings.isDisplayed(), "Internet Of Things template is available");
		templateSelectionPage.listItemInternetOfThings.click();
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.templateIoT));
		templateSelectionPage.templateIoT.click();
		wait(5);
		wait.until(ExpectedConditions.elementToBeClickable(templateSelectionPage.buttonNextEnabled));
		templateSelectionPage.buttonNextEnabled.click();
	}

	@Test(dependsOnGroups="pluginTest")
	public void basicDetailsTest(){
		BasicInformationPage basicInformationPage=new BasicInformationPage(driver);
		wait.until(ExpectedConditions.visibilityOf(basicInformationPage.textBoxProjectName));
		basicInformationPage.textBoxProjectName.sendKeys(testDataMap.get("Project Name"));
		basicInformationPage.textBoxNamespace.sendKeys(testDataMap.get("Namespace"));
		basicInformationPage.textBoxTitle.sendKeys(testDataMap.get("Title"));
		Assert.assertTrue(basicInformationPage.buttonNext.isEnabled(),"Next button is enabled");
		basicInformationPage.buttonNext.click();
	}


	@Test(dependsOnMethods="basicDetailsTest")
	public void dataConnectionTest(){
		DataConnetionPage dataConnetionPage=new DataConnetionPage(driver);
		wait.until(ExpectedConditions.elementToBeClickable(dataConnetionPage.liServiceURL));
		dataConnetionPage.liServiceURL.click();
		dataConnetionPage.comboBoxSelectASystem.click();
		dataConnetionPage.liSystemName.click();
		//	Assert.assertFalse(dataConnetionPage.buttonNext.isEnabled(),"Next button is disabled");
		dataConnetionPage.textBoxServiceName.sendKeys("CompositeThings/v1");
		dataConnetionPage.buttonTest.click();
		wait(100);
		//wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNextEnabled));
		wait.until(ExpectedConditions.elementToBeClickable(dataConnetionPage.buttonNextEnabled));
		/*try{
		wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNext));*/
		//DataConnetionPage dataConnetionPage2=new DataConnetionPage(driver);
		//wait.until(ExpectedConditions.stalenessOf(dataConnetionPage.buttonNext));
		//	while(!dataConnetionPage.buttonNext.isEnabled()){
		//wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(dataConnetionPage.buttonNext)));
		/*wait.until(ExpectedConditions.attributeToBe(dataConnetionPage.buttonNext, "aria-disabled", "false"));

		//	}
		}catch(StaleElementReferenceException e){
			wait.until(ExpectedConditions.visibilityOf(dataConnetionPage.buttonNext));
		}*/

		dataConnetionPage.buttonNextEnabled.click();		
	}

	@Test(dependsOnMethods="dataConnectionTest")
	public void selectPagesTest(){
		SelectPagesPage selectPagesPage=new SelectPagesPage(driver);
		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelSelectPages));
		wait(10);
		Assert.assertEquals(selectPagesPage.labelSelectPages.getText(), "Select Pages");
		Assert.assertEquals(selectPagesPage.labelSelectThePagesYouWant.getText(), "Select the pages you want to use in your application");

		Assert.assertEquals(selectPagesPage.labelLandingPage.isDisplayed(), true, "Landing page is displayed");
		Assert.assertEquals(selectPagesPage.imageLandingPage.isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelThingList.isDisplayed(), true, "Thing List is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxThingList.isEnabled(), true);

		Assert.assertEquals(selectPagesPage.imageThingList.isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelThingPage.isDisplayed(), true, "Thing page is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxThingPage.isEnabled(), true);
		Assert.assertEquals(selectPagesPage.imageThingPage .isDisplayed(), true);

		Assert.assertEquals(selectPagesPage.labelAnalysisPage.isDisplayed(), true, "Analysis page is displayed");
		Assert.assertEquals(selectPagesPage.checkBoxAnalysisPage.isEnabled(), true);
		Assert.assertEquals(selectPagesPage.imageAnalysisPage.isDisplayed(), true);
	}


	@Test(dependsOnMethods="selectPagesTest")
	public void pageSelectionTest(){
		OverLayComponents overLayComponents=new OverLayComponents(driver);
		SelectPagesPage selectPagesPage=new SelectPagesPage(driver);
		wait(5);
		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelSelectPages));
		wait.until(ExpectedConditions.elementToBeClickable(selectPagesPage.labelThingList));
		selectPagesPage.labelThingList.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbThingList));	
		selectPagesPage.labelThingList.click();
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbThingList));

		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelThingPage));
		selectPagesPage.labelThingPage.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbThingPage));
		selectPagesPage.labelThingPage.click();
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbThingPage));

		wait.until(ExpectedConditions.visibilityOf(selectPagesPage.labelAnalysisPage));
		selectPagesPage.labelAnalysisPage.click();
		wait(8);
		Assert.assertFalse(isElementPresent(overLayComponents.breadCrumbAnalysisPage));
		selectPagesPage.labelAnalysisPage.click();
		Assert.assertTrue(isElementPresent(overLayComponents.breadCrumbAnalysisPage));

		selectPagesPage.dropDownSelectPST.clear();
		selectPagesPage.dropDownSelectPST.sendKeys(testDataMap.get("PST"));
		//wait.until(ExpectedConditions.textToBePresentInElementValue(selectPagesPage.dropDownSelectNamedPST, testDataMap.get("Named PST")));
		selectPagesPage.dropDownSelectNamedPST.clear();
		selectPagesPage.dropDownSelectNamedPST.sendKeys(testDataMap.get("Named PST"));

		if(testDataMap.get("Select Thing List").equalsIgnoreCase("No"))
			selectPagesPage.labelThingList.click();
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("No"))
			selectPagesPage.labelThingPage.click();
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("No"))
			selectPagesPage.labelAnalysisPage.click();
		wait(10);
		selectPagesPage.buttonNext.click();
	}

	@Test(dependsOnMethods="pageSelectionTest")
	public void landingPageConfigurationTest(){
		LandingPage landingPage=new LandingPage(driver);
		wait.until(ExpectedConditions.elementToBeClickable(landingPage.checkBoxThingList));
		if(testDataMap.get("Thing List on Map Check box").equals("No"))
			landingPage.checkBoxThingList.click();
		else{
			landingPage.inputThingListInfo1.clear();
			landingPage.inputThingListInfo1.sendKeys(testDataMap.get("ThingList on Map Info 1"));
			wait(2);
			landingPage.inputThingListInfo2.clear();
			landingPage.inputThingListInfo2.sendKeys(testDataMap.get("ThingList on Map Info 2"));
			landingPage.inputThingListSortField.clear();
			landingPage.inputThingListSortField.sendKeys(testDataMap.get("ThingList on Map Sort field"));
			wait(2);
			if(testDataMap.get("ThingList on Map Sort Direction").equalsIgnoreCase("Descending"))
				landingPage.labelDescendingSortOrder.click();
		}
		wait(2);
		landingPage.inputDetailTitle.sendKeys(testDataMap.get("Single Card Title"));
		landingPage.inputDetailViewHeaderInfo1.clear();
		wait(5);
		landingPage.inputDetailViewHeaderInfo1.sendKeys(testDataMap.get("Single Card Header info 1"));
		wait(2);
		landingPage.inputDetailViewHeaderInfo2.clear();
		landingPage.inputDetailViewHeaderInfo2.sendKeys(testDataMap.get("Single Card Header info 2"));
		wait(2);
		landingPage.inputDetailViewHeaderNavigation.clear();
		landingPage.inputDetailViewHeaderNavigation.sendKeys(testDataMap.get("Single Card Header Navigation"));
		wait(2);
		if(testDataMap.get("Single Card Event Enable").equalsIgnoreCase("No"))
			landingPage.checkboxEvent.click();
		else
			landingPage.inputEventAreaTitle.sendKeys(testDataMap.get("Single Card Event Title"));
		wait(2);
		if(testDataMap.get("Single Card Contact Enable").equalsIgnoreCase("No"))
			landingPage.checkboxContactInfo.click();
		else{
			landingPage.inputContactInfoAreaTitle.sendKeys(testDataMap.get("Single Card Contact Title"));
			wait(2);
			landingPage.inputContactInfo1.clear();
			landingPage.inputContactInfo1.sendKeys(testDataMap.get("Single Card Contact Info1"));
			wait(5);
			landingPage.inputContactInfo2.clear();
			landingPage.inputContactInfo2.sendKeys(testDataMap.get("Single Card Contact Info2"));
			wait(2);
			landingPage.inputContactInfo3.clear();
			landingPage.inputContactInfo3.sendKeys(testDataMap.get("Single Card Contact Info3"));
		}
		wait(5);
		landingPage.inputDetailCardFooterText.sendKeys(testDataMap.get("Single Card footer text"));
		wait(2);
		landingPage.inputDetailCardFooterNavigation.clear();
		landingPage.inputDetailCardFooterNavigation.sendKeys(testDataMap.get("Single Card navigation target"));
		wait(2);
		landingPage.inputListCardTitle.sendKeys(testDataMap.get("Multi Card title"));
		wait(2);
		landingPage.inputListCardInfo1.clear();
		landingPage.inputListCardInfo1.sendKeys(testDataMap.get("Multi Card info1"));
		wait(5);
		landingPage.inputListCardInfo2.clear();
		landingPage.inputListCardInfo2.sendKeys(testDataMap.get("Multi Card info2"));
		wait(2);
		landingPage.inputListCardNavigation.clear();
		landingPage.inputListCardNavigation.sendKeys(testDataMap.get("Multi Card List navigation target"));
		wait(2);
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			landingPage.inputListCardFooterText.sendKeys(testDataMap.get("Multi Card footer text"));
			wait(2);
			landingPage.inputListCardFooterNavigation.clear();
			landingPage.inputListCardFooterNavigation.sendKeys(testDataMap.get("Multi Card footer navigation target"));
		}
		else{
			Assert.assertFalse(isElementPresent(landingPage.inputListCardFooterText));
			Assert.assertFalse(isElementPresent(landingPage.inputListCardFooterNavigation));
		}
		wait.until(ExpectedConditions.elementToBeClickable(landingPage.buttonNextEnabled));
		landingPage.buttonNextEnabled.click();		
	}

	@Test(dependsOnMethods="landingPageConfigurationTest")
	public void thingListConfigurationTest(){
		if(testDataMap.get("Select Thing List").equalsIgnoreCase("Yes")){
			ThingListConfigPage thingListConfigPage=new ThingListConfigPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingListConfigPage.textBoxTitle));
			thingListConfigPage.textBoxTitle.sendKeys(testDataMap.get("ThingListTitle"));
			thingListConfigPage.inputSortingField.clear();
			thingListConfigPage.inputSortingField.sendKeys(testDataMap.get("Default sort field"));
			wait(2);
			if(testDataMap.get("Sort Direction").equalsIgnoreCase("Descending"))
				thingListConfigPage.radioButtonDescending.click();
			thingListConfigPage.inputColumn2.clear();
			thingListConfigPage.inputColumn2.sendKeys(testDataMap.get("Column 2"));
			wait(2);
			thingListConfigPage.inputColumn3.clear();
			wait(2);
			thingListConfigPage.inputColumn3.sendKeys(testDataMap.get("Column 3"));
			thingListConfigPage.inputColumn4.clear();
			thingListConfigPage.inputColumn4.sendKeys(testDataMap.get("Column 4"));
			wait(5);
			thingListConfigPage.inputColumn5.clear();
			thingListConfigPage.inputColumn5.sendKeys(testDataMap.get("Column 5"));
			wait(2);
			thingListConfigPage.inputColumn6.clear();
			thingListConfigPage.inputColumn6.sendKeys(testDataMap.get("Column 6"));
			wait(2);
			thingListConfigPage.inputColumn7.clear();
			thingListConfigPage.inputColumn7.sendKeys(testDataMap.get("Column 7"));
			wait(2);
			thingListConfigPage.inputColumn8.clear();
			thingListConfigPage.inputColumn8.sendKeys(testDataMap.get("Column 8"));
			wait(2);
			thingListConfigPage.comboBoxListItemNavTarget.clear();
			thingListConfigPage.comboBoxListItemNavTarget.sendKeys(testDataMap.get("List navigation target"));
			wait.until(ExpectedConditions.elementToBeClickable(thingListConfigPage.buttonNext));
			thingListConfigPage.buttonNext.click();
		}else
			Reporter.log("Test case for thinglist is skipped");
	}

	@Test(dependsOnMethods="thingListConfigurationTest")
	public void thingPageConfigurationTest(){
		if(testDataMap.get("Select Thing Page").equalsIgnoreCase("Yes")){
			ThingPage thingPage=new ThingPage(driver);
			wait.until(ExpectedConditions.visibilityOf(thingPage.dropBoxInformation1));
			thingPage.dropBoxInformation1.clear();
			thingPage.dropBoxInformation1.sendKeys(testDataMap.get("Header Info1"));
			wait(2);
			thingPage.dropBoxInformation2.clear();
			thingPage.dropBoxInformation2.sendKeys(testDataMap.get("Header Info2"));
			wait(2);
			thingPage.dropBoxInformation3.clear();
			thingPage.dropBoxInformation3.sendKeys(testDataMap.get("Header Info3"));
			wait(2);
			wait.until(ExpectedConditions.visibilityOf(thingPage.checkboxContentBasicData));
			if(testDataMap.get("Basic Data Enable").equalsIgnoreCase("Yes")){
				thingPage.dropBoxColumn1Info1.clear();
				wait(2);
				thingPage.dropBoxColumn1Info1.sendKeys(testDataMap.get("Column1 info1"));

				thingPage.dropBoxColumn2Info1.clear();
				thingPage.dropBoxColumn2Info1.sendKeys(testDataMap.get("Column 2 info1"));
				wait(2);
				thingPage.dropBoxColumn3Info1.clear();
				thingPage.dropBoxColumn3Info1.sendKeys(testDataMap.get("Column 3 info1"));
				/* Checks if user wants to add additional data into basic details for column1
				 * if in data sheet, data exists for additional info, then click on add button for column1
				 * and enter the data.
				 */
				for(int i=2;i<9;i++){
					if(!testDataMap.get("Column1 info"+i).isEmpty()) {
						thingPage.buttonAddList.get(0).click();
						thingPage.dropDownColumn1List.get(i-1).clear();
						thingPage.dropDownColumn1List.get(i-1).sendKeys(testDataMap.get("Column1 info"+i));
						wait(2);
					}		
				}
				wait(2);
				for(int j=2;j<9;j++){
					if(!testDataMap.get("Column 2 info"+j).isEmpty()) {
						thingPage.buttonAddList.get(1).click();
						thingPage.dropDownColumn2List.get(j-1).clear();
						thingPage.dropDownColumn2List.get(j-1).sendKeys(testDataMap.get("Column 2 info"+j));
						wait(2);
					}		
				}
				wait(2);
				for(int i=2;i<9;i++){
					if(!testDataMap.get("Column 3 info"+i).isEmpty()) {
						thingPage.buttonAddList.get(2).click();
						thingPage.dropDownColumn3List.get(i-1).clear();
						thingPage.dropDownColumn3List.get(i-1).sendKeys(testDataMap.get("Column 3 info"+i));
						wait(2);
					}		
				}

			}else
				thingPage.checkboxContentBasicData.click();
			Actions action = new Actions(driver); 
			action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
			//		scrollToElementUsingJavascriptExecutor(thingPage.checkBoxMeasureValues);
			scrollPageToBottom();
			if(testDataMap.get("Measured Values Enable").equalsIgnoreCase("No"))
				thingPage.checkBoxMeasureValues.click();

			wait(2);
			if(testDataMap.get("Events Enable").equalsIgnoreCase("No"))
				thingPage.checkBoxEvents.click();
			if(testDataMap.get("Timeline Enable").equalsIgnoreCase("No"))
				thingPage.checkBoxTimeline.click();

			wait.until(ExpectedConditions.elementToBeClickable(thingPage.buttonNextEnabled));
			thingPage.buttonNextEnabled.click();
		}else
			Reporter.log("Test case for thing page is skipped");
	}

	@Test(dependsOnMethods="thingPageConfigurationTest")
	public void analysisPageConfigurationTest(){
		if(testDataMap.get("Select Analysis Page").equalsIgnoreCase("Yes")){
			AnalysisPageConfigurationPage analysisConfigurationPage= new AnalysisPageConfigurationPage(driver);
			wait.until(ExpectedConditions.visibilityOf(analysisConfigurationPage.radioButton7Days));
			if(testDataMap.get("Default Time Period").equalsIgnoreCase("28 Days"))
				analysisConfigurationPage.radioButton28Days.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("7 Days"))
				analysisConfigurationPage.radioButton7Days.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("24 Hours"))
				analysisConfigurationPage.radioButton24Hours.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("12 Hours"))
				analysisConfigurationPage.radioButton12Hours.click();
			else if(testDataMap.get("Default Time Period").equalsIgnoreCase("1 Hour"))
				analysisConfigurationPage.radioButton1Hour.click();

			if(testDataMap.get("Time Slider Enable").equalsIgnoreCase("No"))
				analysisConfigurationPage.checkBoxShowTimeSlider.click();			
			analysisConfigurationPage.buttonFinish.click();
		}else
			Reporter.log("Test case for analysis page is skipped");
	}

	@Test(dependsOnMethods="analysisPageConfigurationTest")
	public void projectDeploymentTest(){
		String generatedAppURL="";
		WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.buttonWorkspace));
		wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonWorkspace));
		wait(20);
		webIDEHomePage.buttonWorkspace.click();
		wait(5);
		for (WebElement	element : webIDEHomePage.generatedProjectsList) {
			if(element.findElement(By.tagName("span")).getText().equals(testDataMap.get("Project Name"))){
				rightClickOnElement(element,driver);
				wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.contextMenuDeploy));
				moveToElementAndClickOnSubMenu(webIDEHomePage.contextMenuDeploy, webIDEHomePage.contextMenuDeployToHCP,driver);
				wait.until(ExpectedConditions.visibilityOf(webIDEHomePage.inputLogOnToSAP));
				webIDEHomePage.inputLogOnToSAP.clear();
				webIDEHomePage.inputLogOnToSAP.sendKeys("I329033");
				wait(5);
				webIDEHomePage.inputLogOnPassword.clear();
				webIDEHomePage.inputLogOnPassword.sendKeys("Vs@9496334472");
				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonLogin));
				webIDEHomePage.buttonLogin.click();

				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.buttonDeploy));
				webIDEHomePage.buttonDeploy.click();
				wait.until(ExpectedConditions.elementToBeClickable(webIDEHomePage.linkOpenApplication));
				generatedAppURL=webIDEHomePage.linkOpenApplication.getAttribute("href");
				Reporter.log(generatedAppURL+" is the generated application URL");
			}
		}
		String userDir = System.getProperty("user.dir");
		ExcelUtils excelUtil=new ExcelUtils();
		try {
			excelUtil.writeProjectURLToExcel(generatedAppURL, testDataMap.get("Project Name"),userDir+"/src/test/resources/TestDataDemo.xlsx");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reporter.log("Unable to write generated app URL to excel");
			e.printStackTrace();
		}
	}

}

/*	@DataProvider(name="testData")
	public Object[][] getTestData(){
		System.out.println("In ReUseUITest getTestData dataprovider");
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.loadDataFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}*/

/*@DataProvider(name="basicDetails")
	public Object[][] getBasicDetails(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.getBasicDetailsFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

	@DataProvider(name="pageDetails")
	public Object[][] getPageSelectionDetails(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.getPageSelectionDetailsFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

	@DataProvider(name="landingPageDetails")
	public Object[][] getLandingPageDetails(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.getLandingPageDetailsFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

	@DataProvider(name="thingListDetails")
	public Object[][] getThingListDetails(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.getThingListDetailsFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

	@DataProvider(name="thingPageDetails")
	public Object[][] getThingPageDetails(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.getThingPageDetailsFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}

	@DataProvider(name="analysisPageDetails")
	public Object[][] getAnalysisPageDetails(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.getAnalysisPageDetailsFromSpreadsheet(userDir+"/src/test/resources/TestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}
 */

