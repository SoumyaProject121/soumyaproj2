package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class SelectPagesPage extends BasePage{
	
	@FindBy(xpath="//span[@title='Select Pages']")
	public WebElement labelSelectPages;
	
	@FindBy(xpath="//span[@title='Select the pages you want to use in your application']")
	public WebElement labelSelectThePagesYouWant;
	
	@FindBy(xpath="//div[span[text()='Select the pages you want to use in your application']]//following-sibling::div[1]//input")
	public WebElement inputpageselection;
	
	@FindBy(xpath="//div//button[text()='Landing Page']")
	//(xpath="//label[text()='Landing Page (Main Page)']")
	public WebElement labelLandingPage;
	
	@FindBy(xpath="//input[@value='Landing Page - Event List']")
	public WebElement labelLandingPageEventlist;
	
	@FindBy(xpath="//div[label[@title='PST']]/following-sibling::div[1]//input")
	public WebElement dropDownSelectPST;
	
	@FindBy(xpath="//div[label[@title='Named PST']]/following-sibling::div[1]//input")
	public WebElement dropDownSelectNamedPST;
	
	@FindBy(xpath="//label[text()='Landing Page (Main Page)']/parent::div/following-sibling::div/img")
	public WebElement imageLandingPage;
	
	@FindBy(xpath="//label[text()='Thing List']/preceding-sibling::input")
	public WebElement checkBoxThingList;
	
	@FindBy(xpath="//label[text()='Thing List']")
	public WebElement labelThingList;
	
	@FindBy(xpath="//div[span/label[text()='Thing List']]/following-sibling::div/img")
	public WebElement imageThingList;
	
	@FindBy(xpath="//label[text()='Thing Page']/preceding-sibling::input")
	public WebElement checkBoxThingPage;
	
	@FindBy(xpath="//label[text()='Thing Page']")
	public WebElement labelThingPage;
	
	@FindBy(xpath="//label[text()='Thing Page']/parent::span/../following-sibling::div/img")
	public WebElement imageThingPage;
	
	@FindBy(xpath="//label[text()='Analysis Page']/preceding-sibling::input")
	public WebElement checkBoxAnalysisPage;
	
	@FindBy(xpath="//label[text()='Analysis Page']")
	public WebElement labelAnalysisPage;
	
	@FindBy(xpath="//label[text()='Analysis Page']/parent::span/../following-sibling::div/img")
	public WebElement imageAnalysisPage;
	
	@FindBy(xpath="//button[@title='Next']")
	public WebElement buttonNext;

	public SelectPagesPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}

}
