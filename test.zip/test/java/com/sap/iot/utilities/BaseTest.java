package com.sap.iot.utilities;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.ScreenshotException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import com.sap.iotwebide.pages.SAMLLogonPage;
import com.sap.iotwebide.pages.WebIDEHomePage;


public class BaseTest extends UtilityMethods{

	public static WebDriver driver;
	public static WebDriverWait wait;
	public static String reuseUIAppURL;
	public static String webIDECommitAppURL;
	public static String webIDEStagingAppURL;
	public static String browserName;
	public String testSpace;
	public static String testMachineOS;
	public static String testMachineSystemType;
	protected HashMap<String, String> configurationMap=new HashMap<>();
	public String URL;
	public static String applicationTested; 
	public LinkedHashMap<String, String> testDataSheet;

	public BaseTest(String baseURL,LinkedHashMap<String,String> testMap) {
		configurationMap=readFromPropertiesFile();
		webIDECommitAppURL=configurationMap.get("webIDE_commit_URL");
		webIDEStagingAppURL=configurationMap.get("webIDE_staging_URL");
		System.out.println(webIDECommitAppURL+"webide");
		//reuseUIAppURL=configurationMap.get("reuseUIURL");
		browserName=configurationMap.get("browser");
		testMachineOS=System.getProperty("os.name");
		testMachineSystemType=System.getProperty("os.arch");
		this.testDataSheet=testMap;
		
		System.out.println(" in BaseTest(url) "+baseURL);
		if(baseURL.equalsIgnoreCase("webIDE_commit_URL")){
			this.URL=webIDECommitAppURL;
			applicationTested="WebIDE";
		}
		else if(baseURL.equalsIgnoreCase("webIDE_staging_URL")){
			this.URL=webIDEStagingAppURL;
			applicationTested="WebIDE";
		}
		else{
			this.URL=reuseUIAppURL;
			applicationTested="ReuseUI";
		}
		System.out.println("in baseTest(String,LinkedHashMap) "+this.URL);
	}

	public BaseTest() {
		System.out.println("in BaseTest() ");
		/*	configurationMap=readFromPropertiesFile();
		webIDEAppURL=configurationMap.get("webIDEURL");
		reuseUIAppURL=configurationMap.get("reuseUIURL");
		browserName=configurationMap.get("browser");
		testMachineOS=System.getProperty("os.name");
		testMachineSystemType=System.getProperty("os.arch");
		System.out.println("username=="+configurationMap.get("username"));*/
	}

	@BeforeSuite
	public void beforeSuite() {

		configurationMap=readFromPropertiesFile();
		webIDECommitAppURL=configurationMap.get("webIDE_commit_URL");
		webIDEStagingAppURL=configurationMap.get("webIDE_staging_URL");
	//	reuseUIAppURL=configurationMap.get("reuseUIURL");
		browserName=configurationMap.get("browser");
		testMachineOS=System.getProperty("os.name");
		testMachineSystemType=System.getProperty("os.arch");


		//driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(120,TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}

	@BeforeTest
	public void beforeTest() {

	}

	@BeforeMethod
	public void beforeMethod() {

	}

	@AfterMethod
	public void afterMethod(ITestResult testResult) throws Exception {
		if(testResult.getStatus()==2)
			captureScreenshot(testResult.getMethod().getMethodName());
	}

	@BeforeClass
	public void beforeClass() {
		if(browserName.equalsIgnoreCase("google_chrome")){
			if(testMachineOS.contains("Windows"))
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/test/resources/chromedriver/chromedriver.exe");
			else if(testMachineSystemType.contains("32")){
				File chromeDriver = new File(System.getProperty("user.dir")+"/src/test/resources/chromedriver/chromedriver_linux32");
				chromeDriver.setExecutable(true);
				System.setProperty("webdriver.chrome.driver", chromeDriver.getAbsolutePath());
			}
			else if(testMachineSystemType.contains("64")){
				File chromeDriver = new File(System.getProperty("user.dir")+"/src/test/resources/chromedriver/chromedriver_linux64");
				chromeDriver.setExecutable(true);
				System.setProperty("webdriver.chrome.driver", chromeDriver.getAbsolutePath());
			}
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();

			ChromeOptions options = new ChromeOptions();
			//options.addArguments("--disable-extensions");
			options.addArguments("start-maximized");
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver=new ChromeDriver(capabilities);
			driver.manage().deleteAllCookies();

		}
		else if (browserName.equalsIgnoreCase("internet_explorer")) {
			System.out.println("Pending to load internet explorer");
		}
		else if(browserName.equalsIgnoreCase("firefox")) {
			driver=new FirefoxDriver();
		}
		else
			System.out.println("Unsupported browser");
		wait=new WebDriverWait(driver, 180);
		System.out.println("In before class"+webIDECommitAppURL+" and "+webIDEStagingAppURL+URL);
		driver.get(this.URL);
		SAMLLogonPage samlLogonPage=new SAMLLogonPage(driver);
		//samlLogonPage.login(configurationMap.get("username"),configurationMap.get("password"));

		if(applicationTested.equalsIgnoreCase("WebIDE")){
			WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
			//webIDEHomePage.goToPluginsSection();
			//if live plugin is enabled then disable it
			//webIDEHomePage.selectSAPPluginAsRepository();
			//webIDEHomePage.disableSAPIoTPlugin();
		}
	}

	@AfterClass
	public void afterClass() {
		System.out.println("Checking for alert popup");
		if(URL.equalsIgnoreCase(webIDECommitAppURL)){
			//driver.navigate().refresh();
			try {
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert=driver.switchTo().alert();
				alert.accept();
			} catch (Exception e) {
				System.out.println("No alert present in after class");
			}
		}
		else
			System.out.println("It is reuse UI");
		
	}

	@AfterTest
	public void afterTest() {
	}



	@AfterSuite
	public void afterSuite() throws Exception{
		//driver.close();
		//driver.quit();
	}


	/*
	 * For results storing
	 * @AfterSuite
public void storeResults( ITestResult resultContainer ) {
    List<ITestResult> results = resultContainer.getSuite().getTestResults();
    for ( ITestResult res : results ) {
        storeInCouchDB( testName, testDatetime, res.getResult().isPassed() );
    } 
}
	 */

	public WebDriver getDriver(){
		return this.driver;
	}

	public void wait(int seconds){
		try {
			int sleepDuration=seconds*1000;
			Thread.sleep(sleepDuration);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void scrollPageToBottom(){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,50)");
	}

	public void moveToElement(WebElement element){
		/*Actions actions=new Actions(getDriver());
		if(element.isDisplayed())
			actions.moveToElement(element).click().build().perform();
		else
		{
			//wait(30);
			actions.moveToElement(element).click().build().perform();
		}*/
	}

	public void captureScreenshot(String fileName) throws Exception{
		System.out.println(LocalDateTime.now().toString());
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);          
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"/test-output/"+applicationTested+"/"+LocalDateTime.now().toString().split("T")[0]+"/"+fileName+LocalDateTime.now().toString().split("T")[1].replace(':', '-')+".png"));
	}

}
