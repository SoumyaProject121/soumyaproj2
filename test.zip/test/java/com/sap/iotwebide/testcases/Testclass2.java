package com.sap.iotwebide.testcases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.sap.iot.utilities.BasePage;
import com.sap.iot.utilities.UtilityMethods;
import com.sap.iotwebide.pages.BasicInformationPage;
import com.sap.iotwebide.pages.DataSourcePage;
import com.sap.iotwebide.pages.SAMLLogonPage;
import com.sap.iotwebide.pages.TemplateSelectionPage;
import com.sap.iotwebide.pages.WebIDEHomePage;

public class Testclass2 extends UtilityMethods{

	public static WebDriver driver;
    WebDriverWait wait;

	@Test
	public void projectDeploymentTest() throws IOException, InterruptedException, AWTException{

		//driver.get("https://webide-acb903337.dispatcher.hana.ondemand.com/");
		driver.get("https://webidecp-aqjuqi30uc.dispatcher.int.sap.eu2.hana.ondemand.com/");
		wait(15);
		SAMLLogonPage samlLogonPage=new SAMLLogonPage(driver);
		samlLogonPage.login("soumya.golla@sap.com", "Welcome@321");
		wait(30);
		//WebIDEHomePage webIDEHomePage=new WebIDEHomePage(driver);
		
		Actions act =  new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath("//span[text()='New Project from Template']"))).click().perform();
		//webIDEHomePage.newProjectfromTemplate.click();
		wait(15);
		TemplateSelectionPage templateselection = new TemplateSelectionPage(driver);
		
		act.moveToElement(templateselection.templateIoT).click().perform();
		wait(15);
		templateselection.buttonNext.click();
		wait(15);
		BasicInformationPage values = new BasicInformationPage(driver);
		values.basicinfoDetails("newprojectiot1", "iotapplication", "app1");
		wait(15);
		values.buttonNext.click();
		DataSourcePage datasource = new DataSourcePage(driver);
		datasource.dropDownService.sendKeys("IOTAS-ADVANCEDLIST-THING-ODATA");
		wait(15);
		datasource.selectdropDown.click();
		wait(10);
		datasource.thingPropertySetsIcon.click();
		wait(10);
		datasource.selectThingTypeTxtbox.sendKeys("iotae.sandboxdevx03.test.automobiles:CarsThingType");
		//BasePage enterkey = new BasePage();
		//enterkey.keyPressENTER();
		Robot robot=new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		wait(15);
		wait.until(ExpectedConditions.elementToBeClickable(datasource.propertsetofThingtype));
		datasource.propertsetofThingtype.click();
		//act.moveToElement(datasource.propertsetofThingtype).click().pause(20);
		//robot.keyPress(KeyEvent.VK_SPACE); //fire spacebar event
        //robot.keyRelease(KeyEvent.VK_SPACE);
		wait(10);
		datasource.okbutton.click();
		wait(20);
		wait.until(ExpectedConditions.elementToBeClickable(datasource.eventPropertySetsIcon));
		datasource.eventPropertySetsIcon.click();
		wait(10);
		datasource.eventTypeTxtbox.sendKeys(Keys.ENTER);
		wait(10);
		//wait.until(ExpectedConditions.elementToBeClickable(datasource.searchEventType));
		datasource.searchEventType.sendKeys("iotae.sandboxdevx03.test.automobiles:EventType11");
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		wait(10);
		//robot.keyPress(KeyEvent.VK_DOWN);
		//robot.keyRelease(KeyEvent.VK_DOWN);
		//wait.until(ExpectedConditions.elementToBeClickable(datasource.elementselectable));
		act.moveToElement(datasource.elementselectable).click().perform();
		//robot.keyPress(KeyEvent.);
		//robot.keyRelease(KeyEvent.VK_ENTER);
		wait.until(ExpectedConditions.elementToBeClickable(datasource.propertsetofEventtype));
		datasource.propertsetofEventtype.click();
		wait(10);
		datasource.okbutton.click();
	}
	
	
	@BeforeTest
	public void login(){

		System.out.println("In basetest before suite");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\C5318528\\git\\iot.ui.webideautomation\\src\\test\\resources\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.get("https://webidecp-aqjuqi30uc.dispatcher.int.sap.eu2.hana.ondemand.com/");
		
		//System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/test/resources/chromedriver/chromedriver_windows.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		//options.addArguments("--disable-extensions");
		options.addArguments("start-maximized");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		//capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		driver=new ChromeDriver(capabilities);
		driver.manage().deleteAllCookies();

		wait=new WebDriverWait(driver, 120);
}
	
	public void wait(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
