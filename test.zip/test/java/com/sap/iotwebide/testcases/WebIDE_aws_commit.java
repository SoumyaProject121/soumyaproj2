package com.sap.iotwebide.testcases;

import java.util.LinkedHashMap;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;

import com.sap.iot.utilities.ExcelUtils;

/**
 * 
 * @author I329033
 * Factory class will read from excel sheet and invoke WebIDETest class by assigning each set of data values from excel
 */
public class WebIDE_aws_commit {
	
	/**
	 * @param basicDetails - HashMap of column name and value pair which is read
	 *  from test data excel sheet
	 * @return creates new object of test class with the test data and tested application name
	 */
	
	@Factory(dataProvider = "testData")
	public Object[] testCreator(LinkedHashMap<String, String> basicDetails) {	
		System.out.println("In factory class factory method");
		return new Object[] { new WebIDETest("webIDE_commit_URL",basicDetails) }; 
		//WebIDETest, WebIDETestMapwithFilter, WebIDETestEventList
	}

	/**
	 * @return 2 D object array of test data from excel
	 * Excel sheet should be placed in the location /src/test/resources
	 */
	@DataProvider(name="testData",parallel=true)
	public Object[][] getTestData(){
		Object[][] testDataArray = null;
		try {
			String userDir = System.getProperty("user.dir");
			ExcelUtils excelUtil=new ExcelUtils();
			testDataArray = excelUtil.loadDataFromSpreadsheet(userDir+"/src/test/resources/CopyOfTestDataDemo.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testDataArray;
	}
}
