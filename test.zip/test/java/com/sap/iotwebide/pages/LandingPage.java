package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class LandingPage extends BasePage{

	public LandingPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	
	@FindBy(xpath="//div[@title='Thing List ']//div[1]") // updated 2/2/2021
	//(xpath="//div[span[@title='Thing List ']]/following-sibling::div[1]//span")  //$x("//span[@ role='checkbox']")[0]
	public WebElement checkBoxThingList;
	
	@FindBy(xpath="//div[div[@title='Thing List ']]/following-sibling::div[label[@title='Information 1']]/following-sibling::div[1]//input")// updated 2/2/2021
	//(xpath="//div[span[@title='Thing List ']]/following-sibling::div[label[text()='Information 1']]/following-sibling::div[1]//input")
	public WebElement inputThingListInfo1;
	
	@FindBy(xpath="//div[div[@title='Thing List ']]/following-sibling::div[label[@title='Information 1']]/following-sibling::div[3]//input")// updated 2/2/2021
	//(xpath="//div[span[@title='Thing List ']]/following-sibling::div[label[text()='Information 1']]/following-sibling::div[3]//input")
	public WebElement inputThingListInfo2;
	
	@FindBy(xpath="//div[div[@title='Thing List ']]/following-sibling::div[label[@title='Information 1']]/following-sibling::div[5]//input")// updated 2/2/2021
	public WebElement inputThingListInfo3;
	
	@FindBy(xpath="//div[div[@title='Thing List ']]/following-sibling::div[label[@title='Information 1']]/following-sibling::div[8]//input") //updated 2/2/2021
	//(xpath="//div[span[@title='Thing List ']]/following-sibling::div[label[text()='Information 1']]/following-sibling::div[6]//input")
	public WebElement inputThingListSortField;
	
	@FindBy(xpath="//label[text()='Ascending']")
	public WebElement labelAscendingSortOrder;
	
	@FindBy(xpath="//label[text()='Descending']")
	public WebElement labelDescendingSortOrder;
	
	@FindBy(xpath="//div[span[text()='Thing Card - Single Object']]/parent::div//input")
	//(xpath="//div[span[text()='Thing Card - Details View']]/parent::div//input") 
	public WebElement inputDetailTitle;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[2]//input") //Updated 2/2/2021
	//(xpath="//div[label[text()='Header']]/following-sibling::div[2]//input")
	public WebElement inputDetailViewHeaderInfo1;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[4]//input")
	//(xpath="//div[label[text()='Header']]/following-sibling::div[4]//input")
	public WebElement inputDetailViewHeaderInfo2;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[6]//input") //Added 2/2/2021
	public WebElement inputDetailViewHeaderInfo3;
	
	@FindBy(xpath="//div[label[text()='Thing Information']]/following-sibling::div[8]//input")
	//(xpath="//div[label[text()='Header']]/following-sibling::div[6]//input")
	public WebElement inputDetailViewHeaderNavigation;
	
	@FindBy(xpath="//div[label[bdi[text()='Event']]]//div[1]")
	//(xpath="//div[label[text()='Event']]/following-sibling::div[1]//span")
	public WebElement checkboxEvent;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[1]//input")
	//(xpath="//div[label[text()='Event']]/following-sibling::div[3]//input")
	public WebElement inputEventAreaTitle;
	
	@FindBy(xpath="//div[label[bdi[text()='Contact Information']]]//div[1]")
	//(xpath="//div[label[text()='Contact Information']]/following-sibling::div[1]//span")
	public WebElement checkboxContactInfo;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[1]//input")
	//(xpath="//div[label[text()='Contact Information']]/following-sibling::div[3]//input")
	public WebElement inputContactInfoAreaTitle;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[3]//input")
	//(xpath="//div[label[text()='Contact Information']]/following-sibling::div[5]//input")
	public WebElement inputContactInfo1;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[5]//input")
	//(xpath="//div[label[text()='Contact Information']]/following-sibling::div[7]//input")
	public WebElement inputContactInfo2;
	
	@FindBy(xpath="(//div[label[@title='Area Title']])[2]//following-sibling::div[7]//input")
	//(xpath="//div[label[text()='Contact Information']]/following-sibling::div[9]//input")
	public WebElement inputContactInfo3;
	
	@FindBy(xpath="(//div[label[text()='Footer']])[1]//following-sibling::div[2]/input")
	//(xpath="//div[div[div[label[text()='Contact Information']]]]/following-sibling::div[1]//div[label[text()='Text']]/following-sibling::div/input")
	public WebElement inputDetailCardFooterText;
	
	@FindBy(xpath="(//div[label[text()='Footer']])[1]//following-sibling::div[4]//div[1]/input")
	//(xpath="//div[div[div[label[text()='Contact Information']]]]/following-sibling::div[1]//div[label[text()='Navigation Target']]/following-sibling::div//input")
	public WebElement inputDetailCardFooterNavigation;
	
	@FindBy(xpath="//div[span[text()='Thing Card - Multiple Objects']]//following-sibling::div[2]/input")
	//(xpath="//div[span[text()='Thing Card - List View']]/following-sibling::div[2]/input")
	public WebElement inputListCardTitle;
	
	@FindBy(xpath="//div[span[text()='Thing Card - Multiple Objects']]/following-sibling::div[4]//input")
	//(xpath="//div[span[text()='Thing Card - List View']]/following-sibling::div[4]//input")
	public WebElement inputListCardInfo1;
	
	@FindBy(xpath="//div[span[text()='Thing Card - Multiple Objects']]/following-sibling::div[6]//input")
	//(xpath="//div[span[text()='Thing Card - List View']]/following-sibling::div[6]//input")
	public WebElement inputListCardInfo2;
	

	@FindBy(xpath="//div[span[text()='Thing Card - Multiple Objects']]/following-sibling::div[8]//input")
	//(xpath="//div[span[text()='Thing Card - List View']]/following-sibling::div[8]//input")
	public WebElement inputListCardNavigation;
	
	@FindBy(xpath="(//div[label[text()='Footer']])[2]//following-sibling::div[2]/input")
	//(xpath="//div[label[text()='List Item Navigation Target']]/../../../../div/div[8]//div[label[text()='Text']]/following-sibling::div/input")
	public WebElement inputListCardFooterText;
	
	@FindBy(xpath="(//div[label[text()='Footer']])[2]//following-sibling::div[4]//div[1]/input")
	//(xpath="//div[label[text()='List Item Navigation Target']]/../../../../div/div[8]//div[label[text()='Navigation Target']]/following-sibling::div//input")
	public WebElement inputListCardFooterNavigation;
	
	@FindBy(xpath="//button[@title='Next']")
	//(xpath="//button[@aria-disabled='false' and @title='Next']")
	public WebElement buttonNextEnabled;
	
	@Override
	public boolean hasPageLoaded() {
		// TODO Auto-generated method stub
		return false;
	}

}
