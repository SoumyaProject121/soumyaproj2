package com.sap.iot.utilities;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;





public class Sample extends UtilityMethods{
	public static void main(String []args) {
		/*ArrayList<String> l1=new ArrayList<String>();
		ArrayList<String> l2=new ArrayList<String>();
		l1.add("");
		l1.add("a");
		l1.add("a");
		l1.add("b");


		l2.add("No Customer");
		l2.add("No Country");
		l2.add("");
		l2.add("a");
		l2.add("b");

		Sample sample=new Sample();
		System.out.println(sample.assertFilterColumns(l1, l2));*/
		//l2.add("a");


		/*	ArrayList<Integer> list = new ArrayList<>();
		l1.forEach(item -> list.add(l1.indexOf(item))); 

		System.out.println(list.size()+" Size ");
		for (int i : list) {
			System.out.println(i);
		}*/
		/*if(isSortedInAscending(l2)){
			System.out.println("Sorted in ascending");
		}
		else
			System.out.println("Not sorted in acsending");*/

		/*	if(isSorted(list)(l2)){
			System.out.println("already sorted");
		}
		else{
			Collections.sort(l2);
		}
		System.out.println(isSorted(l2));*/
		System.out.println(LocalDateTime.now().toString().split("T")[0]);
		System.out.println(LocalDateTime.now().toString().split("T")[1].replace(':', '-'));
		
		
		/*System.out.println(TimeZone.getDefault()+" - Default");
		String[] timeXoneArray=TimeZone.getAvailableIDs();
		for (String string : timeXoneArray) {
			System.out.println(string+" IDs");
		}
		System.out.println(TimeZone.getDefault()+" - Default");*/
	}
	public static boolean isSorted(List<String> list){
		String previous = "";
		for (String current: list) {
			if (current.compareTo(previous) < 0)
				return false;
			previous = current;
		}
		return true;
	}

	public boolean assertFilterColumns(ArrayList<String> actualList,ArrayList<String> userEnteredValues){
		boolean assertionStatus = false;
		if(userEnteredValues.contains("No Customer")||userEnteredValues.contains("No Location")||userEnteredValues.contains("No Country")){
			userEnteredValues.add("");			
		}
		for (String actualValue : actualList) {	
			if(userEnteredValues.contains(actualValue))
				assertionStatus=true;
			else{
				assertionStatus=false;
				return assertionStatus;
			}
		}
		return assertionStatus;
	}
}

