package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

import static io.appium.java_client.touch.LongPressOptions.longPressOptions;

public class ChangeFontsizeandVerifyApp {

		static AppiumDriver<MobileElement> driver;

		public static void main(String[] args) throws MalformedURLException, InterruptedException {
			
			LaunchAppandVerifyHomepage.openPlaystore();
			Thread.sleep(5000);
			changefontsize();
			//LaunchAppandVerifyHomepage app2 = new LaunchAppandVerifyHomepage();
			Thread.sleep(5000);
			LaunchAppandVerifyHomepage.openPlaystore();
			
		}
			
			
			public static void changefontsize() throws MalformedURLException, InterruptedException 
			{
				DesiredCapabilities cap = new DesiredCapabilities();
				cap.setCapability("deviceName", "Emulator123"); //Emulator123
				cap.setCapability("platformName", "Android");
				cap.setCapability("platformVersion", "9"); //9
				cap.setCapability("appPackage", "com.android.settings");
				cap.setCapability("appActivity", "com.android.settings.Settings");
				
				URL url = new URL("http://127.0.0.1:4723/wd/hub");
				
				driver = new AppiumDriver<MobileElement>(url,cap);
				Thread.sleep(3000);
				System.out.println("Settings opened");	
				Thread.sleep(8000);
				driver.findElement(By.xpath("//android.widget.TextView[@text='Display']")).click();
				Thread.sleep(5000);
				System.out.println("Clicked on Dispaly");
				driver.findElement(By.xpath("//android.widget.TextView[@text='Advanced']")).click();
				Thread.sleep(5000);
				System.out.println("Clicked on Advanced");
				driver.findElement(By.xpath("//android.widget.TextView[@text='Font size']")).click();
				Thread.sleep(3000);
				System.out.println("Clicked on Fontsize");
				MobileElement ele1 = driver.findElement(By.xpath("//android.widget.RadioButton[@content-desc='Default']"));
				MobileElement ele2 = driver.findElement(By.xpath("//android.widget.RadioButton[@content-desc='Largest']"));
				
				
				System.out.println("Moved slider default to largest to increase the font size");
				
				
				TouchAction touchAction = new TouchAction(driver);
				touchAction.press(ElementOption.element(ele1))
				.waitAction(WaitOptions.waitOptions(Duration.ofMillis(100)))
				.moveTo(ElementOption.element(ele2)).release().perform();
				//.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
				//.moveTo(ElementOption.element(ele2)).release().perform();
				//.moveTo(ElementOption.element(el3))
				//.release().perform();
				
				
				
				
				
				
				
				/*WebElement seek_bar=driver.findElement(By.xpath("//android.widget.RadioButton[@content-desc='Default]'"));
	            // get start co-ordinate of seekbar
	            int start=seek_bar.getLocation().getX();
	            //Get width of seekbar
	            int end=seek_bar.getSize().getWidth();
	            //get location of seekbar vertically
	            int y=seek_bar.getLocation().getY();

	        // Select till which position you want to move the seekbar
	        TouchAction action=new TouchAction(driver);

	        //Move it will the end
	        action.press(start,y).moveTo(end,y).release().perform();

	        //Move it 40%
	        int moveTo=(int)(end*0.4);
	        action.press(start,y).moveTo(moveTo,y).release().perform();*/

}}
