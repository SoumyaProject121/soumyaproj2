package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class LaunchAppandVerifyHomepage {
	
	static AppiumDriver<MobileElement> driver;
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
		openPlaystore();

	}
	public static void openPlaystore() throws MalformedURLException, InterruptedException
	{
		
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("deviceName", "Emulator123");
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "9");
		//cap.setCapability("appPackage", "com.flipkart.android");
		//cap.setCapability("appActivity", "com.flipkart.android.activity.HomeFragmentHolderActivity");
		cap.setCapability("appPackage", "com.myntra.android");
		cap.setCapability("appActivity", "com.myntra.android.SplashActivity");
		//cap.setCapability("appPackage", "com.android.vending");
		//cap.setCapability("appActivity", "com.google.android.finsky.activities.MainActivity");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		
		driver = new AppiumDriver<MobileElement>(url,cap);
		
		System.out.println("application started");	
		
		Thread.sleep(15000);
		
		WebElement s1 = driver.findElementByXPath("//android.widget.Button[@content-desc='tabButton_home']/android.widget.ImageView");
		Dimension a = s1.getSize();
		System.out.println(a);
	
		
		boolean ele = driver.findElementByXPath("//android.widget.Button[@content-desc='tabButton_home']/android.widget.ImageView").isDisplayed();
		
		if(ele)
		{
			System.out.println("home page displayed");
		}
		else
		{
			System.out.println("home page not displayed");
		}
		
		
		
		/*try {
			driver.runAppInBackground(10);
			((AndroidDriver) driver).startActivity("appPackage", "appActivity");
			} catch (Exception e) {
					e.printStackTrace();
			}*/
}
}
