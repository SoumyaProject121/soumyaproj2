package com.sap.iotwebide.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sap.iot.utilities.BasePage;

public class DataSourcePage extends BasePage {

	@FindBy(xpath ="//span[@title='Data Source']")
	public WebElement labelDataSource;

	//@FindBy(xpath = "//div[@role='combobox' and contains(@class,'wizardComboBox')]/input") //old xpath
	
	@FindBy(xpath ="//div[@role='combobox' and contains(@class,'sapMInputBaseContentWrapper')]/input") //updated xpath (2/22/2021)
	public WebElement dropDownService;
	
	@FindBy(xpath ="//span[text()='IOTAS-ADVANCEDLIST-THING-ODATA']")
	public WebElement selectdropDown; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="(//span[contains(@class,'sapUiIcon')])[5]")
	public WebElement thingPropertySetsIcon; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="(//input[@class='sapMInputBaseInner'])[3]")
	public WebElement selectThingTypeTxtbox; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="//div[@id=\"__table1-rowsel0\"]")
	public WebElement propertsetofThingtype; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="//bdi[text()='OK']")
	public WebElement okbutton; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="(//span[contains(@class,'sapUiIcon')])[8]")
	public WebElement eventPropertySetsIcon; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="(//span[contains(@class,'sapUiIcon')])[9]")
	public WebElement eventTypeTxtbox; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="//input[@type='search']")
	public WebElement searchEventType; // Added xpath (2/22/2021)
	
	@FindBy(xpath ="//div[@class='sapMSLITitle']")
	public WebElement elementselectable; // Added xpath (2/22/2021)
	
	
	@FindBy(xpath ="//*[@id=\"__table2-rowsel0\"]")
	public WebElement propertsetofEventtype; // Added xpath (2/22/2021)
	
	
	
	@FindBy(css = "div.sapMMultiInputInputContainer>input")
	public WebElement multiInputPropertySets;

	@FindBy(css = "div.sapMInputValHelp>span")
	public WebElement valueHelpPropertySets;

	@FindBy(xpath="//li[@title='IOTAS-ADVANCEDLIST-THING-ODATA']")
	public WebElement listItemAdvancedListThingOData;

	@FindBy(xpath="//button[@title='Next']")
	public WebElement buttonNext;

	/*17/12/2018*/
	/*@FindBy(xpath = "//span[text()='Arrow Down']/..")
	public WebElement dropDownService1;*/

	@FindBy(xpath = "(//*[contains(@class,'sapMInputBaseIconContainer')])[1]/span[contains(@class,'IconPointer')]")
	public WebElement dropDownService1;


	/* 31/01/2019
	 * @FindBy(xpath="//li[text()='IOTAS-ADVANCEDLIST-THING-ODATA']")
	public WebElement listItemAdvancedListThingOData1;*/

	@FindBy(xpath="//li[contains(.,'ADVANCEDLIST') and contains(.,'IOTAS')]")
	public WebElement listItemAdvancedListThingOData1;


	@FindBy(xpath="//*[text()='Service']/ancestor::div[4]//input")
	public WebElement serviceInput;


	// 1: //@FindBy(xpath="//label[text()='Property Sets']/../../../../div[2]//input")
	@FindBy(xpath="//*[text()='Property Sets']/ancestor::div[4]//input")
	public WebElement multiInputPropertySets1;

	@FindBy(xpath="//span[contains(@class,'InputValHelpInner')]")
	public WebElement pstValueOffButton;

	public DataSourcePage(WebDriver driver) {
		super(driver);
		//Assert.assertTrue(hasPageLoaded());
	}

	@Override
	public boolean hasPageLoaded(){
		if(labelDataSource.getText().equals("Data Source"))
			return true;
		else
			return false;
	}

}
