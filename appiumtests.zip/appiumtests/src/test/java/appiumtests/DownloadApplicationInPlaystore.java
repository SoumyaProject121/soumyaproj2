package appiumtests;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DownloadApplicationInPlaystore {

	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
		
		openplaystore();

	}
	
	public static void openplaystore() throws MalformedURLException, InterruptedException 
	{
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("deviceName", "Emulator123"); //Emulator123
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "9"); //9
		cap.setCapability("appPackage", "com.android.vending");
		cap.setCapability("appActivity", "com.google.android.finsky.activities.MainActivity");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		
		driver = new AppiumDriver<MobileElement>(url,cap);
		Thread.sleep(3000);
		System.out.println("Playstore opened");	
		Thread.sleep(8000);
		driver.findElement(By.xpath("//android.widget.TextView[@text='Search for apps & games']")).click();
		Thread.sleep(5000);
		WebElement search = driver.findElement(By.xpath("//android.widget.EditText[@text='Search for apps & games']"));
		driver.findElement(By.xpath("//android.widget.EditText[@text='Search for apps & games']")).sendKeys("facebook lite");
        System.out.println("Searching for the required app");
		Thread.sleep(8000);
		driver.findElement(By.xpath("//android.widget.LinearLayout[contains(@index,'3')]")).click();
		Thread.sleep(8000);
		driver.findElement(By.xpath("//android.widget.Button[@text='Install']")).click();
		Thread.sleep(5000);
		System.out.println("Installion started");
	
}
}
